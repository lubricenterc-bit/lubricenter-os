-- Structure-only snapshot 2026-09-23; no customer, transaction or credential data. Auth is stubbed for local tests.
create role anon; create role authenticated; create role service_role; create schema auth; create schema lubricenter_private;
create table auth.users(id uuid primary key,email text,email_confirmed_at timestamptz);
create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
set check_function_bodies=off;
create table "public"."cashea_sales" ("id" uuid default gen_random_uuid() not null,"order_id" uuid not null,"receivable_id" uuid,"status" text default 'ACTIVE'::text not null,"initial_percent" numeric not null,"commission_percent" numeric not null,"gross_ref" numeric not null,"gross_ves_snapshot" numeric not null,"initial_ref" numeric not null,"initial_ves_snapshot" numeric not null,"financed_ref" numeric not null,"commission_ref" numeric not null,"commission_ves_snapshot" numeric not null,"bcv_rate_snapshot" numeric not null,"initial_payment_method" text not null,"cashea_reference" text,"created_at" timestamp with time zone default now() not null,"settled_at" timestamp with time zone,"created_by" uuid default auth.uid());
create table "public"."cashea_installments" ("id" uuid default gen_random_uuid() not null,"cashea_sale_id" uuid not null,"installment_no" integer not null,"due_date" date not null,"amount_ref" numeric not null,"amount_ves_snapshot" numeric not null,"paid_ref" numeric default 0 not null,"paid_ves_actual" numeric default 0 not null,"status" text default 'PENDING'::text not null,"paid_at" timestamp with time zone,"updated_at" timestamp with time zone default now() not null);
create table "public"."inventory_movements" ("id" uuid default gen_random_uuid() not null,"inventory_item_id" uuid not null,"location_id" uuid not null,"quantity_delta" numeric not null,"movement_type" text not null,"order_item_id" uuid,"note" text,"occurred_at" timestamp with time zone default now() not null,"created_by" uuid default auth.uid(),"created_at" timestamp with time zone default now() not null,"supplier_receipt_item_id" uuid);
create table "public"."suppliers" ("id" uuid default gen_random_uuid() not null,"name" text not null,"legal_name" text,"rif" text,"phone" text,"email" text,"address" text,"contact_name" text,"bank_details" text,"default_currency" text default 'USD'::text not null,"payment_terms_days" integer default 0 not null,"notes" text,"active" boolean default true not null,"created_by" uuid default auth.uid(),"created_at" timestamp with time zone default now() not null,"updated_at" timestamp with time zone default now() not null);
create table "public"."supplier_invoices" ("id" uuid default gen_random_uuid() not null,"supplier_id" uuid not null,"invoice_number" text not null,"invoice_date" date not null,"due_date" date,"currency" text not null,"bcv_rate_snapshot" numeric not null,"operative_rate_snapshot" numeric not null,"subtotal_original" numeric default 0 not null,"tax_original" numeric default 0 not null,"discount_original" numeric default 0 not null,"freight_original" numeric default 0 not null,"total_original" numeric default 0 not null,"paid_original" numeric default 0 not null,"status" text default 'OPEN'::text not null,"notes" text,"created_by" uuid default auth.uid(),"created_at" timestamp with time zone default now() not null,"updated_at" timestamp with time zone default now() not null,"voided_at" timestamp with time zone,"voided_by" uuid,"void_reason" text);
create table "public"."supplier_invoice_items" ("id" uuid default gen_random_uuid() not null,"supplier_invoice_id" uuid not null,"line_type" text not null,"inventory_item_id" uuid,"description" text not null,"expense_category" text,"quantity" numeric not null,"unit_cost_original" numeric not null,"unit_cost_ref" numeric not null,"line_total_original" numeric not null,"received_quantity" numeric default 0 not null,"created_at" timestamp with time zone default now() not null);
create table "public"."supplier_receipts" ("id" uuid default gen_random_uuid() not null,"supplier_invoice_id" uuid not null,"location_id" uuid not null,"received_on" date not null,"status" text default 'POSTED'::text not null,"notes" text,"created_by" uuid default auth.uid(),"created_at" timestamp with time zone default now() not null);
create table "public"."supplier_receipt_items" ("id" uuid default gen_random_uuid() not null,"supplier_receipt_id" uuid not null,"supplier_invoice_item_id" uuid not null,"inventory_item_id" uuid not null,"quantity" numeric not null,"unit_cost_ref" numeric not null,"created_at" timestamp with time zone default now() not null);
create table "public"."supplier_payments" ("id" uuid default gen_random_uuid() not null,"supplier_invoice_id" uuid not null,"account_id" uuid not null,"account_movement_id" uuid not null,"currency" text not null,"amount_original" numeric not null,"amount_applied_invoice" numeric not null,"value_ves" numeric not null,"value_ref" numeric not null,"paid_on" date not null,"reference" text,"note" text,"created_by" uuid default auth.uid(),"created_at" timestamp with time zone default now() not null);
create table "public"."cash_closings" ("id" uuid default gen_random_uuid() not null,"business_date" date not null,"location_id" uuid not null,"status" text default 'OPEN'::text not null,"notes" text,"opened_by" uuid default auth.uid(),"opened_at" timestamp with time zone default now() not null,"closed_by" uuid,"closed_at" timestamp with time zone,"reopened_by" uuid,"reopened_at" timestamp with time zone,"reopen_reason" text,"review_reason" text,"created_at" timestamp with time zone default now() not null,"updated_at" timestamp with time zone default now() not null);
create table "public"."cash_closing_accounts" ("cash_closing_id" uuid not null,"account_id" uuid not null,"opening_native" numeric default 0 not null,"system_in_native" numeric default 0 not null,"system_out_native" numeric default 0 not null,"expected_native" numeric default 0 not null,"actual_native" numeric,"difference_native" numeric,"explanation" text,"denomination_counts" jsonb default '{}'::jsonb not null,"updated_by" uuid default auth.uid(),"updated_at" timestamp with time zone default now() not null);
create table "public"."products" ("id" uuid default gen_random_uuid() not null,"name" text not null,"category" text,"filter_code" text,"available" boolean default true not null,"active" boolean default true not null,"cash_usd_base_price" numeric(14,4) default 0 not null,"notes" text,"created_at" timestamp with time zone default now() not null,"updated_at" timestamp with time zone default now() not null,"image_url" text,"catalog_source" text,"catalog_synced_at" timestamp with time zone);
create table "public"."app_settings" ("key" text not null,"value" jsonb not null,"updated_at" timestamp with time zone default now() not null);
create table "public"."locations" ("id" uuid default gen_random_uuid() not null,"code" text not null,"name" text not null,"active" boolean default true not null,"created_at" timestamp with time zone default now() not null);
create table "public"."employees" ("id" uuid default gen_random_uuid() not null,"code" text not null,"name" text not null,"active" boolean default true not null,"created_at" timestamp with time zone default now() not null,"updated_at" timestamp with time zone default now() not null);
create table "public"."customers" ("id" uuid default gen_random_uuid() not null,"name" text,"phone" text,"document_id" text,"created_at" timestamp with time zone default now() not null,"updated_at" timestamp with time zone default now() not null);
create table "public"."vehicles" ("id" uuid default gen_random_uuid() not null,"customer_id" uuid,"plate" text,"make" text,"model" text,"year" integer,"engine" text,"current_odometer" integer,"created_at" timestamp with time zone default now() not null,"updated_at" timestamp with time zone default now() not null);
create table "public"."exchange_rates" ("id" uuid default gen_random_uuid() not null,"rate_type" text not null,"value" numeric(18,6) not null,"effective_at" timestamp with time zone default now() not null,"source" text,"created_by" uuid default auth.uid(),"created_at" timestamp with time zone default now() not null);
create table "public"."compensation_rules" ("id" uuid default gen_random_uuid() not null,"employee_id" uuid not null,"rule_type" text not null,"value" numeric(14,4) not null,"valid_from" date not null,"valid_to" date,"note" text,"created_at" timestamp with time zone default now() not null);
create table "public"."receivables" ("id" uuid default gen_random_uuid() not null,"order_id" uuid not null,"debtor_type" text not null,"customer_id" uuid,"principal_ves" numeric(18,2) not null,"principal_ref" numeric(18,4) not null,"outstanding_ves" numeric(18,2) not null,"status" text default 'OPEN'::text not null,"due_date" date,"created_at" timestamp with time zone default now() not null,"closed_at" timestamp with time zone);
create table "public"."integration_events" ("id" uuid default gen_random_uuid() not null,"event_type" text not null,"aggregate_type" text not null,"aggregate_id" uuid,"payload" jsonb default '{}'::jsonb not null,"status" text default 'PENDING'::text not null,"attempts" integer default 0 not null,"available_at" timestamp with time zone default now() not null,"processed_at" timestamp with time zone,"last_error" text,"created_at" timestamp with time zone default now() not null);
create table "public"."audit_events" ("id" uuid default gen_random_uuid() not null,"event_type" text not null,"entity_type" text not null,"entity_id" uuid,"data" jsonb default '{}'::jsonb not null,"actor_id" uuid default auth.uid(),"created_at" timestamp with time zone default now() not null);
create table "public"."payroll_accruals" ("id" uuid default gen_random_uuid() not null,"employee_id" uuid not null,"source_order_item_id" uuid not null,"source_type" text not null,"amount_ref" numeric(18,4) not null,"description" text,"occurred_at" timestamp with time zone default now() not null,"payroll_run_id" uuid,"created_at" timestamp with time zone default now() not null);
create table "public"."payroll_runs" ("id" uuid default gen_random_uuid() not null,"employee_id" uuid not null,"period_start" date not null,"period_end" date not null,"fixed_ref" numeric(18,4) default 0 not null,"variable_ref" numeric(18,4) default 0 not null,"adjustments_ref" numeric(18,4) default 0 not null,"total_ref" numeric(18,4) default 0 not null,"status" text default 'SETTLED'::text not null,"created_at" timestamp with time zone default now() not null,"created_by" uuid default auth.uid());
create table "public"."payroll_adjustments" ("id" uuid default gen_random_uuid() not null,"employee_id" uuid not null,"adjustment_type" text not null,"amount_ref" numeric(18,4) not null,"note" text,"occurred_on" date default CURRENT_DATE not null,"payroll_run_id" uuid,"created_at" timestamp with time zone default now() not null,"created_by" uuid default auth.uid());
create table "public"."payments" ("id" uuid default gen_random_uuid() not null,"order_id" uuid not null,"method" text not null,"currency" text not null,"amount_original" numeric(18,4) not null,"bcv_rate_snapshot" numeric(18,6) not null,"operative_rate_snapshot" numeric(18,6) not null,"value_ves" numeric(18,2) not null,"value_ref" numeric(18,4) not null,"reference" text,"paid_at" timestamp with time zone default now() not null,"created_by" uuid default auth.uid(),"created_at" timestamp with time zone default now() not null,"receivable_id" uuid,"financial_account_id" uuid);
create table "public"."order_items" ("id" uuid default gen_random_uuid() not null,"order_id" uuid not null,"item_type" text not null,"business_area" text not null,"description" text not null,"product_id" uuid,"quantity" numeric(14,3) default 1 not null,"pricing_mode" text default 'STANDARD'::text not null,"base_ref_amount" numeric(18,4),"customer_ref_amount" numeric(18,4),"charged_ves_amount" numeric(18,2) not null,"charged_ref_amount" numeric(18,4) not null,"cash_usd_unit_snapshot" numeric(18,4),"cash_usd_special_total" numeric(18,4),"bcv_rate_snapshot" numeric(18,6) not null,"operative_rate_snapshot" numeric(18,6) not null,"cash_price_revealed" boolean default false not null,"worker_employee_id" uuid,"worker_share_percent_snapshot" numeric(9,4),"worker_share_ref_snapshot" numeric(18,4),"assistant_bonus_employee_id" uuid,"assistant_bonus_percent_snapshot" numeric(9,4),"assistant_bonus_ref_snapshot" numeric(18,4),"created_at" timestamp with time zone default now() not null,"service_odometer" integer,"oil_brand" text,"oil_viscosity" text,"oil_quantity_liters" numeric,"oil_filter_code" text,"next_service_odometer" integer,"next_service_date" date,"inventory_item_id" uuid,"inventory_location_id" uuid,"unit_cost_ref_snapshot" numeric,"total_cost_ref_snapshot" numeric);
create table "public"."orders" ("id" uuid default gen_random_uuid() not null,"order_seq" bigint generated always as identity not null,"order_number" text generated always as (('OS-'::text || lpad((order_seq)::text, 6, '0'::text))) stored,"status" text default 'OPEN'::text not null,"customer_id" uuid,"vehicle_id" uuid,"location_id" uuid,"total_ves" numeric(18,2) default 0 not null,"total_ref" numeric(18,4) default 0 not null,"total_cash_usd_equivalent" numeric(18,4) default 0 not null,"opened_at" timestamp with time zone default now() not null,"closed_at" timestamp with time zone,"created_by" uuid default auth.uid(),"created_at" timestamp with time zone default now() not null,"health_status" text default 'GREEN'::text not null,"health_notes" text,"crm_additional_services" text[] default '{}'::text[] not null,"crm_bonuses" text[] default '{}'::text[] not null,"crm_observations" text,"workflow_status" text default 'RECEIVED'::text not null,"workflow_updated_at" timestamp with time zone default now() not null,"health_reviewed_at" timestamp with time zone,"business_at" timestamp with time zone,"corrects_order_id" uuid,"cancellation_reason" text,"cancelled_at" timestamp with time zone,"is_walk_in" boolean default false not null);
create table "public"."account_movements" ("id" uuid default gen_random_uuid() not null,"account_id" uuid not null,"direction" text not null,"movement_type" text not null,"source_payment_id" uuid,"transfer_group" uuid,"currency" text not null,"amount_original" numeric not null,"value_ves" numeric not null,"category" text,"note" text,"reference" text,"occurred_at" timestamp with time zone default now() not null,"created_by" uuid default auth.uid(),"created_at" timestamp with time zone default now() not null,"payee" text);
create table "public"."financial_accounts" ("id" uuid default gen_random_uuid() not null,"code" text not null,"name" text not null,"currency" text not null,"account_type" text not null,"active" boolean default true not null,"created_at" timestamp with time zone default now() not null);
create table "public"."service_records" ("id" uuid default gen_random_uuid() not null,"order_id" uuid,"order_item_id" uuid,"customer_id" uuid,"vehicle_id" uuid not null,"service_type" text not null,"description" text not null,"odometer" integer,"oil_brand" text,"oil_viscosity" text,"oil_quantity_liters" numeric,"oil_filter_code" text,"next_service_odometer" integer,"next_service_date" date,"charged_ref_amount" numeric default 0 not null,"charged_ves_amount" numeric default 0 not null,"performed_at" timestamp with time zone default now() not null,"created_by" uuid default auth.uid(),"created_at" timestamp with time zone default now() not null,"source_system" text,"source_key" text,"source_invoice" text,"service_notes" text,"included_services" text[] default '{}'::text[] not null,"bonuses" text[] default '{}'::text[] not null,"source_payload" jsonb default '{}'::jsonb not null,"imported_at" timestamp with time zone);
create table "public"."integration_sync_state" ("source_key" text not null,"last_verified_at" timestamp with time zone not null,"last_success_payload" jsonb default '{}'::jsonb not null,"updated_at" timestamp with time zone default now() not null);
create table "public"."maintenance_reminder_actions" ("id" uuid default gen_random_uuid() not null,"service_record_id" uuid not null,"status" text default 'PENDING'::text not null,"snoozed_until" date,"sent_at" timestamp with time zone,"last_action_by" uuid,"created_at" timestamp with time zone default now() not null,"updated_at" timestamp with time zone default now() not null);
create table "public"."inventory_items" ("id" uuid default gen_random_uuid() not null,"sku" text not null,"brand" text,"description" text not null,"category" text,"unit" text default 'UND'::text not null,"source_cost_ref" numeric default 0 not null,"source_stock_imported" numeric default 0 not null,"source_alert" text,"source_price_status" text,"source_row" integer,"product_id" uuid,"needs_review" boolean default false not null,"cost_missing" boolean default false not null,"active" boolean default true not null,"source_name" text default 'Inventario LC.xlsx'::text not null,"imported_at" timestamp with time zone default now() not null,"updated_at" timestamp with time zone default now() not null,"source_rows" text,"source_duplicate_count" integer default 1 not null,"average_cost_ref" numeric default 0 not null,"last_purchase_cost_ref" numeric,"last_purchased_at" timestamp with time zone);
create table "public"."customer_followups" ("id" uuid default gen_random_uuid() not null,"order_id" uuid not null,"customer_id" uuid,"vehicle_id" uuid,"followup_type" text default 'POST_SERVICE'::text not null,"channel" text default 'WHATSAPP'::text not null,"status" text default 'PENDING'::text not null,"message" text not null,"sent_at" timestamp with time zone,"snoozed_until" date,"created_at" timestamp with time zone default now() not null,"updated_at" timestamp with time zone default now() not null);
create table "public"."order_history" ("id" uuid default gen_random_uuid() not null,"order_id" uuid not null,"entity_type" text not null,"entity_id" uuid,"action" text not null,"before_data" jsonb,"after_data" jsonb,"reason" text,"actor_id" uuid,"actor_email" text,"recorded_at" timestamp with time zone default clock_timestamp() not null);
create table "public"."data_import_runs" ("id" uuid default gen_random_uuid() not null,"source_system" text not null,"source_name" text,"started_at" timestamp with time zone default now() not null,"finished_at" timestamp with time zone,"staged_rows" integer default 0 not null,"imported_rows" integer default 0 not null,"error_rows" integer default 0 not null,"notes" text);
create table "public"."data_import_issues" ("id" uuid default gen_random_uuid() not null,"source_system" text not null,"source_key" text,"issue_type" text not null,"field_name" text,"raw_value" text,"details" jsonb default '{}'::jsonb not null,"resolved" boolean default false not null,"created_at" timestamp with time zone default now() not null);
create table "public"."customer_external_identities" ("id" uuid default gen_random_uuid() not null,"source_system" text not null,"external_key" text not null,"customer_id" uuid not null,"normalized_document" text,"normalized_phone" text,"first_seen_at" timestamp with time zone,"last_seen_at" timestamp with time zone,"created_at" timestamp with time zone default now() not null,"updated_at" timestamp with time zone default now() not null);
create table "public"."vehicle_plate_aliases" ("id" uuid default gen_random_uuid() not null,"vehicle_id" uuid not null,"source_system" text not null,"alias_plate" text,"normalized_alias" text,"confidence" text default 'SOURCE'::text not null,"first_seen_at" timestamp with time zone,"last_seen_at" timestamp with time zone,"created_at" timestamp with time zone default now() not null);
create table "public"."vehicle_customer_history" ("id" uuid default gen_random_uuid() not null,"vehicle_id" uuid not null,"customer_id" uuid not null,"source_system" text not null,"first_seen_at" timestamp with time zone,"last_seen_at" timestamp with time zone,"created_at" timestamp with time zone default now() not null);
create table "public"."legacy_service_import_stage" ("source_system" text not null,"source_key" text not null,"source_rows" integer[] default '{}'::integer[] not null,"identity_key" text not null,"customer_name" text,"document_id" text,"phone" text,"invoice" text,"raw_plate" text,"canonical_plate" text,"vehicle_make" text,"vehicle_model" text,"vehicle_year" integer,"service_type" text default 'OIL_CHANGE'::text not null,"service_date" date,"submitted_at" timestamp with time zone,"odometer" integer,"raw_odometer" text,"oil_raw" text,"oil_viscosity" text,"oil_filter_code" text,"next_service_odometer" integer,"next_service_date" date,"service_notes" text,"included_services" text[] default '{}'::text[] not null,"bonuses" text[] default '{}'::text[] not null,"source_payload" jsonb default '{}'::jsonb not null,"quality_flags" text[] default '{}'::text[] not null,"import_status" text default 'STAGED'::text not null,"imported_customer_id" uuid,"imported_vehicle_id" uuid,"imported_service_record_id" uuid,"imported_at" timestamp with time zone);
alter table "public"."cashea_sales" add constraint "cashea_sales_pkey" PRIMARY KEY (id);
alter table "public"."cashea_installments" add constraint "cashea_installments_pkey" PRIMARY KEY (id);
alter table "public"."inventory_movements" add constraint "inventory_movements_pkey" PRIMARY KEY (id);
alter table "public"."suppliers" add constraint "suppliers_pkey" PRIMARY KEY (id);
alter table "public"."supplier_invoices" add constraint "supplier_invoices_pkey" PRIMARY KEY (id);
alter table "public"."supplier_invoice_items" add constraint "supplier_invoice_items_pkey" PRIMARY KEY (id);
alter table "public"."supplier_receipts" add constraint "supplier_receipts_pkey" PRIMARY KEY (id);
alter table "public"."supplier_receipt_items" add constraint "supplier_receipt_items_pkey" PRIMARY KEY (id);
alter table "public"."supplier_payments" add constraint "supplier_payments_pkey" PRIMARY KEY (id);
alter table "public"."cash_closings" add constraint "cash_closings_pkey" PRIMARY KEY (id);
alter table "public"."cash_closing_accounts" add constraint "cash_closing_accounts_pkey" PRIMARY KEY (cash_closing_id, account_id);
alter table "public"."products" add constraint "products_pkey" PRIMARY KEY (id);
alter table "public"."app_settings" add constraint "app_settings_pkey" PRIMARY KEY (key);
alter table "public"."locations" add constraint "locations_pkey" PRIMARY KEY (id);
alter table "public"."employees" add constraint "employees_pkey" PRIMARY KEY (id);
alter table "public"."customers" add constraint "customers_pkey" PRIMARY KEY (id);
alter table "public"."vehicles" add constraint "vehicles_pkey" PRIMARY KEY (id);
alter table "public"."exchange_rates" add constraint "exchange_rates_pkey" PRIMARY KEY (id);
alter table "public"."compensation_rules" add constraint "compensation_rules_pkey" PRIMARY KEY (id);
alter table "public"."receivables" add constraint "receivables_pkey" PRIMARY KEY (id);
alter table "public"."integration_events" add constraint "integration_events_pkey" PRIMARY KEY (id);
alter table "public"."audit_events" add constraint "audit_events_pkey" PRIMARY KEY (id);
alter table "public"."payroll_accruals" add constraint "payroll_accruals_pkey" PRIMARY KEY (id);
alter table "public"."payroll_runs" add constraint "payroll_runs_pkey" PRIMARY KEY (id);
alter table "public"."payroll_adjustments" add constraint "payroll_adjustments_pkey" PRIMARY KEY (id);
alter table "public"."payments" add constraint "payments_pkey" PRIMARY KEY (id);
alter table "public"."order_items" add constraint "order_items_pkey" PRIMARY KEY (id);
alter table "public"."orders" add constraint "orders_pkey" PRIMARY KEY (id);
alter table "public"."account_movements" add constraint "account_movements_pkey" PRIMARY KEY (id);
alter table "public"."financial_accounts" add constraint "financial_accounts_pkey" PRIMARY KEY (id);
alter table "public"."service_records" add constraint "service_records_pkey" PRIMARY KEY (id);
alter table "public"."integration_sync_state" add constraint "integration_sync_state_pkey" PRIMARY KEY (source_key);
alter table "public"."maintenance_reminder_actions" add constraint "maintenance_reminder_actions_pkey" PRIMARY KEY (id);
alter table "public"."inventory_items" add constraint "inventory_items_pkey" PRIMARY KEY (id);
alter table "public"."customer_followups" add constraint "customer_followups_pkey" PRIMARY KEY (id);
alter table "public"."order_history" add constraint "order_history_pkey" PRIMARY KEY (id);
alter table "public"."data_import_runs" add constraint "data_import_runs_pkey" PRIMARY KEY (id);
alter table "public"."data_import_issues" add constraint "data_import_issues_pkey" PRIMARY KEY (id);
alter table "public"."customer_external_identities" add constraint "customer_external_identities_pkey" PRIMARY KEY (id);
alter table "public"."vehicle_plate_aliases" add constraint "vehicle_plate_aliases_pkey" PRIMARY KEY (id);
alter table "public"."vehicle_customer_history" add constraint "vehicle_customer_history_pkey" PRIMARY KEY (id);
alter table "public"."legacy_service_import_stage" add constraint "legacy_service_import_stage_pkey" PRIMARY KEY (source_system, source_key);
alter table "public"."cashea_sales" add constraint "cashea_sales_order_id_key" UNIQUE (order_id);
alter table "public"."cashea_sales" add constraint "cashea_sales_receivable_id_key" UNIQUE (receivable_id);
alter table "public"."cashea_installments" add constraint "cashea_installments_cashea_sale_id_installment_no_key" UNIQUE (cashea_sale_id, installment_no);
alter table "public"."supplier_payments" add constraint "supplier_payments_account_movement_id_key" UNIQUE (account_movement_id);
alter table "public"."cash_closings" add constraint "cash_closings_business_date_location_id_key" UNIQUE (business_date, location_id);
alter table "public"."locations" add constraint "locations_code_key" UNIQUE (code);
alter table "public"."employees" add constraint "employees_code_key" UNIQUE (code);
alter table "public"."payroll_accruals" add constraint "payroll_accruals_employee_id_source_order_item_id_source_ty_key" UNIQUE (employee_id, source_order_item_id, source_type);
alter table "public"."payroll_runs" add constraint "payroll_runs_employee_id_period_start_period_end_key" UNIQUE (employee_id, period_start, period_end);
alter table "public"."orders" add constraint "orders_order_seq_key" UNIQUE (order_seq);
alter table "public"."financial_accounts" add constraint "financial_accounts_code_key" UNIQUE (code);
alter table "public"."service_records" add constraint "service_records_order_item_id_key" UNIQUE (order_item_id);
alter table "public"."maintenance_reminder_actions" add constraint "maintenance_reminder_actions_service_record_id_key" UNIQUE (service_record_id);
alter table "public"."inventory_items" add constraint "inventory_items_sku_brand_key" UNIQUE (sku, brand);
alter table "public"."customer_followups" add constraint "customer_followups_order_id_followup_type_key" UNIQUE (order_id, followup_type);
alter table "public"."customer_external_identities" add constraint "customer_external_identities_source_system_external_key_key" UNIQUE (source_system, external_key);
alter table "public"."vehicle_plate_aliases" add constraint "vehicle_plate_aliases_vehicle_id_source_system_normalized_a_key" UNIQUE (vehicle_id, source_system, normalized_alias);
alter table "public"."vehicle_customer_history" add constraint "vehicle_customer_history_vehicle_id_customer_id_source_syst_key" UNIQUE (vehicle_id, customer_id, source_system);
alter table "public"."cashea_sales" add constraint "cashea_sales_bcv_rate_snapshot_check" CHECK ((bcv_rate_snapshot > (0)::numeric));
alter table "public"."cashea_sales" add constraint "cashea_sales_commission_percent_check" CHECK (((commission_percent >= (0)::numeric) AND (commission_percent < (100)::numeric)));
alter table "public"."cashea_sales" add constraint "cashea_sales_commission_ref_check" CHECK ((commission_ref >= (0)::numeric));
alter table "public"."cashea_sales" add constraint "cashea_sales_commission_ves_snapshot_check" CHECK ((commission_ves_snapshot >= (0)::numeric));
alter table "public"."cashea_sales" add constraint "cashea_sales_financed_ref_check" CHECK ((financed_ref >= (0)::numeric));
alter table "public"."cashea_sales" add constraint "cashea_sales_gross_ref_check" CHECK ((gross_ref > (0)::numeric));
alter table "public"."cashea_sales" add constraint "cashea_sales_gross_ves_snapshot_check" CHECK ((gross_ves_snapshot > (0)::numeric));
alter table "public"."cashea_sales" add constraint "cashea_sales_initial_payment_method_check" CHECK ((initial_payment_method = ANY (ARRAY['CASH_USD'::text, 'CASH_VES'::text, 'MOBILE_PAYMENT'::text, 'TRANSFER_BDV'::text, 'TRANSFER_BNC'::text])));
alter table "public"."cashea_sales" add constraint "cashea_sales_initial_percent_check" CHECK (((initial_percent > (0)::numeric) AND (initial_percent <= (100)::numeric)));
alter table "public"."cashea_sales" add constraint "cashea_sales_initial_ref_check" CHECK ((initial_ref > (0)::numeric));
alter table "public"."cashea_sales" add constraint "cashea_sales_initial_ves_snapshot_check" CHECK ((initial_ves_snapshot > (0)::numeric));
alter table "public"."cashea_sales" add constraint "cashea_sales_status_check" CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'SETTLED'::text, 'CANCELLED'::text])));
alter table "public"."cashea_installments" add constraint "cashea_installments_amount_ref_check" CHECK ((amount_ref > (0)::numeric));
alter table "public"."cashea_installments" add constraint "cashea_installments_amount_ves_snapshot_check" CHECK ((amount_ves_snapshot > (0)::numeric));
alter table "public"."cashea_installments" add constraint "cashea_installments_installment_no_check" CHECK (((installment_no >= 1) AND (installment_no <= 3)));
alter table "public"."cashea_installments" add constraint "cashea_installments_paid_ref_check" CHECK ((paid_ref >= (0)::numeric));
alter table "public"."cashea_installments" add constraint "cashea_installments_paid_ves_actual_check" CHECK ((paid_ves_actual >= (0)::numeric));
alter table "public"."cashea_installments" add constraint "cashea_installments_status_check" CHECK ((status = ANY (ARRAY['PENDING'::text, 'PARTIAL'::text, 'PAID'::text])));
alter table "public"."inventory_movements" add constraint "inventory_movements_movement_type_check" CHECK ((movement_type = ANY (ARRAY['OPENING_IMPORT'::text, 'SALE'::text, 'PURCHASE'::text, 'ADJUSTMENT'::text, 'RETURN'::text, 'TRANSFER_IN'::text, 'TRANSFER_OUT'::text])));
alter table "public"."inventory_movements" add constraint "inventory_movements_quantity_delta_check" CHECK ((quantity_delta <> (0)::numeric));
alter table "public"."suppliers" add constraint "suppliers_default_currency_check" CHECK ((default_currency = ANY (ARRAY['USD'::text, 'VES'::text])));
alter table "public"."suppliers" add constraint "suppliers_payment_terms_days_check" CHECK (((payment_terms_days >= 0) AND (payment_terms_days <= 3650)));
alter table "public"."supplier_invoices" add constraint "supplier_invoices_bcv_rate_snapshot_check" CHECK ((bcv_rate_snapshot > (0)::numeric));
alter table "public"."supplier_invoices" add constraint "supplier_invoices_currency_check" CHECK ((currency = ANY (ARRAY['USD'::text, 'VES'::text])));
alter table "public"."supplier_invoices" add constraint "supplier_invoices_discount_original_check" CHECK ((discount_original >= (0)::numeric));
alter table "public"."supplier_invoices" add constraint "supplier_invoices_freight_original_check" CHECK ((freight_original >= (0)::numeric));
alter table "public"."supplier_invoices" add constraint "supplier_invoices_operative_rate_snapshot_check" CHECK ((operative_rate_snapshot > (0)::numeric));
alter table "public"."supplier_invoices" add constraint "supplier_invoices_paid_original_check" CHECK ((paid_original >= (0)::numeric));
alter table "public"."supplier_invoices" add constraint "supplier_invoices_status_check" CHECK ((status = ANY (ARRAY['OPEN'::text, 'PARTIAL'::text, 'PAID'::text, 'VOID'::text])));
alter table "public"."supplier_invoices" add constraint "supplier_invoices_subtotal_original_check" CHECK ((subtotal_original >= (0)::numeric));
alter table "public"."supplier_invoices" add constraint "supplier_invoices_tax_original_check" CHECK ((tax_original >= (0)::numeric));
alter table "public"."supplier_invoices" add constraint "supplier_invoices_total_original_check" CHECK ((total_original >= (0)::numeric));
alter table "public"."supplier_invoice_items" add constraint "supplier_invoice_items_check" CHECK ((((line_type = 'INVENTORY'::text) AND (inventory_item_id IS NOT NULL)) OR (line_type = 'EXPENSE'::text)));
alter table "public"."supplier_invoice_items" add constraint "supplier_invoice_items_check1" CHECK ((received_quantity <= quantity));
alter table "public"."supplier_invoice_items" add constraint "supplier_invoice_items_line_total_original_check" CHECK ((line_total_original >= (0)::numeric));
alter table "public"."supplier_invoice_items" add constraint "supplier_invoice_items_line_type_check" CHECK ((line_type = ANY (ARRAY['INVENTORY'::text, 'EXPENSE'::text])));
alter table "public"."supplier_invoice_items" add constraint "supplier_invoice_items_quantity_check" CHECK ((quantity > (0)::numeric));
alter table "public"."supplier_invoice_items" add constraint "supplier_invoice_items_received_quantity_check" CHECK ((received_quantity >= (0)::numeric));
alter table "public"."supplier_invoice_items" add constraint "supplier_invoice_items_unit_cost_original_check" CHECK ((unit_cost_original >= (0)::numeric));
alter table "public"."supplier_invoice_items" add constraint "supplier_invoice_items_unit_cost_ref_check" CHECK ((unit_cost_ref >= (0)::numeric));
alter table "public"."supplier_receipts" add constraint "supplier_receipts_status_check" CHECK ((status = ANY (ARRAY['POSTED'::text, 'VOID'::text])));
alter table "public"."supplier_receipt_items" add constraint "supplier_receipt_items_quantity_check" CHECK ((quantity > (0)::numeric));
alter table "public"."supplier_receipt_items" add constraint "supplier_receipt_items_unit_cost_ref_check" CHECK ((unit_cost_ref >= (0)::numeric));
alter table "public"."supplier_payments" add constraint "supplier_payments_amount_applied_invoice_check" CHECK ((amount_applied_invoice > (0)::numeric));
alter table "public"."supplier_payments" add constraint "supplier_payments_amount_original_check" CHECK ((amount_original > (0)::numeric));
alter table "public"."supplier_payments" add constraint "supplier_payments_currency_check" CHECK ((currency = ANY (ARRAY['USD'::text, 'VES'::text])));
alter table "public"."supplier_payments" add constraint "supplier_payments_value_ref_check" CHECK ((value_ref > (0)::numeric));
alter table "public"."supplier_payments" add constraint "supplier_payments_value_ves_check" CHECK ((value_ves > (0)::numeric));
alter table "public"."cash_closings" add constraint "cash_closings_status_check" CHECK ((status = ANY (ARRAY['OPEN'::text, 'REVIEW'::text, 'CLOSED'::text, 'REOPENED'::text])));
alter table "public"."products" add constraint "products_cash_usd_base_price_check" CHECK ((cash_usd_base_price >= (0)::numeric));
alter table "public"."exchange_rates" add constraint "exchange_rates_rate_type_check" CHECK ((rate_type = ANY (ARRAY['BCV'::text, 'OPERATIVE'::text])));
alter table "public"."exchange_rates" add constraint "exchange_rates_value_check" CHECK ((value > (0)::numeric));
alter table "public"."compensation_rules" add constraint "compensation_rules_check" CHECK (((valid_to IS NULL) OR (valid_to >= valid_from)));
alter table "public"."compensation_rules" add constraint "compensation_rules_rule_type_check" CHECK ((rule_type = ANY (ARRAY['WORKSHOP_PERCENT'::text, 'ELECTROAUTO_PERCENT'::text, 'ASSISTANT_BONUS_PERCENT'::text, 'FIXED_WEEKLY'::text])));
alter table "public"."compensation_rules" add constraint "compensation_rules_value_check" CHECK ((value >= (0)::numeric));
alter table "public"."receivables" add constraint "receivables_debtor_type_check" CHECK ((debtor_type = ANY (ARRAY['CUSTOMER'::text, 'CASHEA'::text, 'OTHER'::text])));
alter table "public"."receivables" add constraint "receivables_outstanding_ves_check" CHECK ((outstanding_ves >= (0)::numeric));
alter table "public"."receivables" add constraint "receivables_principal_ref_check" CHECK ((principal_ref > (0)::numeric));
alter table "public"."receivables" add constraint "receivables_principal_ves_check" CHECK ((principal_ves > (0)::numeric));
alter table "public"."receivables" add constraint "receivables_status_check" CHECK ((status = ANY (ARRAY['OPEN'::text, 'PAID'::text, 'CANCELLED'::text])));
alter table "public"."integration_events" add constraint "integration_events_status_check" CHECK ((status = ANY (ARRAY['PENDING'::text, 'PROCESSING'::text, 'DONE'::text, 'FAILED'::text])));
alter table "public"."payroll_accruals" add constraint "payroll_accruals_amount_ref_check" CHECK ((amount_ref >= (0)::numeric));
alter table "public"."payroll_accruals" add constraint "payroll_accruals_source_type_check" CHECK ((source_type = ANY (ARRAY['WORKSHOP_COMMISSION'::text, 'ASSISTANT_BONUS'::text, 'ELECTROAUTO_COMMISSION'::text])));
alter table "public"."payroll_runs" add constraint "payroll_runs_check" CHECK ((period_end >= period_start));
alter table "public"."payroll_runs" add constraint "payroll_runs_status_check" CHECK ((status = ANY (ARRAY['SETTLED'::text, 'VOID'::text])));
alter table "public"."payroll_adjustments" add constraint "payroll_adjustments_adjustment_type_check" CHECK ((adjustment_type = ANY (ARRAY['SUPPLIES'::text, 'ADVANCE'::text, 'DEBT'::text, 'BONUS'::text, 'OTHER'::text])));
alter table "public"."payroll_adjustments" add constraint "payroll_adjustments_amount_ref_check" CHECK ((amount_ref <> (0)::numeric));
alter table "public"."payments" add constraint "payments_amount_original_check" CHECK ((amount_original > (0)::numeric));
alter table "public"."payments" add constraint "payments_bcv_rate_snapshot_check" CHECK ((bcv_rate_snapshot > (0)::numeric));
alter table "public"."payments" add constraint "payments_currency_check" CHECK ((currency = ANY (ARRAY['USD'::text, 'VES'::text])));
alter table "public"."payments" add constraint "payments_method_check" CHECK ((method = ANY (ARRAY['CASH_USD'::text, 'CASH_VES'::text, 'MOBILE_PAYMENT'::text, 'TRANSFER_BDV'::text, 'TRANSFER_BNC'::text])));
alter table "public"."payments" add constraint "payments_operative_rate_snapshot_check" CHECK ((operative_rate_snapshot > (0)::numeric));
alter table "public"."payments" add constraint "payments_value_ref_check" CHECK ((value_ref > (0)::numeric));
alter table "public"."payments" add constraint "payments_value_ves_check" CHECK ((value_ves > (0)::numeric));
alter table "public"."order_items" add constraint "order_items_bcv_rate_snapshot_check" CHECK ((bcv_rate_snapshot > (0)::numeric));
alter table "public"."order_items" add constraint "order_items_business_area_check" CHECK ((business_area = ANY (ARRAY['STORE'::text, 'OIL_CHANGE'::text, 'WORKSHOP'::text, 'ELECTROAUTO'::text])));
alter table "public"."order_items" add constraint "order_items_charged_ref_amount_check" CHECK ((charged_ref_amount >= (0)::numeric));
alter table "public"."order_items" add constraint "order_items_charged_ves_amount_check" CHECK ((charged_ves_amount >= (0)::numeric));
alter table "public"."order_items" add constraint "order_items_item_type_check" CHECK ((item_type = ANY (ARRAY['PRODUCT'::text, 'SERVICE'::text])));
alter table "public"."order_items" add constraint "order_items_next_service_odometer_check" CHECK (((next_service_odometer IS NULL) OR (next_service_odometer >= 0)));
alter table "public"."order_items" add constraint "order_items_oil_quantity_liters_check" CHECK (((oil_quantity_liters IS NULL) OR (oil_quantity_liters > (0)::numeric)));
alter table "public"."order_items" add constraint "order_items_operative_rate_snapshot_check" CHECK ((operative_rate_snapshot > (0)::numeric));
alter table "public"."order_items" add constraint "order_items_pricing_mode_check" CHECK ((pricing_mode = ANY (ARRAY['STANDARD'::text, 'CASH_USD_SPECIAL'::text, 'BONUS'::text, 'MANUAL_OVERRIDE'::text, 'MANUAL_NO_STOCK'::text])));
alter table "public"."order_items" add constraint "order_items_quantity_check" CHECK ((quantity > (0)::numeric));
alter table "public"."order_items" add constraint "order_items_service_odometer_check" CHECK (((service_odometer IS NULL) OR (service_odometer >= 0)));
alter table "public"."orders" add constraint "orders_health_status_check" CHECK ((health_status = ANY (ARRAY['GREEN'::text, 'YELLOW'::text, 'RED'::text])));
alter table "public"."orders" add constraint "orders_status_check" CHECK ((status = ANY (ARRAY['OPEN'::text, 'CLOSED'::text, 'CANCELLED'::text])));
alter table "public"."orders" add constraint "orders_workflow_status_check" CHECK ((workflow_status = ANY (ARRAY['RECEIVED'::text, 'DIAGNOSIS'::text, 'IN_PROGRESS'::text, 'WAITING_PART'::text, 'READY'::text, 'DELIVERED'::text])));
alter table "public"."account_movements" add constraint "account_movements_amount_original_check" CHECK ((amount_original > (0)::numeric));
alter table "public"."account_movements" add constraint "account_movements_currency_check" CHECK ((currency = ANY (ARRAY['VES'::text, 'USD'::text])));
alter table "public"."account_movements" add constraint "account_movements_direction_check" CHECK ((direction = ANY (ARRAY['IN'::text, 'OUT'::text])));
alter table "public"."account_movements" add constraint "account_movements_movement_type_check" CHECK ((movement_type = ANY (ARRAY['PAYMENT'::text, 'EXPENSE'::text, 'SUPPLIER_PAYMENT'::text, 'TRANSFER'::text, 'ADJUSTMENT'::text])));
alter table "public"."account_movements" add constraint "account_movements_value_ves_check" CHECK ((value_ves > (0)::numeric));
alter table "public"."financial_accounts" add constraint "financial_accounts_account_type_check" CHECK ((account_type = ANY (ARRAY['CASH'::text, 'BANK'::text, 'CLEARING'::text, 'RELATED'::text])));
alter table "public"."financial_accounts" add constraint "financial_accounts_currency_check" CHECK ((currency = ANY (ARRAY['VES'::text, 'USD'::text])));
alter table "public"."service_records" add constraint "service_records_next_service_odometer_check" CHECK (((next_service_odometer IS NULL) OR (next_service_odometer >= 0)));
alter table "public"."service_records" add constraint "service_records_odometer_check" CHECK (((odometer IS NULL) OR (odometer >= 0)));
alter table "public"."service_records" add constraint "service_records_oil_quantity_liters_check" CHECK (((oil_quantity_liters IS NULL) OR (oil_quantity_liters > (0)::numeric)));
alter table "public"."service_records" add constraint "service_records_service_type_check" CHECK ((service_type = ANY (ARRAY['OIL_CHANGE'::text, 'WORKSHOP'::text, 'ELECTROAUTO'::text, 'OTHER'::text])));
alter table "public"."maintenance_reminder_actions" add constraint "maintenance_reminder_actions_status_check" CHECK ((status = ANY (ARRAY['PENDING'::text, 'SENT'::text, 'SNOOZED'::text])));
alter table "public"."customer_followups" add constraint "customer_followups_channel_check" CHECK ((channel = 'WHATSAPP'::text));
alter table "public"."customer_followups" add constraint "customer_followups_status_check" CHECK ((status = ANY (ARRAY['PENDING'::text, 'SENT'::text, 'SNOOZED'::text])));
alter table "public"."cashea_sales" add constraint "cashea_sales_order_id_fkey" FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE RESTRICT;
alter table "public"."cashea_sales" add constraint "cashea_sales_receivable_id_fkey" FOREIGN KEY (receivable_id) REFERENCES receivables(id) ON DELETE RESTRICT;
alter table "public"."cashea_installments" add constraint "cashea_installments_cashea_sale_id_fkey" FOREIGN KEY (cashea_sale_id) REFERENCES cashea_sales(id) ON DELETE CASCADE;
alter table "public"."inventory_movements" add constraint "inventory_movements_inventory_item_id_fkey" FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT;
alter table "public"."inventory_movements" add constraint "inventory_movements_location_id_fkey" FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE RESTRICT;
alter table "public"."inventory_movements" add constraint "inventory_movements_order_item_id_fkey" FOREIGN KEY (order_item_id) REFERENCES order_items(id) ON DELETE RESTRICT;
alter table "public"."inventory_movements" add constraint "inventory_movements_supplier_receipt_item_id_fkey" FOREIGN KEY (supplier_receipt_item_id) REFERENCES supplier_receipt_items(id) ON DELETE RESTRICT;
alter table "public"."supplier_invoices" add constraint "supplier_invoices_supplier_id_fkey" FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE RESTRICT;
alter table "public"."supplier_invoice_items" add constraint "supplier_invoice_items_inventory_item_id_fkey" FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT;
alter table "public"."supplier_invoice_items" add constraint "supplier_invoice_items_supplier_invoice_id_fkey" FOREIGN KEY (supplier_invoice_id) REFERENCES supplier_invoices(id) ON DELETE CASCADE;
alter table "public"."supplier_receipts" add constraint "supplier_receipts_location_id_fkey" FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE RESTRICT;
alter table "public"."supplier_receipts" add constraint "supplier_receipts_supplier_invoice_id_fkey" FOREIGN KEY (supplier_invoice_id) REFERENCES supplier_invoices(id) ON DELETE RESTRICT;
alter table "public"."supplier_receipt_items" add constraint "supplier_receipt_items_inventory_item_id_fkey" FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT;
alter table "public"."supplier_receipt_items" add constraint "supplier_receipt_items_supplier_invoice_item_id_fkey" FOREIGN KEY (supplier_invoice_item_id) REFERENCES supplier_invoice_items(id) ON DELETE RESTRICT;
alter table "public"."supplier_receipt_items" add constraint "supplier_receipt_items_supplier_receipt_id_fkey" FOREIGN KEY (supplier_receipt_id) REFERENCES supplier_receipts(id) ON DELETE CASCADE;
alter table "public"."supplier_payments" add constraint "supplier_payments_account_id_fkey" FOREIGN KEY (account_id) REFERENCES financial_accounts(id) ON DELETE RESTRICT;
alter table "public"."supplier_payments" add constraint "supplier_payments_account_movement_id_fkey" FOREIGN KEY (account_movement_id) REFERENCES account_movements(id) ON DELETE RESTRICT;
alter table "public"."supplier_payments" add constraint "supplier_payments_supplier_invoice_id_fkey" FOREIGN KEY (supplier_invoice_id) REFERENCES supplier_invoices(id) ON DELETE RESTRICT;
alter table "public"."cash_closings" add constraint "cash_closings_location_id_fkey" FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE RESTRICT;
alter table "public"."cash_closing_accounts" add constraint "cash_closing_accounts_account_id_fkey" FOREIGN KEY (account_id) REFERENCES financial_accounts(id) ON DELETE RESTRICT;
alter table "public"."cash_closing_accounts" add constraint "cash_closing_accounts_cash_closing_id_fkey" FOREIGN KEY (cash_closing_id) REFERENCES cash_closings(id) ON DELETE CASCADE;
alter table "public"."vehicles" add constraint "vehicles_customer_id_fkey" FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL;
alter table "public"."compensation_rules" add constraint "compensation_rules_employee_id_fkey" FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE;
alter table "public"."receivables" add constraint "receivables_customer_id_fkey" FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL;
alter table "public"."receivables" add constraint "receivables_order_id_fkey" FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE RESTRICT;
alter table "public"."payroll_accruals" add constraint "payroll_accruals_employee_id_fkey" FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE RESTRICT;
alter table "public"."payroll_accruals" add constraint "payroll_accruals_payroll_run_id_fkey" FOREIGN KEY (payroll_run_id) REFERENCES payroll_runs(id) ON DELETE SET NULL;
alter table "public"."payroll_accruals" add constraint "payroll_accruals_source_order_item_id_fkey" FOREIGN KEY (source_order_item_id) REFERENCES order_items(id) ON DELETE RESTRICT;
alter table "public"."payroll_runs" add constraint "payroll_runs_employee_id_fkey" FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE RESTRICT;
alter table "public"."payroll_adjustments" add constraint "payroll_adjustments_employee_id_fkey" FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE RESTRICT;
alter table "public"."payroll_adjustments" add constraint "payroll_adjustments_payroll_run_id_fkey" FOREIGN KEY (payroll_run_id) REFERENCES payroll_runs(id) ON DELETE SET NULL;
alter table "public"."payments" add constraint "payments_financial_account_id_fkey" FOREIGN KEY (financial_account_id) REFERENCES financial_accounts(id);
alter table "public"."payments" add constraint "payments_order_id_fkey" FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE;
alter table "public"."payments" add constraint "payments_receivable_id_fkey" FOREIGN KEY (receivable_id) REFERENCES receivables(id);
alter table "public"."order_items" add constraint "order_items_assistant_bonus_employee_id_fkey" FOREIGN KEY (assistant_bonus_employee_id) REFERENCES employees(id) ON DELETE SET NULL;
alter table "public"."order_items" add constraint "order_items_inventory_item_id_fkey" FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT;
alter table "public"."order_items" add constraint "order_items_inventory_location_id_fkey" FOREIGN KEY (inventory_location_id) REFERENCES locations(id) ON DELETE RESTRICT;
alter table "public"."order_items" add constraint "order_items_order_id_fkey" FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE;
alter table "public"."order_items" add constraint "order_items_product_id_fkey" FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL;
alter table "public"."order_items" add constraint "order_items_worker_employee_id_fkey" FOREIGN KEY (worker_employee_id) REFERENCES employees(id) ON DELETE SET NULL;
alter table "public"."orders" add constraint "orders_corrects_order_id_fkey" FOREIGN KEY (corrects_order_id) REFERENCES orders(id);
alter table "public"."orders" add constraint "orders_customer_id_fkey" FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL;
alter table "public"."orders" add constraint "orders_location_id_fkey" FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE SET NULL;
alter table "public"."orders" add constraint "orders_vehicle_id_fkey" FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL;
alter table "public"."account_movements" add constraint "account_movements_account_id_fkey" FOREIGN KEY (account_id) REFERENCES financial_accounts(id);
alter table "public"."account_movements" add constraint "account_movements_source_payment_id_fkey" FOREIGN KEY (source_payment_id) REFERENCES payments(id) ON DELETE CASCADE;
alter table "public"."service_records" add constraint "service_records_customer_id_fkey" FOREIGN KEY (customer_id) REFERENCES customers(id);
alter table "public"."service_records" add constraint "service_records_order_id_fkey" FOREIGN KEY (order_id) REFERENCES orders(id);
alter table "public"."service_records" add constraint "service_records_order_item_id_fkey" FOREIGN KEY (order_item_id) REFERENCES order_items(id);
alter table "public"."service_records" add constraint "service_records_vehicle_id_fkey" FOREIGN KEY (vehicle_id) REFERENCES vehicles(id);
alter table "public"."maintenance_reminder_actions" add constraint "maintenance_reminder_actions_service_record_id_fkey" FOREIGN KEY (service_record_id) REFERENCES service_records(id) ON DELETE CASCADE;
alter table "public"."inventory_items" add constraint "inventory_items_product_id_fkey" FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL;
alter table "public"."customer_followups" add constraint "customer_followups_customer_id_fkey" FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL;
alter table "public"."customer_followups" add constraint "customer_followups_order_id_fkey" FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE;
alter table "public"."customer_followups" add constraint "customer_followups_vehicle_id_fkey" FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL;
alter table "public"."customer_external_identities" add constraint "customer_external_identities_customer_id_fkey" FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE;
alter table "public"."vehicle_plate_aliases" add constraint "vehicle_plate_aliases_vehicle_id_fkey" FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE;
alter table "public"."vehicle_customer_history" add constraint "vehicle_customer_history_customer_id_fkey" FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE;
alter table "public"."vehicle_customer_history" add constraint "vehicle_customer_history_vehicle_id_fkey" FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE;
CREATE OR REPLACE FUNCTION lubricenter_private.require_order_admin()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
 if not lubricenter_private.is_order_admin() then raise exception 'Solo lubricenterc@gmail.com puede modificar o anular ventas cerradas'; end if;
end $function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.is_order_admin()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$
 select exists(select 1 from auth.users where id=auth.uid() and lower(email)='lubricenterc@gmail.com' and email_confirmed_at is not null)
$function$
;
CREATE OR REPLACE FUNCTION public.can_administer_orders()
 RETURNS boolean
 LANGUAGE sql
 STABLE
 SET search_path TO ''
AS $function$ select lubricenter_private.is_order_admin() $function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.capture_order_history()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare b jsonb; a jsonb; d jsonb; oid uuid; actor text;
begin
 if TG_OP<>'INSERT' then b:=to_jsonb(old); end if;
 if TG_OP<>'DELETE' then a:=to_jsonb(new); end if;
 d:=coalesce(a,b);
 if TG_TABLE_NAME='orders' then oid:=(d->>'id')::uuid;
 elsif d ? 'order_id' then oid:=(d->>'order_id')::uuid;
 elsif TG_TABLE_NAME='inventory_movements' then select order_id into oid from public.order_items where id=(d->>'order_item_id')::uuid;
 elsif TG_TABLE_NAME='account_movements' then
  select order_id into oid from public.payments where id=(d->>'source_payment_id')::uuid;
  oid:=coalesce(oid,nullif(current_setting('lubricenter.order_id',true),'')::uuid);
 elsif TG_TABLE_NAME='payroll_accruals' then select order_id into oid from public.order_items where id=(d->>'source_order_item_id')::uuid;
 elsif TG_TABLE_NAME='cashea_installments' then select order_id into oid from public.cashea_sales where id=(d->>'cashea_sale_id')::uuid;
 else oid:=nullif(current_setting('lubricenter.order_id',true),'')::uuid;
 end if;
 if oid is not null and a is distinct from b then
  select email into actor from auth.users where id=auth.uid();
  insert into public.order_history(order_id,entity_type,entity_id,action,before_data,after_data,reason,actor_id,actor_email)
  values(oid,TG_TABLE_NAME,(d->>'id')::uuid,TG_OP,b,a,nullif(current_setting('lubricenter.reason',true),''),auth.uid(),actor);
 end if;
 return coalesce(new,old);
end $function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.immutable_history()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$ begin raise exception 'El historial de movimientos no se puede modificar ni borrar'; end $function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.guard_closed_edits()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare oid uuid; s text;
begin
 if TG_TABLE_NAME='orders' then s:=old.status;
 else oid:=coalesce(new.order_id,old.order_id); select status into s from public.orders where id=oid for update;
 end if;
 if s in ('CLOSED','CANCELLED') then perform lubricenter_private.require_order_admin(); end if;
 return coalesce(new,old);
end $function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.apply_business_date()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare d timestamptz; s text;
begin
 if TG_TABLE_NAME='orders' then
  if TG_OP='INSERT' then
   new.business_at:=coalesce(new.business_at,nullif(current_setting('lubricenter.business_at',true),'')::timestamptz);
   if new.business_at is not null then new.opened_at:=new.business_at; end if;
  end if;
  if new.business_at>now()+interval '5 minutes' then raise exception 'La fecha de venta no puede estar en el futuro'; end if;
  if new.status='CLOSED' and new.business_at is not null then new.closed_at:=new.business_at; end if;
 elsif TG_TABLE_NAME='payments' then
  select business_at,status into d,s from public.orders where id=new.order_id;
  if s='OPEN' and d is not null and coalesce(current_setting('lubricenter.revision',true),'')<>'yes' then new.paid_at:=d; end if;
 elsif TG_TABLE_NAME='payroll_accruals' then
  select coalesce(o.business_at,o.closed_at),o.corrects_order_id::text into d,s from public.orders o join public.order_items i on i.order_id=o.id where i.id=new.source_order_item_id;
  if s is null and d is not null then new.occurred_at:=d; end if;
 end if;
 return new;
end $function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.set_order_date(p_order_id uuid, p_business_at timestamp with time zone)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
 perform public.require_auth(); perform public.assert_order_open(p_order_id);
 if p_business_at is null or p_business_at>now()+interval '5 minutes' then raise exception 'Indica la fecha real de la venta, sin fechas futuras'; end if;
 perform set_config('lubricenter.reason','Fecha de venta indicada por el usuario',true);
 update public.orders set business_at=p_business_at,opened_at=p_business_at where id=p_order_id;
 update public.payments set paid_at=p_business_at where order_id=p_order_id;
 update public.account_movements set occurred_at=p_business_at where source_payment_id in (select id from public.payments where order_id=p_order_id);
end $function$
;
CREATE OR REPLACE FUNCTION public.set_order_date(p_order_id uuid, p_business_at timestamp with time zone)
 RETURNS void
 LANGUAGE sql
 SET search_path TO ''
AS $function$ select lubricenter_private.set_order_date(p_order_id,p_business_at) $function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.create_order_dated(p_business_at timestamp with time zone DEFAULT NULL::timestamp with time zone)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare r record; begin
 perform public.require_auth(); perform set_config('lubricenter.business_at',coalesce(p_business_at::text,''),true);
 select * into r from public.create_order(); return to_jsonb(r);
end $function$
;
CREATE OR REPLACE FUNCTION public.create_order_dated(p_business_at timestamp with time zone DEFAULT NULL::timestamp with time zone)
 RETURNS jsonb
 LANGUAGE sql
 SET search_path TO ''
AS $function$ select lubricenter_private.create_order_dated(p_business_at) $function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.quick_sale_dated(p_items jsonb, p_mode text, p_business_at timestamp with time zone DEFAULT NULL::timestamp with time zone, p_method text DEFAULT 'MOBILE_PAYMENT'::text, p_reference text DEFAULT NULL::text, p_initial_percent numeric DEFAULT 40, p_cashea_reference text DEFAULT NULL::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare r record; d date; begin
 perform public.require_auth(); perform set_config('lubricenter.business_at',coalesce(p_business_at::text,''),true);
 if p_mode='DIRECT' then select * into r from public.complete_quick_sale(p_items,p_method,p_reference);
 elsif p_mode='CASHEA' then
  select * into r from public.complete_quick_sale_cashea(p_items,p_initial_percent,p_method,p_reference,p_cashea_reference);
  d:=(coalesce(p_business_at,now()) at time zone 'America/Caracas')::date;
  update public.cashea_installments set due_date=d+installment_no*14 where cashea_sale_id=r.cashea_sale_id;
 elsif p_mode='DRAFT' then select * into r from public.build_quick_sale_order(p_items);
 else raise exception 'Tipo de venta inválido'; end if;
 return to_jsonb(r);
end $function$
;
CREATE OR REPLACE FUNCTION public.quick_sale_dated(p_items jsonb, p_mode text, p_business_at timestamp with time zone DEFAULT NULL::timestamp with time zone, p_method text DEFAULT 'MOBILE_PAYMENT'::text, p_reference text DEFAULT NULL::text, p_initial_percent numeric DEFAULT 40, p_cashea_reference text DEFAULT NULL::text)
 RETURNS jsonb
 LANGUAGE sql
 SET search_path TO ''
AS $function$ select lubricenter_private.quick_sale_dated(p_items,p_mode,p_business_at,p_method,p_reference,p_initial_percent,p_cashea_reference) $function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.cancel_order(p_order_id uuid, p_reason text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare o public.orders; m record; a record;
begin
 perform lubricenter_private.require_order_admin();
 if length(trim(coalesce(p_reason,'')))<5 then raise exception 'Explica el motivo de la anulación (al menos 5 caracteres)'; end if;
 select * into o from public.orders where id=p_order_id for update;
 if not found then raise exception 'Venta no encontrada'; end if;
 if o.status='CANCELLED' then return; end if;
 -- Lock installment writers too; their functions lock installment then sale.
 perform 1 from public.cashea_installments where cashea_sale_id in(select id from public.cashea_sales where order_id=p_order_id) order by id for update;
 perform 1 from public.cashea_sales where order_id=p_order_id for update;
 perform 1 from public.receivables where order_id=p_order_id for update;
 perform set_config('lubricenter.order_id',p_order_id::text,true);
 perform set_config('lubricenter.reason',trim(p_reason),true);
 for m in select im.* from public.inventory_movements im join public.order_items i on i.id=im.order_item_id where i.order_id=p_order_id and im.movement_type='SALE' loop
  insert into public.inventory_movements(inventory_item_id,location_id,quantity_delta,movement_type,order_item_id,note)
  values(m.inventory_item_id,m.location_id,-m.quantity_delta,'RETURN',m.order_item_id,'Anulación '||o.order_number||': '||p_reason);
 end loop;
 for m in select am.* from public.account_movements am join public.payments p on p.id=am.source_payment_id where p.order_id=p_order_id loop
  insert into public.account_movements(account_id,direction,movement_type,currency,amount_original,value_ves,category,note,reference,occurred_at)
  values(m.account_id,case when m.direction='IN' then 'OUT' else 'IN' end,'ADJUSTMENT',m.currency,m.amount_original,m.value_ves,'ORDER_REVERSAL','Anulación '||o.order_number||': '||p_reason,m.id::text,m.occurred_at);
 end loop;
 for a in select pa.* from public.payroll_accruals pa join public.order_items i on i.id=pa.source_order_item_id where i.order_id=p_order_id for update of pa loop
  if a.payroll_run_id is null then delete from public.payroll_accruals where id=a.id;
  elsif a.amount_ref>0 then
   insert into public.payroll_adjustments(employee_id,adjustment_type,amount_ref,note,occurred_on)
   values(a.employee_id,'OTHER',-a.amount_ref,'Reversión de comisión liquidada · '||o.order_number||' · '||p_reason,(now() at time zone 'America/Caracas')::date);
  end if;
 end loop;
 update public.receivables set status='CANCELLED',outstanding_ves=0,closed_at=now() where order_id=p_order_id;
 update public.cashea_sales set status='CANCELLED' where order_id=p_order_id;
 -- Suppress pending CRM without pretending that a message was sent.
 delete from public.customer_followups where order_id=p_order_id and status<>'SENT';
 update public.orders set status='CANCELLED',cancellation_reason=trim(p_reason),cancelled_at=now() where id=p_order_id;
 insert into public.audit_events(event_type,entity_type,entity_id,data) values('order.cancelled','order',p_order_id,jsonb_build_object('reason',p_reason,'cash_and_stock_reversed',true));
end $function$
;
CREATE OR REPLACE FUNCTION public.cancel_order(p_order_id uuid, p_reason text)
 RETURNS void
 LANGUAGE sql
 SET search_path TO ''
AS $function$ select lubricenter_private.cancel_order(p_order_id,p_reason) $function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.correct_closed_order(p_order_id uuid, p_reason text, p_business_at timestamp with time zone, p_items jsonb, p_payments jsonb, p_customer_id uuid, p_vehicle_id uuid)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare o public.orders; n uuid; i public.order_items; ni public.order_items; p public.payments; np public.payments;
 x jsonb; q numeric; u numeric; ratio numeric; tv numeric; tr numeric; pv numeric; initial_paid numeric;
 cs public.cashea_sales; ns public.cashea_sales; ci public.cashea_installments; ci_id uuid; instmap jsonb:='{}';
 lc public.receivables; new_lc uuid; inst_id uuid; new_sale uuid; part numeric; amount numeric; fin numeric; paidinst numeric;
begin
 perform lubricenter_private.require_order_admin();
 select * into o from public.orders where id=p_order_id for update;
 if not found then raise exception 'Orden no encontrada'; end if;
 if o.status='CANCELLED' then
  select id into n from public.orders where corrects_order_id=p_order_id;
  if n is not null then return n; end if;
 end if;
 if o.status<>'CLOSED' then raise exception 'Solo se corrigen ventas cerradas'; end if;
 if p_business_at is null or p_business_at>now()+interval '5 minutes' then raise exception 'Indica la fecha real de la venta'; end if;
 if jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'La corrección necesita al menos una línea. Si no hubo venta, usa Anular'; end if;
 if jsonb_typeof(p_payments)<>'array' then raise exception 'Revisa los pagos'; end if;
 if p_vehicle_id is not null and not exists(select 1 from public.vehicles where id=p_vehicle_id and customer_id=p_customer_id) then raise exception 'El vehículo no pertenece al cliente seleccionado'; end if;
 perform 1 from public.cashea_installments where cashea_sale_id in(select id from public.cashea_sales where order_id=p_order_id) order by id for update;
 select * into cs from public.cashea_sales where order_id=p_order_id for update;
 select * into lc from public.receivables where order_id=p_order_id for update;
 perform lubricenter_private.cancel_order(p_order_id,p_reason);
 perform set_config('lubricenter.revision','yes',true);
 insert into public.orders(customer_id,vehicle_id,location_id,business_at,corrects_order_id,health_status,health_notes,health_reviewed_at,crm_additional_services,crm_bonuses,crm_observations)
 values(p_customer_id,p_vehicle_id,o.location_id,p_business_at,o.id,o.health_status,o.health_notes,o.health_reviewed_at,o.crm_additional_services,o.crm_bonuses,o.crm_observations) returning id into n;
 perform set_config('lubricenter.order_id',n::text,true);
 if (select count(*) from jsonb_array_elements(p_items))<>(select count(distinct value->>'source_id') from jsonb_array_elements(p_items)) then raise exception 'Hay líneas duplicadas en la corrección'; end if;
 for x in select value from jsonb_array_elements(p_items) loop
  select * into i from public.order_items where id=(x->>'source_id')::uuid and order_id=o.id;
  if not found then raise exception 'Una línea no pertenece a la venta original'; end if;
  q:=(x->>'quantity')::numeric; u:=(x->>'unit_ref')::numeric;
  if q is null or q<=0 or u is null or u<0 or q::text in ('NaN','Infinity','-Infinity') or u::text in ('NaN','Infinity','-Infinity') then raise exception 'Cantidad o precio inválido'; end if;
  ni:=i; ni.id:=gen_random_uuid(); ni.order_id:=n; ni.created_at:=now(); ni.quantity:=q; ni.description:=trim(x->>'description');
  if coalesce(ni.description,'')='' then raise exception 'Escribe la descripción de cada línea'; end if;
  if abs(q-i.quantity)>0.000001 or abs(u-i.charged_ref_amount/i.quantity)>0.000001 then
   ni.charged_ref_amount:=round(q*u,4); ni.charged_ves_amount:=round(ni.charged_ref_amount*i.bcv_rate_snapshot,2);
   ni.customer_ref_amount:=ni.charged_ref_amount; ni.base_ref_amount:=ni.charged_ref_amount;
   ni.pricing_mode:=case when i.pricing_mode='MANUAL_NO_STOCK' then i.pricing_mode else 'MANUAL_OVERRIDE' end;
   ni.cash_usd_special_total:=null; ni.cash_price_revealed:=false;
   ratio:=case when i.charged_ref_amount>0 then ni.charged_ref_amount/i.charged_ref_amount else q/i.quantity end;
   ni.worker_share_ref_snapshot:=round(i.worker_share_ref_snapshot*ratio,4); ni.assistant_bonus_ref_snapshot:=round(i.assistant_bonus_ref_snapshot*ratio,4);
  end if;
  insert into public.order_items select ni.*;
 end loop;
 select sum(charged_ves_amount),sum(charged_ref_amount) into tv,tr from public.order_items where order_id=n;
 if tv<=0 then raise exception 'El total debe ser mayor que cero'; end if;
 if cs.id is not null then
  ns:=cs; ns.id:=gen_random_uuid(); ns.order_id:=n; ns.created_at:=now(); ns.created_by:=auth.uid(); ns.receivable_id:=null;
  ns.gross_ref:=tr; ns.gross_ves_snapshot:=tv; ns.initial_ref:=round(tr*cs.initial_percent/100,4); ns.initial_ves_snapshot:=round(ns.initial_ref*cs.bcv_rate_snapshot,2);
  ns.financed_ref:=tr-ns.initial_ref; ns.commission_ref:=round(tr*cs.commission_percent/100,4); ns.commission_ves_snapshot:=round(ns.commission_ref*cs.bcv_rate_snapshot,2);
  ns.status:='ACTIVE'; ns.settled_at:=null; insert into public.cashea_sales select ns.*; new_sale:=ns.id;
  part:=round(ns.financed_ref/3,4);
  for ci in select * from public.cashea_installments where cashea_sale_id=cs.id order by installment_no loop
   amount:=case when ci.installment_no=3 then ns.financed_ref-2*part else part end;
   if amount+0.0001<ci.paid_ref then raise exception 'La cuota % ya recibió REF %. No puedes reducirla por debajo de ese pago',ci.installment_no,ci.paid_ref; end if;
   ci_id:=gen_random_uuid(); instmap:=instmap||jsonb_build_object(ci.id::text,ci_id);
   insert into public.cashea_installments(id,cashea_sale_id,installment_no,due_date,amount_ref,amount_ves_snapshot,paid_ref,paid_ves_actual,status,paid_at)
   values(ci_id,new_sale,ci.installment_no,(p_business_at at time zone 'America/Caracas')::date+ci.installment_no*14,amount,round(amount*cs.bcv_rate_snapshot,2),ci.paid_ref,ci.paid_ves_actual,case when amount-ci.paid_ref<=0.05 then 'PAID' when ci.paid_ref>0 then 'PARTIAL' else 'PENDING' end,ci.paid_at);
  end loop;
 end if;
 if (select count(*) from jsonb_array_elements(p_payments))<>(select count(distinct value->>'source_id') from jsonb_array_elements(p_payments)) then raise exception 'Hay pagos duplicados'; end if;
 initial_paid:=0;
 for x in select value from jsonb_array_elements(p_payments) loop
  select * into p from public.payments where id=(x->>'source_id')::uuid and order_id=o.id;
  if not found then raise exception 'Un pago no pertenece a la venta original'; end if;
  select entity_id into inst_id from public.audit_events where event_type='cashea.installment_payment_recorded' and data->>'payment_id'=p.id::text limit 1;
  if inst_id is not null and ((x->>'method') is distinct from p.method or (x->>'amount_original')::numeric<>p.amount_original) then raise exception 'Los pagos de cuotas Cashea se conservan: corrige la inicial, no una cuota ya recibida'; end if;
  np:=p; np.id:=gen_random_uuid(); np.order_id:=n; np.receivable_id:=null; np.created_at:=now(); np.created_by:=auth.uid();
  np.method:=x->>'method'; np.amount_original:=(x->>'amount_original')::numeric; np.reference:=nullif(trim(x->>'reference'),'');
  if np.amount_original is null or np.amount_original<=0 or np.amount_original::text in ('NaN','Infinity','-Infinity') then raise exception 'Monto de pago inválido'; end if;
  if np.method<>p.method or np.amount_original<>p.amount_original then
   np.currency:=case when np.method='CASH_USD' then 'USD' else 'VES' end;
   np.financial_account_id:=null;
   np.value_ves:=case when np.currency='USD' then round(np.amount_original*case when cs.id is not null then p.bcv_rate_snapshot else p.operative_rate_snapshot end,2) else np.amount_original end;
   np.value_ref:=round(np.value_ves/p.bcv_rate_snapshot,4);
  end if;
  if inst_id is null and p.receivable_id is null then np.paid_at:=p_business_at; end if;
  insert into public.payments select np.*;
  if inst_id is not null then
   if instmap->>inst_id::text is null then raise exception 'No se encontró la cuota original del pago'; end if;
   insert into public.audit_events(event_type,entity_type,entity_id,data) values('cashea.installment_payment_recorded','cashea_installment',(instmap->>inst_id::text)::uuid,jsonb_build_object('payment_id',np.id,'copied_from_payment_id',p.id,'value_ref',np.value_ref));
  else initial_paid:=initial_paid+np.value_ves; end if;
 end loop;
 if exists(select 1 from public.payments pay join public.audit_events a on a.event_type='cashea.installment_payment_recorded' and a.data->>'payment_id'=pay.id::text where pay.order_id=o.id and not exists(select 1 from jsonb_array_elements(p_payments) element where element.value->>'source_id'=pay.id::text)) then raise exception 'Conserva todos los pagos de cuotas Cashea ya recibidas'; end if;
 select coalesce(sum(value_ves),0) into pv from public.payments where order_id=n;
 if cs.id is null then
  if lc.id is not null then perform public.close_order_with_credit(n,lc.due_date); else perform public.close_order(n); end if;
 else
  if abs(initial_paid-ns.initial_ves_snapshot)>1 then raise exception 'Ajusta los pagos de la inicial a Bs % (inicial original de % por ciento)',ns.initial_ves_snapshot,cs.initial_percent; end if;
  perform public.validate_order_ready_to_close(n);
  update public.orders set status='CLOSED',closed_at=p_business_at,total_ves=tv,total_ref=tr,total_cash_usd_equivalent=(select sum(charged_ves_amount/operative_rate_snapshot) from public.order_items where order_id=n) where id=n;
  for i in select * from public.order_items where order_id=n loop
   if i.business_area in ('WORKSHOP','ELECTROAUTO') and coalesce(i.worker_share_ref_snapshot,0)>0 then insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description) values(i.worker_employee_id,i.id,case when i.business_area='WORKSHOP' then 'WORKSHOP_COMMISSION' else 'ELECTROAUTO_COMMISSION' end,i.worker_share_ref_snapshot,'Corrección · '||i.description); end if;
   if i.business_area='WORKSHOP' and coalesce(i.assistant_bonus_ref_snapshot,0)>0 then insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description) values(i.assistant_bonus_employee_id,i.id,'ASSISTANT_BONUS',i.assistant_bonus_ref_snapshot,'Corrección · '||i.description); end if;
  end loop;
  select coalesce(sum(greatest(amount_ref-paid_ref,0)),0) into fin from public.cashea_installments where cashea_sale_id=new_sale;
  update public.cashea_sales set status=case when fin<=0.05 then 'SETTLED' else 'ACTIVE' end,settled_at=case when fin<=0.05 then now() end where id=new_sale;
 end if;
 insert into public.audit_events(event_type,entity_type,entity_id,data) values('order.corrected','order',o.id,jsonb_build_object('replacement_order_id',n,'reason',p_reason));
 return n;
end $function$
;
CREATE OR REPLACE FUNCTION public.correct_closed_order(p_order_id uuid, p_reason text, p_business_at timestamp with time zone, p_items jsonb, p_payments jsonb, p_customer_id uuid, p_vehicle_id uuid)
 RETURNS uuid
 LANGUAGE sql
 SET search_path TO ''
AS $function$ select lubricenter_private.correct_closed_order(p_order_id,p_reason,p_business_at,p_items,p_payments,p_customer_id,p_vehicle_id) $function$
;
CREATE OR REPLACE FUNCTION public.search_order_admin(p_query text DEFAULT ''::text, p_status text DEFAULT 'ALL'::text, p_from date DEFAULT NULL::date, p_to date DEFAULT NULL::date, p_page integer DEFAULT 0)
 RETURNS jsonb
 LANGUAGE sql
 STABLE
 SET search_path TO ''
AS $function$
 with rows as (
  select o.id,o.order_number,o.status,coalesce(o.business_at,o.closed_at,o.opened_at) sale_at,o.created_at,o.corrects_order_id,o.cancellation_reason,
   c.name customer_name,v.plate,
   case when exists(select 1 from public.order_items i where i.order_id=o.id and i.item_type='SERVICE') then 'Orden de servicio' else 'Venta' end kind,
   (select coalesce(sum(charged_ref_amount),0) from public.order_items i where i.order_id=o.id) total_ref,
   (select coalesce(sum(charged_ves_amount),0) from public.order_items i where i.order_id=o.id) total_ves,
   case when cs.id is not null then 'Cashea' when r.id is not null then 'Crédito LC' else 'Contado / mixto' end payment_type
  from public.orders o left join public.customers c on c.id=o.customer_id left join public.vehicles v on v.id=o.vehicle_id
  left join public.cashea_sales cs on cs.order_id=o.id left join public.receivables r on r.order_id=o.id
  where (p_status='ALL' or o.status=p_status)
   and (p_from is null or coalesce(o.business_at,o.closed_at,o.opened_at)>=(p_from::timestamp at time zone 'America/Caracas'))
   and (p_to is null or coalesce(o.business_at,o.closed_at,o.opened_at)<((p_to+1)::timestamp at time zone 'America/Caracas'))
   and (trim(p_query)='' or concat_ws(' ',o.order_number,c.name,c.phone,v.plate,v.make,v.model) ilike '%'||trim(p_query)||'%')
 ) select jsonb_build_object('count',(select count(*) from rows),'rows',coalesce((select jsonb_agg(r) from (select * from rows order by sale_at desc,id limit 30 offset greatest(p_page,0)*30) r),'[]'::jsonb))
$function$
;
CREATE OR REPLACE FUNCTION public.order_installment_payment_ids(p_order_id uuid)
 RETURNS jsonb
 LANGUAGE sql
 STABLE
 SET search_path TO ''
AS $function$
 select coalesce(jsonb_agg(p.id),'[]'::jsonb) from public.payments p where p.order_id=p_order_id and exists(select 1 from public.audit_events a where a.event_type='cashea.installment_payment_recorded' and a.data->>'payment_id'=p.id::text)
$function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.close_order_cashea(p_order_id uuid, p_initial_percent numeric, p_initial_payment_method text, p_payment_reference text DEFAULT NULL::text, p_cashea_reference text DEFAULT NULL::text, p_expected_total_ves numeric DEFAULT NULL::numeric, p_expected_total_ref numeric DEFAULT NULL::numeric, p_expected_bcv numeric DEFAULT NULL::numeric)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare
  v_order public.orders; v_sale uuid; v_total_ref numeric; v_total_ves numeric;
  v_bcv numeric; v_op numeric; v_paid numeric; v_initial_ref numeric; v_initial_ves numeric;
  v_extra numeric; v_financed numeric; v_commission numeric; v_min numeric;
  v_method text := upper(coalesce(p_initial_payment_method,''));
  v_part numeric; v_date date := (now() at time zone 'America/Caracas')::date;
  i public.order_items;
begin
  perform public.require_auth();
  select * into v_order from public.orders where id=p_order_id for update;
  if not found then raise exception 'Orden no encontrada'; end if;
  select id into v_sale from public.cashea_sales where order_id=p_order_id;
  if v_sale is not null then return v_sale; end if;
  if v_order.status <> 'OPEN' then raise exception 'La orden ya está cerrada o cancelada'; end if;
  v_date := (coalesce(v_order.business_at,now()) at time zone 'America/Caracas')::date;
  perform public.validate_order_ready_to_close(p_order_id);
  if exists(select 1 from public.receivables where order_id=p_order_id) then raise exception 'La orden ya tiene Crédito LC. Revisa el registro antes de usar Cashea'; end if;
  if p_initial_percent is null or p_initial_percent <= 0 or p_initial_percent > 100 or p_initial_percent::text in ('NaN','Infinity','-Infinity') then raise exception 'Indica una inicial mayor que 0 y hasta 100 por ciento'; end if;
  if v_method not in ('CASH_USD','CASH_VES','MOBILE_PAYMENT','TRANSFER_BDV','TRANSFER_BNC') then raise exception 'Selecciona cómo recibiste la inicial'; end if;
  select coalesce(sum(charged_ref_amount),0),coalesce(sum(charged_ves_amount),0) into v_total_ref,v_total_ves from public.order_items where order_id=p_order_id;
  if v_total_ves<=0 then raise exception 'Agrega productos o trabajos antes de cobrar'; end if;
  if p_expected_total_ves is null or p_expected_total_ref is null or abs(p_expected_total_ves-v_total_ves)>0.01 or abs(p_expected_total_ref-v_total_ref)>0.0001 then raise exception 'El total cambió. Actualiza la orden y revisa la inicial antes de confirmar'; end if;
  select bcv_rate,operative_rate into v_bcv,v_op from public.current_exchange_rates;
  if v_bcv is null or v_bcv<=0 or v_op is null or v_op<=0 then raise exception 'Actualiza las tasas antes de cobrar con Cashea'; end if;
  if p_expected_bcv is null or p_expected_bcv<>v_bcv then raise exception 'La tasa BCV cambió. Vuelve a abrir Cashea para revisar la inicial'; end if;
  select coalesce((select (value #>> '{}')::numeric from public.app_settings where key='cashea_commission_percent'),4) into v_commission;
  select coalesce((select (value #>> '{}')::numeric from public.app_settings where key='cashea_minimum_ref'),25) into v_min;
  if v_total_ref<v_min then raise exception 'Cashea requiere al menos REF %',v_min; end if;
  v_initial_ref := round(v_total_ref*p_initial_percent/100,4);
  v_initial_ves := round(v_initial_ref*v_bcv,2);
  v_financed := round(v_total_ref-v_initial_ref,4);
  select coalesce(sum(value_ves),0) into v_paid from public.payments where order_id=p_order_id;
  if v_paid>v_initial_ves+0.01 then raise exception 'Los pagos registrados superan la inicial en Bs %. Ajusta el porcentaje o corrige el pago antes de confirmar',round(v_paid-v_initial_ves,2); end if;
  v_extra := greatest(round(v_initial_ves-v_paid,2),0);
  if v_extra>0 then
    insert into public.payments(order_id,method,currency,amount_original,bcv_rate_snapshot,operative_rate_snapshot,value_ves,value_ref,reference,paid_at)
    values(p_order_id,v_method,case when v_method='CASH_USD' then 'USD' else 'VES' end,case when v_method='CASH_USD' then round(v_extra/v_bcv,4) else v_extra end,v_bcv,v_op,v_extra,round(v_extra/v_bcv,4),nullif(trim(p_payment_reference),''),now());
  end if;
  insert into public.cashea_sales(order_id,status,initial_percent,commission_percent,gross_ref,gross_ves_snapshot,initial_ref,initial_ves_snapshot,financed_ref,commission_ref,commission_ves_snapshot,bcv_rate_snapshot,initial_payment_method,cashea_reference)
  values(p_order_id,case when v_financed<=0.01 then 'SETTLED' else 'ACTIVE' end,p_initial_percent,v_commission,v_total_ref,v_total_ves,v_initial_ref,v_initial_ves,v_financed,round(v_total_ref*v_commission/100,4),round(v_total_ref*v_commission/100*v_bcv,2),v_bcv,v_method,nullif(trim(p_cashea_reference),'')) returning id into v_sale;
  if v_financed>0.01 then
    v_part:=round(v_financed/3,4);
    insert into public.cashea_installments(cashea_sale_id,installment_no,due_date,amount_ref,amount_ves_snapshot)
    values(v_sale,1,v_date+14,v_part,round(v_part*v_bcv,2)),(v_sale,2,v_date+28,v_part,round(v_part*v_bcv,2)),(v_sale,3,v_date+42,v_financed-2*v_part,round((v_financed-2*v_part)*v_bcv,2));
  end if;
  update public.orders set status='CLOSED',closed_at=now(),total_ves=round(v_total_ves,2),total_ref=round(v_total_ref,4),total_cash_usd_equivalent=round((select coalesce(sum(charged_ves_amount/nullif(operative_rate_snapshot,0)),0) from public.order_items where order_id=p_order_id),4) where id=p_order_id;
  for i in select * from public.order_items where order_id=p_order_id loop
    if i.business_area='WORKSHOP' and coalesce(i.worker_share_ref_snapshot,0)>0 then
      insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description,occurred_at) values(i.worker_employee_id,i.id,'WORKSHOP_COMMISSION',i.worker_share_ref_snapshot,'Taller · '||i.description,now()) on conflict do nothing;
    end if;
    if i.business_area='WORKSHOP' and coalesce(i.assistant_bonus_ref_snapshot,0)>0 then
      insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description,occurred_at) values(i.assistant_bonus_employee_id,i.id,'ASSISTANT_BONUS',i.assistant_bonus_ref_snapshot,'Bono ayudante · '||i.description,now()) on conflict do nothing;
    end if;
    if i.business_area='ELECTROAUTO' and coalesce(i.worker_share_ref_snapshot,0)>0 then
      insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description,occurred_at) values(i.worker_employee_id,i.id,'ELECTROAUTO_COMMISSION',i.worker_share_ref_snapshot,'Electroauto · '||i.description,now()) on conflict do nothing;
    end if;
  end loop;
  insert into public.integration_events(event_type,aggregate_type,aggregate_id,payload) values('order.closed','order',p_order_id,jsonb_build_object('order_number',v_order.order_number,'payment_status','CASHEA','cashea_sale_id',v_sale,'total_ves',v_total_ves,'total_ref',v_total_ref));
  insert into public.audit_events(event_type,entity_type,entity_id,data) values('order.closed_cashea','order',p_order_id,jsonb_build_object('cashea_sale_id',v_sale,'initial_ref',v_initial_ref,'financed_ref',v_financed,'previous_payments_ves',v_paid));
  return v_sale;
end $function$
;
CREATE OR REPLACE FUNCTION public.enforce_order_close_readiness()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if new.status='CLOSED' and old.status is distinct from 'CLOSED' then
    perform public.validate_order_ready_to_close(new.id);
    new.workflow_status := 'DELIVERED';
    new.workflow_updated_at := coalesce(new.closed_at,now());
  end if;
  return new;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.close_order_cashea(p_order_id uuid, p_initial_percent numeric, p_initial_payment_method text, p_payment_reference text DEFAULT NULL::text, p_cashea_reference text DEFAULT NULL::text, p_expected_total_ves numeric DEFAULT NULL::numeric, p_expected_total_ref numeric DEFAULT NULL::numeric, p_expected_bcv numeric DEFAULT NULL::numeric)
 RETURNS uuid
 LANGUAGE sql
 SET search_path TO ''
AS $function$
  select lubricenter_private.close_order_cashea(p_order_id,p_initial_percent,p_initial_payment_method,p_payment_reference,p_cashea_reference,p_expected_total_ves,p_expected_total_ref,p_expected_bcv);
$function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.apply_notion_pricing(p_bcv numeric, p_operative numeric, p_products jsonb, p_synced_at timestamp with time zone DEFAULT now())
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare
  v_item jsonb; v_name text; v_key text; v_price numeric;
  v_seen text[] := array[]::text[];
  v_catalog_count integer := 0; v_product_changes integer := 0;
  v_retired integer := 0; v_rate_changes integer := 0; v_latest numeric;
begin
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('lubricenter-notion-pricing', 0));

  if p_bcv is null or p_bcv <= 0 or p_bcv > 1000000 then
    raise exception 'La tasa BCV recibida no es válida';
  end if;
  if p_operative is null or p_operative <= 0 or p_operative > 1000000 then
    raise exception 'La tasa operativa recibida no es válida';
  end if;
  if p_synced_at is null or p_synced_at > now() + interval '5 minutes' then
    raise exception 'La fecha de sincronización no es válida';
  end if;
  if pg_catalog.jsonb_typeof(p_products) <> 'array'
     or pg_catalog.jsonb_array_length(p_products) < 1
     or pg_catalog.jsonb_array_length(p_products) > 500 then
    raise exception 'El catálogo debe contener entre 1 y 500 productos';
  end if;

  for v_item in select value from pg_catalog.jsonb_array_elements(p_products)
  loop
    v_name := pg_catalog.btrim(coalesce(v_item ->> 'name', ''));
    v_key := pg_catalog.lower(v_name);
    if v_name = '' then raise exception 'Hay un producto sin nombre'; end if;
    if v_key = any(v_seen) then raise exception 'El catálogo contiene el producto repetido: %', v_name; end if;

    begin
      v_price := (v_item ->> 'base_usd')::numeric;
    exception when others then
      raise exception 'El precio de % no es numérico', v_name;
    end;
    if v_price is null or v_price < 0 or v_price > 1000000 then
      raise exception 'El precio de % no es válido', v_name;
    end if;

    if exists (
      select 1 from public.products p
      where pg_catalog.lower(pg_catalog.btrim(p.name)) = v_key
        and (p.name, p.category, p.available, p.active, p.cash_usd_base_price, p.notes, p.image_url, p.catalog_source)
          is distinct from
            (v_name, nullif(pg_catalog.btrim(v_item ->> 'category'), ''), true, true, v_price,
             nullif(pg_catalog.btrim(v_item ->> 'description'), ''),
             nullif(pg_catalog.btrim(v_item ->> 'image_url'), ''), 'Notion · Nuestros Productos')
    ) or not exists (
      select 1 from public.products p where pg_catalog.lower(pg_catalog.btrim(p.name)) = v_key
    ) then v_product_changes := v_product_changes + 1; end if;

    insert into public.products (
      name, category, available, active, cash_usd_base_price, notes, image_url,
      catalog_source, catalog_synced_at, updated_at
    ) values (
      v_name, nullif(pg_catalog.btrim(v_item ->> 'category'), ''), true, true, v_price,
      nullif(pg_catalog.btrim(v_item ->> 'description'), ''),
      nullif(pg_catalog.btrim(v_item ->> 'image_url'), ''),
      'Notion · Nuestros Productos', p_synced_at, p_synced_at
    )
    on conflict (pg_catalog.lower(pg_catalog.btrim(name))) do update set
      name = excluded.name, category = excluded.category, available = true, active = true,
      cash_usd_base_price = excluded.cash_usd_base_price, notes = excluded.notes,
      image_url = excluded.image_url, catalog_source = excluded.catalog_source,
      catalog_synced_at = excluded.catalog_synced_at, updated_at = excluded.updated_at;

    v_seen := pg_catalog.array_append(v_seen, v_key);
    v_catalog_count := v_catalog_count + 1;
  end loop;

  update public.products p
  set available = false, catalog_synced_at = p_synced_at, updated_at = p_synced_at
  where p.catalog_source = 'Notion · Nuestros Productos'
    and not (pg_catalog.lower(pg_catalog.btrim(p.name)) = any(v_seen)) and p.available;
  get diagnostics v_retired = row_count;
  v_product_changes := v_product_changes + v_retired;

  select er.value into v_latest from public.exchange_rates er
  where er.rate_type = 'BCV' order by er.effective_at desc, er.created_at desc limit 1;
  if v_latest is distinct from p_bcv then
    insert into public.exchange_rates(rate_type, value, effective_at, source, created_by)
    values ('BCV', p_bcv, p_synced_at, 'Notion · Tasas', null);
    v_rate_changes := v_rate_changes + 1;
  end if;

  select er.value into v_latest from public.exchange_rates er
  where er.rate_type = 'OPERATIVE' order by er.effective_at desc, er.created_at desc limit 1;
  if v_latest is distinct from p_operative then
    insert into public.exchange_rates(rate_type, value, effective_at, source, created_by)
    values ('OPERATIVE', p_operative, p_synced_at, 'Notion · Tasas', null);
    v_rate_changes := v_rate_changes + 1;
  end if;

  insert into public.integration_sync_state(source_key, last_verified_at, last_success_payload, updated_at)
  values ('notion_catalog', p_synced_at,
    pg_catalog.jsonb_build_object('products', v_catalog_count, 'changed', v_product_changes), p_synced_at)
  on conflict (source_key) do update set last_verified_at = excluded.last_verified_at,
    last_success_payload = excluded.last_success_payload, updated_at = excluded.updated_at;

  insert into public.integration_sync_state(source_key, last_verified_at, last_success_payload, updated_at)
  values ('notion_rates', p_synced_at,
    pg_catalog.jsonb_build_object('BCV', p_bcv, 'OPERATIVE', p_operative, 'changed', v_rate_changes), p_synced_at)
  on conflict (source_key) do update set last_verified_at = excluded.last_verified_at,
    last_success_payload = excluded.last_success_payload, updated_at = excluded.updated_at;

  insert into public.audit_events(event_type, entity_type, entity_id, data, actor_id)
  values ('NOTION_PRICING_SYNCED', 'integration_sync_state', null,
    pg_catalog.jsonb_build_object('products', v_catalog_count, 'product_changes', v_product_changes,
      'rate_changes', v_rate_changes, 'bcv', p_bcv, 'operative', p_operative, 'synced_at', p_synced_at),
    auth.uid());

  return pg_catalog.jsonb_build_object('ok', true, 'products', v_catalog_count,
    'product_changes', v_product_changes, 'rate_changes', v_rate_changes, 'synced_at', p_synced_at);
end
$function$
;
CREATE OR REPLACE FUNCTION public.sync_notion_pricing(p_bcv numeric, p_operative numeric, p_products jsonb, p_synced_at timestamp with time zone DEFAULT now())
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
  perform lubricenter_private.require_order_admin();
  return lubricenter_private.apply_notion_pricing(p_bcv, p_operative, p_products, p_synced_at);
end
$function$
;
CREATE OR REPLACE FUNCTION public.sync_notion_pricing_service(p_bcv numeric, p_operative numeric, p_products jsonb, p_synced_at timestamp with time zone DEFAULT now())
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
  if auth.role() <> 'service_role' then
    raise exception 'Esta función es exclusiva del sincronizador del servidor';
  end if;
  return lubricenter_private.apply_notion_pricing(p_bcv, p_operative, p_products, p_synced_at);
end
$function$
;
CREATE OR REPLACE FUNCTION lubricenter_private.normalize_order_walk_in()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
begin
  -- Corrections inherit walk-in status from the original order when no party is
  -- supplied. This keeps old quick services editable by the authorized account.
  if tg_op = 'INSERT'
     and new.corrects_order_id is not null
     and new.customer_id is null
     and new.vehicle_id is null then
    select o.is_walk_in into new.is_walk_in
    from public.orders o
    where o.id = new.corrects_order_id;
  end if;

  -- Any real customer or vehicle turns the order back into a tracked service.
  if new.customer_id is not null or new.vehicle_id is not null then
    new.is_walk_in := false;
  end if;

  return new;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.set_order_walk_in(p_order_id uuid, p_is_walk_in boolean DEFAULT true)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);

  if coalesce(p_is_walk_in, false) and exists (
    select 1
    from public.order_items
    where order_id = p_order_id
      and item_type = 'SERVICE'
      and business_area = 'OIL_CHANGE'
  ) then
    raise exception 'Un cambio de aceite necesita cliente y vehículo para guardar kilometraje y próximo servicio';
  end if;

  update public.orders
  set is_walk_in = coalesce(p_is_walk_in, false),
      customer_id = case when coalesce(p_is_walk_in, false) then null else customer_id end,
      vehicle_id = case when coalesce(p_is_walk_in, false) then null else vehicle_id end
  where id = p_order_id;

  insert into public.audit_events(event_type, entity_type, entity_id, data)
  values (
    'order.walk_in_changed',
    'order',
    p_order_id,
    jsonb_build_object('is_walk_in', coalesce(p_is_walk_in, false))
  );
end;
$function$
;
CREATE OR REPLACE FUNCTION public.set_order_party(p_order_id uuid, p_customer_id uuid DEFAULT NULL::uuid, p_vehicle_id uuid DEFAULT NULL::uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_vehicle_customer uuid;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);

  if p_customer_id is not null and not exists(select 1 from public.customers where id=p_customer_id) then
    raise exception 'Cliente no encontrado';
  end if;
  if p_vehicle_id is not null then
    select customer_id into v_vehicle_customer from public.vehicles where id=p_vehicle_id;
    if not found then raise exception 'Vehículo no encontrado'; end if;
    if p_customer_id is not null and v_vehicle_customer is not null and v_vehicle_customer <> p_customer_id then
      raise exception 'El vehículo pertenece a otro cliente';
    end if;
    if p_customer_id is not null and v_vehicle_customer is null then
      update public.vehicles set customer_id=p_customer_id where id=p_vehicle_id;
    end if;
  end if;

  update public.orders
  set customer_id=p_customer_id,
      vehicle_id=p_vehicle_id,
      is_walk_in=false
  where id=p_order_id;

  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('order.party_changed','order',p_order_id,jsonb_build_object('customer_id',p_customer_id,'vehicle_id',p_vehicle_id,'is_walk_in',false));
end;
$function$
;
CREATE OR REPLACE FUNCTION public.get_current_rates()
 RETURNS TABLE(bcv_rate numeric, operative_rate numeric)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select c.bcv_rate, c.operative_rate from public.current_exchange_rates c;
$function$
;
CREATE OR REPLACE FUNCTION public.assert_order_open(p_order_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_status text;
begin
  select status into v_status from public.orders where id=p_order_id for update;
  if v_status is null then raise exception 'Orden no encontrada'; end if;
  if v_status <> 'OPEN' then raise exception 'La orden ya no está abierta'; end if;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.touch_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
begin
  new.updated_at = now();
  return new;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.require_auth()
 RETURNS void
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.delete_order_item(p_item_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_order uuid;
begin
  perform public.require_auth();
  select order_id into v_order from public.order_items where id=p_item_id;
  if v_order is null then return; end if;
  perform public.assert_order_open(v_order);
  delete from public.order_items where id=p_item_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.add_payment(p_order_id uuid, p_method text, p_amount_original numeric, p_reference text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_bcv numeric; v_op numeric; v_currency text; v_value_ves numeric; v_id uuid;
  v_method text := upper(p_method);
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  if v_method not in ('CASH_USD','CASH_VES','MOBILE_PAYMENT','TRANSFER_BDV','TRANSFER_BNC') then raise exception 'Método de pago inválido'; end if;
  if p_amount_original <= 0 then raise exception 'Monto de pago inválido'; end if;
  select bcv_rate,operative_rate into v_bcv,v_op from public.current_exchange_rates;
  if v_bcv is null or v_op is null then raise exception 'Debes registrar tasas antes de cobrar'; end if;
  v_currency := case when v_method='CASH_USD' then 'USD' else 'VES' end;
  v_value_ves := case when v_currency='USD' then p_amount_original * v_op else p_amount_original end;
  insert into public.payments(order_id,method,currency,amount_original,bcv_rate_snapshot,operative_rate_snapshot,value_ves,value_ref,reference)
  values(p_order_id,v_method,v_currency,p_amount_original,v_bcv,v_op,round(v_value_ves,2),round(v_value_ves/v_bcv,4),nullif(trim(p_reference),''))
  returning id into v_id;
  return v_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.delete_payment(p_payment_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_order uuid;
begin
  perform public.require_auth();
  select order_id into v_order from public.payments where id=p_payment_id;
  if v_order is null then return; end if;
  perform public.assert_order_open(v_order);
  delete from public.payments where id=p_payment_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.update_customer_profile(p_customer_id uuid, p_name text DEFAULT NULL::text, p_phone text DEFAULT NULL::text, p_document_id text DEFAULT NULL::text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_before jsonb;
  v_name text := nullif(trim(p_name), '');
  v_phone text := nullif(trim(p_phone), '');
  v_document text := nullif(trim(p_document_id), '');
begin
  perform public.require_auth();
  if p_customer_id is null then raise exception 'Cliente inválido'; end if;
  if v_name is null and v_phone is null and v_document is null then
    raise exception 'Debes indicar nombre, teléfono o documento';
  end if;

  select to_jsonb(c) - 'created_at' - 'updated_at' into v_before
  from public.customers c where c.id = p_customer_id for update;
  if not found then raise exception 'Cliente no encontrado'; end if;

  update public.customers
  set name = v_name, phone = v_phone, document_id = v_document
  where id = p_customer_id;

  insert into public.audit_events(event_type, entity_type, entity_id, data)
  values ('customer.profile_updated', 'customer', p_customer_id,
    jsonb_build_object('before', v_before, 'after', jsonb_build_object('name', v_name, 'phone', v_phone, 'document_id', v_document)));
end;
$function$
;
CREATE OR REPLACE FUNCTION public.reassign_vehicle_customer(p_vehicle_id uuid, p_customer_id uuid DEFAULT NULL::uuid, p_reason text DEFAULT NULL::text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_previous uuid;
  v_reason text := nullif(trim(p_reason), '');
begin
  perform public.require_auth();
  if v_reason is null or length(v_reason) < 3 then
    raise exception 'Indica el motivo del cambio';
  end if;

  select customer_id into v_previous from public.vehicles where id = p_vehicle_id for update;
  if not found then raise exception 'Vehículo no encontrado'; end if;
  if p_customer_id is not null and not exists(select 1 from public.customers where id = p_customer_id) then
    raise exception 'Cliente no encontrado';
  end if;
  if v_previous is not distinct from p_customer_id then
    raise exception 'El vehículo ya tiene esa asociación';
  end if;

  update public.vehicles set customer_id = p_customer_id where id = p_vehicle_id;

  if v_previous is not null then
    update public.vehicle_customer_history
    set last_seen_at = now()
    where vehicle_id = p_vehicle_id and customer_id = v_previous and source_system = 'LUBRICENTER_OS';
  end if;
  if p_customer_id is not null then
    insert into public.vehicle_customer_history(vehicle_id, customer_id, source_system, first_seen_at, last_seen_at)
    values (p_vehicle_id, p_customer_id, 'LUBRICENTER_OS', now(), now())
    on conflict (vehicle_id, customer_id, source_system)
    do update set last_seen_at = excluded.last_seen_at;
  end if;

  insert into public.audit_events(event_type, entity_type, entity_id, data)
  values (
    case when p_customer_id is null then 'vehicle.customer_unlinked' else 'vehicle.customer_reassigned' end,
    'vehicle', p_vehicle_id,
    jsonb_build_object('previous_customer_id', v_previous, 'customer_id', p_customer_id, 'reason', v_reason)
  );
end;
$function$
;
CREATE OR REPLACE FUNCTION public.search_customer_master(p_query text DEFAULT NULL::text, p_limit integer DEFAULT 100)
 RETURNS TABLE(customer_id uuid, name text, phone text, document_id text, created_at timestamp with time zone, vehicle_count bigint, order_count bigint, total_ref numeric, last_visit_at timestamp with time zone, vehicles_text text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_query text := nullif(trim(p_query), '');
  v_limit integer := least(greatest(coalesce(p_limit, 100), 1), 1000);
begin
  perform public.require_auth();
  return query
  select c.id, c.name, c.phone, c.document_id, c.created_at,
    coalesce(vs.vehicle_count, 0), coalesce(os.order_count, 0), coalesce(os.total_ref, 0), os.last_visit_at, vs.vehicles_text
  from public.customers c
  left join lateral (
    select count(*) as vehicle_count,
      string_agg(trim(concat_ws(' ', v.plate, v.make, v.model, v.year::text)), ' · ' order by v.updated_at desc) as vehicles_text
    from public.vehicles v where v.customer_id = c.id
  ) vs on true
  left join lateral (
    select count(*) as order_count, sum(o.total_ref) as total_ref,
      max(coalesce(o.closed_at, o.opened_at)) as last_visit_at
    from public.orders o where o.customer_id = c.id
  ) os on true
  where v_query is null
     or concat_ws(' ', c.name, c.phone, c.document_id) ilike '%' || v_query || '%'
     or exists (select 1 from public.vehicles sv where sv.customer_id = c.id
       and concat_ws(' ', sv.plate, sv.make, sv.model, sv.year::text) ilike '%' || v_query || '%')
  order by os.last_visit_at desc nulls last, c.updated_at desc
  limit v_limit;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.search_vehicles_for_customer(p_customer_id uuid, p_query text, p_limit integer DEFAULT 12)
 RETURNS TABLE(id uuid, customer_id uuid, plate text, make text, model text, year integer, engine text, current_odometer integer, customer_name text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_query text := nullif(trim(p_query), '');
  v_limit integer := least(greatest(coalesce(p_limit, 12), 1), 50);
begin
  perform public.require_auth();
  if v_query is null then return; end if;
  return query
  select v.id, v.customer_id, v.plate, v.make, v.model, v.year, v.engine, v.current_odometer, c.name
  from public.vehicles v
  left join public.customers c on c.id = v.customer_id
  where v.customer_id is distinct from p_customer_id
    and concat_ws(' ', v.plate, v.make, v.model, v.year::text, c.name) ilike '%' || v_query || '%'
  order by case when upper(coalesce(v.plate,'')) = upper(v_query) then 0 else 1 end, v.updated_at desc
  limit v_limit;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.create_order()
 RETURNS TABLE(id uuid, order_number text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v public.orders;
  v_location uuid;
begin
  perform public.require_auth();
  select l.id into v_location from public.locations l where l.code='CABUDARE' and l.active=true limit 1;
  if v_location is null then select l.id into v_location from public.locations l where l.active=true order by l.created_at limit 1; end if;
  insert into public.orders(location_id) values(v_location) returning * into v;
  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('order.created','order',v.id,jsonb_build_object('order_number',v.order_number,'location_id',v.location_id));
  return query select v.id,v.order_number;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.create_customer_vehicle(p_customer_id uuid, p_plate text DEFAULT NULL::text, p_make text DEFAULT NULL::text, p_model text DEFAULT NULL::text, p_year integer DEFAULT NULL::integer, p_engine text DEFAULT NULL::text, p_current_odometer integer DEFAULT NULL::integer)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_id uuid;
  v_plate text := nullif(upper(trim(p_plate)), '');
  v_make text := nullif(trim(p_make), '');
  v_model text := nullif(trim(p_model), '');
  v_engine text := nullif(trim(p_engine), '');
begin
  perform public.require_auth();
  if p_customer_id is null or not exists(select 1 from public.customers where id = p_customer_id) then
    raise exception 'Cliente no encontrado';
  end if;
  if v_plate is null and v_make is null and v_model is null then
    raise exception 'Debes indicar placa, marca o modelo';
  end if;
  if v_plate is not null and exists(select 1 from public.vehicles where upper(plate) = v_plate) then
    raise exception 'Esa placa ya existe. Usa Asociar existente para conservar el historial.';
  end if;
  if p_year is not null and (p_year < 1900 or p_year > extract(year from current_date)::integer + 1) then
    raise exception 'Año de vehículo inválido';
  end if;
  if p_current_odometer is not null and p_current_odometer < 0 then
    raise exception 'Kilometraje inválido';
  end if;

  insert into public.vehicles(customer_id, plate, make, model, year, engine, current_odometer)
  values (p_customer_id, v_plate, v_make, v_model, p_year, v_engine, p_current_odometer)
  returning id into v_id;

  insert into public.vehicle_customer_history(vehicle_id, customer_id, source_system, first_seen_at, last_seen_at)
  values (v_id, p_customer_id, 'LUBRICENTER_OS', now(), now())
  on conflict (vehicle_id, customer_id, source_system) do update set last_seen_at = excluded.last_seen_at;

  insert into public.audit_events(event_type, entity_type, entity_id, data)
  values ('vehicle.created', 'vehicle', v_id, jsonb_build_object('customer_id', p_customer_id, 'plate', v_plate));
  return v_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.set_exchange_rates(p_bcv numeric, p_operative numeric)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_now timestamptz := now();
begin
  perform public.require_auth();
  if p_bcv <= 0 or p_operative <= 0 then raise exception 'Las tasas deben ser mayores que cero'; end if;
  insert into public.exchange_rates(rate_type,value,effective_at,source) values
    ('BCV', p_bcv, v_now, 'APP'),
    ('OPERATIVE', p_operative, v_now, 'APP');
  insert into public.audit_events(event_type, entity_type, data)
  values ('rates.changed','exchange_rates', jsonb_build_object('bcv',p_bcv,'operative',p_operative));
end;
$function$
;
CREATE OR REPLACE FUNCTION public.set_pricing_settings(p_rounding_step numeric, p_rounding_mode text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  perform public.require_auth();
  if p_rounding_step <= 0 then raise exception 'Paso de redondeo inválido'; end if;
  if p_rounding_mode not in ('nearest','up','down') then raise exception 'Modo de redondeo inválido'; end if;
  insert into public.app_settings(key,value) values ('price_rounding_step',to_jsonb(p_rounding_step))
    on conflict(key) do update set value=excluded.value, updated_at=now();
  insert into public.app_settings(key,value) values ('price_rounding_mode',to_jsonb(p_rounding_mode))
    on conflict(key) do update set value=excluded.value, updated_at=now();
end;
$function$
;
CREATE OR REPLACE FUNCTION public.record_cashea_installment_payment(p_installment_id uuid, p_method text, p_amount_original numeric, p_reference text DEFAULT NULL::text)
 RETURNS TABLE(payment_id uuid, installment_status text, remaining_sale_ref numeric, sale_status text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_inst public.cashea_installments;
  v_sale public.cashea_sales;
  v_bcv numeric; v_op numeric; v_method text := upper(coalesce(p_method,''));
  v_currency text; v_value_ves numeric; v_value_ref numeric; v_remaining_inst_ref numeric; v_applied_ref numeric;
  v_payment_id uuid; v_remaining_ref numeric; v_inst_status text; v_sale_status text;
begin
  perform public.require_auth();
  select * into v_inst from public.cashea_installments where id=p_installment_id for update;
  if v_inst.id is null then raise exception 'Cuota Cashea no encontrada'; end if;
  if v_inst.status='PAID' then raise exception 'Esta cuota Cashea ya está pagada'; end if;
  select * into v_sale from public.cashea_sales where id=v_inst.cashea_sale_id for update;
  if v_sale.status<>'ACTIVE' then raise exception 'La venta Cashea no está activa'; end if;
  if v_method not in ('CASH_USD','CASH_VES','MOBILE_PAYMENT','TRANSFER_BDV','TRANSFER_BNC') then raise exception 'Método de pago inválido'; end if;
  if p_amount_original is null or p_amount_original<=0 then raise exception 'Monto inválido'; end if;
  select bcv_rate,operative_rate into v_bcv,v_op from public.current_exchange_rates;
  if v_bcv is null or v_bcv<=0 or v_op is null or v_op<=0 then raise exception 'Debes registrar tasas antes de cobrar'; end if;

  v_currency := case when v_method='CASH_USD' then 'USD' else 'VES' end;
  if v_currency='USD' then
    v_value_ref := p_amount_original;
    v_value_ves := round(p_amount_original*v_bcv,2);
  else
    v_value_ves := p_amount_original;
    v_value_ref := round(p_amount_original/v_bcv,4);
  end if;
  v_remaining_inst_ref := greatest(v_inst.amount_ref-v_inst.paid_ref,0);
  if v_value_ref > v_remaining_inst_ref + 0.05 then raise exception 'El pago excede esta cuota Cashea por REF %', round(v_value_ref-v_remaining_inst_ref,2); end if;
  v_applied_ref := least(v_value_ref,v_remaining_inst_ref);

  insert into public.payments(order_id,receivable_id,method,currency,amount_original,bcv_rate_snapshot,operative_rate_snapshot,value_ves,value_ref,reference,paid_at)
  values(v_sale.order_id,null,v_method,v_currency,p_amount_original,v_bcv,v_op,round(v_value_ves,2),round(v_value_ref,4),nullif(trim(p_reference),''),now())
  returning id into v_payment_id;

  v_inst_status := case when v_inst.paid_ref+v_applied_ref >= v_inst.amount_ref-0.05 then 'PAID' else 'PARTIAL' end;
  update public.cashea_installments
  set paid_ref=case when v_inst_status='PAID' then amount_ref else round(paid_ref+v_applied_ref,4) end,
      paid_ves_actual=round(paid_ves_actual+v_value_ves,2),status=v_inst_status,
      paid_at=case when v_inst_status='PAID' then now() else paid_at end,updated_at=now()
  where id=p_installment_id;

  select coalesce(sum(greatest(amount_ref-paid_ref,0)),0) into v_remaining_ref
  from public.cashea_installments where cashea_sale_id=v_sale.id;
  v_sale_status := case when v_remaining_ref<=0.05 then 'SETTLED' else 'ACTIVE' end;
  update public.cashea_sales set status=v_sale_status,settled_at=case when v_sale_status='SETTLED' then now() else null end where id=v_sale.id;

  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('cashea.installment_payment_recorded','cashea_installment',p_installment_id,
    jsonb_build_object('payment_id',v_payment_id,'method',v_method,'value_ref',v_value_ref,'remaining_sale_ref',v_remaining_ref,'installment_status',v_inst_status,'sale_status',v_sale_status));

  payment_id:=v_payment_id; installment_status:=v_inst_status; remaining_sale_ref:=round(v_remaining_ref,4); sale_status:=v_sale_status;
  return next;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.round_to_step(p_value numeric, p_step numeric, p_mode text)
 RETURNS numeric
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
begin
  if p_step is null or p_step <= 0 then return p_value; end if;
  if p_mode = 'up' then return ceil(p_value / p_step) * p_step; end if;
  if p_mode = 'down' then return floor(p_value / p_step) * p_step; end if;
  return round(p_value / p_step) * p_step;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.finance_dashboard(p_from date DEFAULT NULL::date, p_to date DEFAULT NULL::date)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_from date := coalesce(p_from, date_trunc('month', timezone('America/Caracas', now()))::date);
  v_to date := coalesce(p_to, timezone('America/Caracas', now())::date);
  v_result jsonb;
begin
  perform public.require_auth();
  if v_from > v_to then raise exception 'La fecha inicial debe ser anterior a la final'; end if;
  if v_to - v_from > 366 then raise exception 'El período máximo es de 367 días'; end if;

  with classified_sales as (
    select o.id, o.total_ref, o.total_ves,
      timezone('America/Caracas', coalesce(o.business_at, o.closed_at))::date sale_date,
      case when cs.id is not null then 'CASHEA'
           when r.id is not null then 'CREDIT_LC'
           else 'CASH' end sale_type
    from public.orders o
    left join public.cashea_sales cs on cs.order_id = o.id
    left join public.receivables r on r.order_id = o.id and r.debtor_type <> 'CASHEA'
    where o.status = 'CLOSED'
      and coalesce(o.business_at, o.closed_at) >= (v_from::timestamp at time zone 'America/Caracas')
      and coalesce(o.business_at, o.closed_at) < ((v_to + 1)::timestamp at time zone 'America/Caracas')
  ), sales_summary as (
    select count(*) orders, coalesce(sum(total_ref),0) total_ref, coalesce(sum(total_ves),0) total_ves
    from classified_sales
  ), sales_by_type as (
    select sale_type, count(*) orders, coalesce(sum(total_ref),0) total_ref, coalesce(sum(total_ves),0) total_ves
    from classified_sales group by sale_type
  ), period_payments as (
    select p.* from public.payments p
    where p.paid_at >= (v_from::timestamp at time zone 'America/Caracas')
      and p.paid_at < ((v_to + 1)::timestamp at time zone 'America/Caracas')
  ), collections_summary as (
    select count(*) payments, coalesce(sum(value_ref),0) total_ref, coalesce(sum(value_ves),0) total_ves
    from period_payments
  ), collections_by_method as (
    select method, count(*) payments, coalesce(sum(value_ref),0) total_ref, coalesce(sum(value_ves),0) total_ves
    from period_payments group by method
  ), period_expenses as (
    select am.* from public.account_movements am
    where am.direction='OUT' and am.movement_type='EXPENSE'
      and am.occurred_at >= (v_from::timestamp at time zone 'America/Caracas')
      and am.occurred_at < ((v_to + 1)::timestamp at time zone 'America/Caracas')
  ), expense_summary as (
    select count(*) expenses, coalesce(sum(value_ves),0) total_ves from period_expenses
  ), expenses_by_category as (
    select coalesce(category,'Sin categoría') category, count(*) expenses, coalesce(sum(value_ves),0) total_ves
    from period_expenses group by coalesce(category,'Sin categoría')
  ), daily as (
    select d::date activity_date,
      coalesce((select sum(s.total_ref) from classified_sales s where s.sale_date=d::date),0) sales_ref,
      coalesce((select sum(p.value_ref) from period_payments p where timezone('America/Caracas',p.paid_at)::date=d::date),0) collected_ref,
      coalesce((select sum(e.value_ves) from period_expenses e where timezone('America/Caracas',e.occurred_at)::date=d::date),0) expenses_ves
    from generate_series(v_from::timestamp, v_to::timestamp, interval '1 day') d
  ), lc_open as (
    select count(*) accounts, coalesce(sum(outstanding_ves),0) outstanding_ves,
      count(*) filter(where due_date is not null and due_date < timezone('America/Caracas',now())::date) overdue
    from public.receivables where status='OPEN' and debtor_type <> 'CASHEA'
  ), cashea_open as (
    select count(distinct cs.id) sales,
      count(ci.id) filter(where ci.status in ('PENDING','PARTIAL')) installments,
      coalesce(sum(greatest(ci.amount_ref-ci.paid_ref,0)) filter(where ci.status in ('PENDING','PARTIAL')),0) outstanding_ref,
      count(ci.id) filter(where ci.status in ('PENDING','PARTIAL') and ci.due_date < timezone('America/Caracas',now())::date) overdue
    from public.cashea_sales cs left join public.cashea_installments ci on ci.cashea_sale_id=cs.id
    where cs.status <> 'SETTLED'
  ), balances as (
    select id,code,name,currency,account_type,balance_native,balance_ves
    from public.account_balances_current where active order by account_type,name
  )
  select jsonb_build_object(
    'period', jsonb_build_object('from',v_from,'to',v_to,'days',v_to-v_from+1),
    'sales', (select to_jsonb(sales_summary) from sales_summary),
    'sales_by_type', coalesce((select jsonb_agg(to_jsonb(x) order by sale_type) from sales_by_type x),'[]'::jsonb),
    'collections', (select to_jsonb(collections_summary) from collections_summary),
    'collections_by_method', coalesce((select jsonb_agg(to_jsonb(x) order by total_ves desc) from collections_by_method x),'[]'::jsonb),
    'expenses', (select to_jsonb(expense_summary) from expense_summary),
    'expenses_by_category', coalesce((select jsonb_agg(to_jsonb(x) order by total_ves desc) from expenses_by_category x),'[]'::jsonb),
    'net_cash_ves', (select total_ves from collections_summary) - (select total_ves from expense_summary),
    'lc_open', (select to_jsonb(lc_open) from lc_open),
    'cashea_open', (select to_jsonb(cashea_open) from cashea_open),
    'accounts', coalesce((select jsonb_agg(to_jsonb(x)) from balances x),'[]'::jsonb),
    'daily', coalesce((select jsonb_agg(to_jsonb(x) order by activity_date) from daily x),'[]'::jsonb)
  ) into v_result;
  return v_result;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.record_account_expense_v2(p_account_id uuid, p_amount numeric, p_category text, p_payee text DEFAULT NULL::text, p_note text DEFAULT NULL::text, p_reference text DEFAULT NULL::text, p_occurred_on date DEFAULT NULL::date)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_account public.financial_accounts;
  v_day date := coalesce(p_occurred_on, timezone('America/Caracas',now())::date);
  v_op numeric;
  v_value_ves numeric;
  v_id uuid;
  v_occurred_at timestamptz;
begin
  perform public.require_auth();
  select * into v_account from public.financial_accounts where id=p_account_id and active=true;
  if not found then raise exception 'Cuenta no encontrada'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Monto inválido'; end if;
  if coalesce(trim(p_category),'')='' then raise exception 'Categoría requerida'; end if;
  if v_day > timezone('America/Caracas',now())::date then raise exception 'La fecha del gasto no puede ser futura'; end if;
  if v_day < timezone('America/Caracas',now())::date - 1825 then raise exception 'La fecha del gasto es demasiado antigua'; end if;

  select value into v_op from public.exchange_rates
  where rate_type='OPERATIVE' and timezone('America/Caracas',effective_at)::date <= v_day
  order by effective_at desc limit 1;
  if v_op is null then select operative_rate into v_op from public.current_exchange_rates; end if;
  v_value_ves := case when v_account.currency='USD' then p_amount*v_op else p_amount end;
  v_occurred_at := ((v_day::timestamp + time '12:00') at time zone 'America/Caracas');

  insert into public.account_movements(account_id,direction,movement_type,currency,amount_original,value_ves,category,payee,note,reference,occurred_at)
  values(p_account_id,'OUT','EXPENSE',v_account.currency,p_amount,round(v_value_ves,2),trim(p_category),nullif(trim(p_payee),''),nullif(trim(p_note),''),nullif(trim(p_reference),''),v_occurred_at)
  returning id into v_id;

  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('cash.expense_recorded','account_movement',v_id,jsonb_build_object(
    'account_id',p_account_id,'amount',p_amount,'currency',v_account.currency,
    'category',trim(p_category),'payee',nullif(trim(p_payee),''),'occurred_on',v_day
  ));
  return v_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.add_payroll_adjustment(p_employee_id uuid, p_adjustment_type text, p_amount_ref numeric, p_note text DEFAULT NULL::text, p_occurred_on date DEFAULT CURRENT_DATE)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid; v_type text := upper(p_adjustment_type);
begin
  perform public.require_auth();
  if v_type not in ('SUPPLIES','ADVANCE','DEBT','BONUS','OTHER') then raise exception 'Tipo de ajuste inválido'; end if;
  if p_amount_ref=0 then raise exception 'Monto inválido'; end if;
  insert into public.payroll_adjustments(employee_id,adjustment_type,amount_ref,note,occurred_on)
  values(p_employee_id,v_type,p_amount_ref,nullif(trim(p_note),''),p_occurred_on) returning id into v_id;
  return v_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.create_weekly_payroll_run(p_employee_id uuid, p_period_start date, p_period_end date)
 RETURNS TABLE(id uuid, total_ref numeric, fixed_ref numeric, variable_ref numeric, adjustments_ref numeric)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_id uuid; v_fixed numeric:=0; v_variable numeric:=0; v_adjustments numeric:=0; v_total numeric:=0;
begin
  perform public.require_auth();
  if p_period_end < p_period_start then raise exception 'Período inválido'; end if;
  if exists(
    select 1 from public.payroll_runs
    where employee_id=p_employee_id and status='SETTLED'
      and daterange(period_start, period_end, '[]') && daterange(p_period_start, p_period_end, '[]')
  ) then
    raise exception 'Ya existe una liquidación que se solapa con ese período para el empleado';
  end if;

  select coalesce(cr.value,0) into v_fixed
  from public.compensation_rules cr
  where cr.employee_id=p_employee_id and cr.rule_type='FIXED_WEEKLY'
    and cr.valid_from <= p_period_end and (cr.valid_to is null or cr.valid_to >= p_period_end)
  order by cr.valid_from desc limit 1;
  v_fixed := coalesce(v_fixed,0);

  select coalesce(sum(amount_ref),0) into v_variable from public.payroll_accruals
  where employee_id=p_employee_id and payroll_run_id is null and (occurred_at at time zone 'America/Caracas')::date between p_period_start and p_period_end;
  select coalesce(sum(amount_ref),0) into v_adjustments from public.payroll_adjustments
  where employee_id=p_employee_id and payroll_run_id is null and occurred_on between p_period_start and p_period_end;
  v_total := v_fixed + v_variable + v_adjustments;
  if v_total < 0 then raise exception 'Las deducciones superan el pago de la semana. Ajusta la liquidación antes de cerrarla.'; end if;

  insert into public.payroll_runs(employee_id,period_start,period_end,fixed_ref,variable_ref,adjustments_ref,total_ref)
  values(p_employee_id,p_period_start,p_period_end,v_fixed,v_variable,v_adjustments,v_total) returning payroll_runs.id into v_id;
  update public.payroll_accruals set payroll_run_id=v_id
  where employee_id=p_employee_id and payroll_run_id is null and (occurred_at at time zone 'America/Caracas')::date between p_period_start and p_period_end;
  update public.payroll_adjustments set payroll_run_id=v_id
  where employee_id=p_employee_id and payroll_run_id is null and occurred_on between p_period_start and p_period_end;

  insert into public.integration_events(event_type,aggregate_type,aggregate_id,payload)
  values('payroll.settled','payroll_run',v_id,jsonb_build_object('employee_id',p_employee_id,'total_ref',v_total,'period_start',p_period_start,'period_end',p_period_end));
  return query select v_id,round(v_total,4),round(v_fixed,4),round(v_variable,4),round(v_adjustments,4);
end;
$function$
;
CREATE OR REPLACE FUNCTION public.queue_post_service_followup()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_message text;
  v_start_date date;
  v_status text;
  v_sent_at timestamptz;
begin
  if new.status='CLOSED' and old.status is distinct from 'CLOSED' and new.customer_id is not null then
    select coalesce(
      (select trim(both '"' from value::text)::date from public.app_settings where key='crm_operational_start_date'),
      date '2026-09-10'
    ) into v_start_date;

    v_message := public.build_post_service_message(new.id);
    if coalesce(new.closed_at,new.created_at,now())::date < v_start_date then
      v_status := 'SENT';
      v_sent_at := coalesce(new.closed_at,now());
    else
      v_status := 'PENDING';
      v_sent_at := null;
    end if;

    insert into public.customer_followups(order_id,customer_id,vehicle_id,followup_type,channel,status,message,sent_at)
    values(new.id,new.customer_id,new.vehicle_id,'POST_SERVICE','WHATSAPP',v_status,v_message,v_sent_at)
    on conflict(order_id,followup_type) do update
      set customer_id=excluded.customer_id,
          vehicle_id=excluded.vehicle_id,
          message=excluded.message,
          status=excluded.status,
          sent_at=excluded.sent_at,
          snoozed_until=null,
          updated_at=now();
  end if;
  return new;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.snapshot_order_item_cost()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_cost numeric;
begin
  if new.movement_type='SALE' and new.order_item_id is not null then
    select average_cost_ref into v_cost from public.inventory_items where id=new.inventory_item_id;
    update public.order_items set unit_cost_ref_snapshot=coalesce(unit_cost_ref_snapshot,v_cost),total_cost_ref_snapshot=coalesce(total_cost_ref_snapshot,round(abs(new.quantity_delta)*v_cost,4)) where id=new.order_item_id;
  end if;
  return new;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.mark_cash_close_review()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_day date; v_old_day date;
begin
  if tg_op='DELETE' then v_day:=timezone('America/Caracas',old.occurred_at)::date;
  else v_day:=timezone('America/Caracas',new.occurred_at)::date; end if;
  v_old_day:=case when tg_op='UPDATE' then timezone('America/Caracas',old.occurred_at)::date else null end;
  update public.cash_closings set status='REVIEW',review_reason='Se registró o modificó un movimiento después del cierre',updated_at=now() where status='CLOSED' and business_date in (v_day,v_old_day);
  if tg_op='DELETE' then return old; end if;
  return new;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.regenerate_customer_followup_message(p_followup_id uuid)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_order uuid; v_msg text;
begin
  perform public.require_auth();
  select order_id into v_order from public.customer_followups where id=p_followup_id and followup_type='POST_SERVICE' and status <> 'SENT';
  if v_order is null then raise exception 'Seguimiento no encontrado o ya enviado'; end if;
  v_msg := public.build_post_service_message(v_order);
  update public.customer_followups set message=v_msg,updated_at=now() where id=p_followup_id;
  return v_msg;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.add_inventory_bonus_item(p_order_id uuid, p_inventory_item_id uuid, p_quantity numeric, p_reason text DEFAULT NULL::text, p_business_area text DEFAULT 'STORE'::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_item public.inventory_items;
  v_order public.orders;
  v_location uuid;
  v_stock numeric;
  v_bcv numeric;
  v_op numeric;
  v_order_item uuid;
  v_area text := upper(coalesce(p_business_area,'STORE'));
  v_reason text := nullif(trim(coalesce(p_reason,'')),'');
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  if p_quantity is null or p_quantity <= 0 then raise exception 'Cantidad inválida'; end if;
  if v_area not in ('STORE','OIL_CHANGE') then raise exception 'Área de bonificación inválida'; end if;

  select * into v_order from public.orders where id=p_order_id for update;
  select * into v_item from public.inventory_items where id=p_inventory_item_id and active=true;
  if v_item.id is null then raise exception 'Producto de inventario no encontrado'; end if;
  if v_item.needs_review then raise exception 'Este SKU requiere revisión de inventario antes de bonificarlo: %',v_item.sku; end if;

  v_location := v_order.location_id;
  if v_location is null then
    select id into v_location from public.locations where code='CABUDARE' and active=true limit 1;
    if v_location is null then select id into v_location from public.locations where active=true order by created_at limit 1; end if;
    update public.orders set location_id=v_location where id=p_order_id;
  end if;
  if v_location is null then raise exception 'No hay sede activa para descontar inventario'; end if;

  perform 1 from public.inventory_items where id=v_item.id for update;
  v_stock := public.inventory_quantity(v_item.id,v_location);
  if v_stock < p_quantity then
    raise exception 'Stock insuficiente para bonificar %: disponible %, solicitado %',v_item.sku,v_stock,p_quantity;
  end if;

  select bcv_rate,operative_rate into v_bcv,v_op from public.current_exchange_rates;
  if v_bcv is null or v_op is null then raise exception 'Debes registrar tasa BCV y operativa antes de registrar la cortesía'; end if;

  insert into public.order_items(
    order_id,item_type,business_area,description,product_id,inventory_item_id,inventory_location_id,
    quantity,pricing_mode,base_ref_amount,customer_ref_amount,
    charged_ves_amount,charged_ref_amount,cash_usd_unit_snapshot,cash_usd_special_total,
    bcv_rate_snapshot,operative_rate_snapshot,cash_price_revealed
  ) values (
    p_order_id,'PRODUCT',v_area,
    '🎁 Cortesía · '||v_item.sku||' · '||v_item.description||case when v_reason is not null then ' · '||v_reason else '' end,
    v_item.product_id,v_item.id,v_location,
    p_quantity,'BONUS',0,0,0,0,null,null,v_bcv,v_op,false
  ) returning id into v_order_item;

  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('order.bonus_product_added','order_item',v_order_item,
         jsonb_build_object('order_id',p_order_id,'inventory_item_id',v_item.id,'sku',v_item.sku,'quantity',p_quantity,'reason',v_reason));

  return v_order_item;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.upsert_supplier(p_id uuid, p_name text, p_legal_name text DEFAULT NULL::text, p_rif text DEFAULT NULL::text, p_phone text DEFAULT NULL::text, p_email text DEFAULT NULL::text, p_address text DEFAULT NULL::text, p_contact_name text DEFAULT NULL::text, p_bank_details text DEFAULT NULL::text, p_default_currency text DEFAULT 'USD'::text, p_payment_terms_days integer DEFAULT 0, p_notes text DEFAULT NULL::text, p_active boolean DEFAULT true)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid;
begin
  perform public.require_auth();
  if coalesce(trim(p_name),'')='' then raise exception 'El nombre del proveedor es obligatorio'; end if;
  if upper(p_default_currency) not in ('USD','VES') then raise exception 'Moneda inválida'; end if;
  if p_id is null then
    insert into public.suppliers(name,legal_name,rif,phone,email,address,contact_name,bank_details,default_currency,payment_terms_days,notes,active)
    values(trim(p_name),nullif(trim(p_legal_name),''),nullif(trim(p_rif),''),nullif(trim(p_phone),''),nullif(trim(p_email),''),nullif(trim(p_address),''),nullif(trim(p_contact_name),''),nullif(trim(p_bank_details),''),upper(p_default_currency),coalesce(p_payment_terms_days,0),nullif(trim(p_notes),''),coalesce(p_active,true)) returning id into v_id;
  else
    update public.suppliers set name=trim(p_name),legal_name=nullif(trim(p_legal_name),''),rif=nullif(trim(p_rif),''),phone=nullif(trim(p_phone),''),email=nullif(trim(p_email),''),address=nullif(trim(p_address),''),contact_name=nullif(trim(p_contact_name),''),bank_details=nullif(trim(p_bank_details),''),default_currency=upper(p_default_currency),payment_terms_days=coalesce(p_payment_terms_days,0),notes=nullif(trim(p_notes),''),active=coalesce(p_active,true),updated_at=now() where id=p_id returning id into v_id;
    if v_id is null then raise exception 'Proveedor no encontrado'; end if;
  end if;
  insert into public.audit_events(event_type,entity_type,entity_id,data) values(case when p_id is null then 'supplier.created' else 'supplier.updated' end,'supplier',v_id,jsonb_build_object('name',trim(p_name),'rif',nullif(trim(p_rif),'')));
  return v_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.create_supplier_invoice(p_supplier_id uuid, p_invoice_number text, p_invoice_date date, p_due_date date, p_currency text, p_items jsonb, p_tax numeric DEFAULT 0, p_discount numeric DEFAULT 0, p_freight numeric DEFAULT 0, p_notes text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid; v_item jsonb; v_subtotal numeric:=0; v_total numeric; v_bcv numeric; v_op numeric; v_currency text:=upper(coalesce(p_currency,'')); v_inventory uuid; v_type text; v_qty numeric; v_cost numeric; v_description text;
begin
  perform public.require_auth();
  if not exists(select 1 from public.suppliers where id=p_supplier_id and active) then raise exception 'Proveedor no encontrado o inactivo'; end if;
  if coalesce(trim(p_invoice_number),'')='' then raise exception 'Indica el número de factura'; end if;
  if p_invoice_date is null or p_invoice_date > timezone('America/Caracas',now())::date then raise exception 'Fecha de factura inválida'; end if;
  if p_due_date is not null and p_due_date < p_invoice_date then raise exception 'El vencimiento no puede ser anterior a la factura'; end if;
  if v_currency not in ('USD','VES') then raise exception 'Moneda inválida'; end if;
  if jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'Agrega al menos una línea a la factura'; end if;
  select value into v_bcv from public.exchange_rates where rate_type='BCV' and timezone('America/Caracas',effective_at)::date<=p_invoice_date order by effective_at desc limit 1;
  select value into v_op from public.exchange_rates where rate_type='OPERATIVE' and timezone('America/Caracas',effective_at)::date<=p_invoice_date order by effective_at desc limit 1;
  if v_bcv is null or v_op is null then select bcv_rate,operative_rate into v_bcv,v_op from public.current_exchange_rates; end if;
  if v_bcv is null or v_bcv<=0 or v_op is null or v_op<=0 then raise exception 'No hay tasas para la fecha de la factura'; end if;
  for v_item in select value from jsonb_array_elements(p_items) loop
    v_qty:=coalesce((v_item->>'quantity')::numeric,0); v_cost:=coalesce((v_item->>'unit_cost')::numeric,-1);
    if v_qty<=0 or v_cost<0 then raise exception 'Revisa cantidad y costo de cada línea'; end if;
    v_subtotal:=v_subtotal+v_qty*v_cost;
  end loop;
  v_total:=round(v_subtotal+coalesce(p_tax,0)+coalesce(p_freight,0)-coalesce(p_discount,0),2);
  if v_total<0 then raise exception 'El total de la factura no puede ser negativo'; end if;
  insert into public.supplier_invoices(supplier_id,invoice_number,invoice_date,due_date,currency,bcv_rate_snapshot,operative_rate_snapshot,subtotal_original,tax_original,discount_original,freight_original,total_original,notes)
  values(p_supplier_id,trim(p_invoice_number),p_invoice_date,p_due_date,v_currency,v_bcv,v_op,round(v_subtotal,2),coalesce(p_tax,0),coalesce(p_discount,0),coalesce(p_freight,0),v_total,nullif(trim(p_notes),'')) returning id into v_id;
  for v_item in select value from jsonb_array_elements(p_items) loop
    v_type:=upper(coalesce(v_item->>'line_type','')); v_inventory:=nullif(v_item->>'inventory_item_id','')::uuid; v_qty:=(v_item->>'quantity')::numeric; v_cost:=(v_item->>'unit_cost')::numeric; v_description:=trim(coalesce(v_item->>'description',''));
    if v_type not in ('INVENTORY','EXPENSE') then raise exception 'Tipo de línea inválido'; end if;
    if v_type='INVENTORY' then
      select coalesce(nullif(v_description,''),description) into v_description from public.inventory_items where id=v_inventory and active;
      if not found then raise exception 'Producto de inventario no encontrado'; end if;
    elsif v_description='' then raise exception 'Describe la línea de gasto'; end if;
    insert into public.supplier_invoice_items(supplier_invoice_id,line_type,inventory_item_id,description,expense_category,quantity,unit_cost_original,unit_cost_ref,line_total_original)
    values(v_id,v_type,v_inventory,v_description,nullif(trim(v_item->>'expense_category'),''),v_qty,v_cost,case when v_currency='USD' then v_cost else round(v_cost/v_bcv,4) end,round(v_qty*v_cost,2));
  end loop;
  insert into public.audit_events(event_type,entity_type,entity_id,data) values('supplier_invoice.created','supplier_invoice',v_id,jsonb_build_object('supplier_id',p_supplier_id,'invoice_number',trim(p_invoice_number),'currency',v_currency,'total',v_total));
  return v_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.receive_supplier_invoice(p_invoice_id uuid, p_received_on date, p_items jsonb DEFAULT NULL::jsonb, p_location_id uuid DEFAULT NULL::uuid, p_notes text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_invoice public.supplier_invoices; v_receipt uuid; v_location uuid; v_line public.supplier_invoice_items; v_payload jsonb; v_qty numeric; v_old_qty numeric; v_old_cost numeric; v_new_cost numeric; v_receipt_item uuid; v_count integer:=0;
begin
  perform public.require_auth();
  select * into v_invoice from public.supplier_invoices where id=p_invoice_id for update;
  if not found or v_invoice.status='VOID' then raise exception 'Factura de proveedor no disponible'; end if;
  if p_received_on is null or p_received_on>timezone('America/Caracas',now())::date then raise exception 'Fecha de recepción inválida'; end if;
  if p_location_id is null then select id into v_location from public.locations where active order by created_at limit 1; else v_location:=p_location_id; end if;
  if not exists(select 1 from public.locations where id=v_location and active) then raise exception 'Ubicación no disponible'; end if;
  insert into public.supplier_receipts(supplier_invoice_id,location_id,received_on,notes) values(p_invoice_id,v_location,p_received_on,nullif(trim(p_notes),'')) returning id into v_receipt;
  for v_line in select * from public.supplier_invoice_items where supplier_invoice_id=p_invoice_id and line_type='INVENTORY' order by created_at loop
    if p_items is null then v_qty:=v_line.quantity-v_line.received_quantity;
    else select value into v_payload from jsonb_array_elements(p_items) where value->>'line_id'=v_line.id::text limit 1; v_qty:=coalesce((v_payload->>'quantity')::numeric,0); end if;
    if v_qty<=0 then continue; end if;
    if v_line.received_quantity+v_qty>v_line.quantity then raise exception 'La recepción supera la cantidad facturada para %',v_line.description; end if;
    select coalesce(sum(quantity_delta),0) into v_old_qty from public.inventory_movements where inventory_item_id=v_line.inventory_item_id;
    select average_cost_ref into v_old_cost from public.inventory_items where id=v_line.inventory_item_id for update;
    v_new_cost:=case when v_old_qty>0 then round((v_old_qty*v_old_cost+v_qty*v_line.unit_cost_ref)/(v_old_qty+v_qty),4) else v_line.unit_cost_ref end;
    update public.inventory_items set average_cost_ref=v_new_cost,last_purchase_cost_ref=v_line.unit_cost_ref,last_purchased_at=((p_received_on::timestamp+time '12:00') at time zone 'America/Caracas'),updated_at=now() where id=v_line.inventory_item_id;
    insert into public.supplier_receipt_items(supplier_receipt_id,supplier_invoice_item_id,inventory_item_id,quantity,unit_cost_ref) values(v_receipt,v_line.id,v_line.inventory_item_id,v_qty,v_line.unit_cost_ref) returning id into v_receipt_item;
    insert into public.inventory_movements(inventory_item_id,location_id,quantity_delta,movement_type,note,occurred_at,supplier_receipt_item_id) values(v_line.inventory_item_id,v_location,v_qty,'PURCHASE','Recepción factura '||v_invoice.invoice_number,((p_received_on::timestamp+time '12:00') at time zone 'America/Caracas'),v_receipt_item);
    update public.supplier_invoice_items set received_quantity=received_quantity+v_qty where id=v_line.id;
    v_count:=v_count+1;
  end loop;
  if v_count=0 then delete from public.supplier_receipts where id=v_receipt; raise exception 'No hay cantidades pendientes para recibir'; end if;
  insert into public.audit_events(event_type,entity_type,entity_id,data) values('supplier_receipt.posted','supplier_receipt',v_receipt,jsonb_build_object('invoice_id',p_invoice_id,'received_on',p_received_on,'lines',v_count));
  return v_receipt;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.record_supplier_payment(p_invoice_id uuid, p_account_id uuid, p_amount numeric, p_paid_on date, p_reference text DEFAULT NULL::text, p_note text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_invoice public.supplier_invoices; v_account public.financial_accounts; v_bcv numeric; v_op numeric; v_value_ves numeric; v_value_ref numeric; v_applied numeric; v_remaining numeric; v_movement uuid; v_id uuid; v_status text;
begin
  perform public.require_auth();
  select * into v_invoice from public.supplier_invoices where id=p_invoice_id for update;
  if not found or v_invoice.status in ('VOID','PAID') then raise exception 'La factura no tiene saldo pendiente'; end if;
  select * into v_account from public.financial_accounts where id=p_account_id and active and account_type<>'RELATED';
  if not found then raise exception 'Cuenta de pago no disponible'; end if;
  if p_amount is null or p_amount<=0 then raise exception 'Monto inválido'; end if;
  if p_paid_on is null or p_paid_on>timezone('America/Caracas',now())::date then raise exception 'Fecha de pago inválida'; end if;
  select value into v_bcv from public.exchange_rates where rate_type='BCV' and timezone('America/Caracas',effective_at)::date<=p_paid_on order by effective_at desc limit 1;
  select value into v_op from public.exchange_rates where rate_type='OPERATIVE' and timezone('America/Caracas',effective_at)::date<=p_paid_on order by effective_at desc limit 1;
  if v_bcv is null or v_op is null then select bcv_rate,operative_rate into v_bcv,v_op from public.current_exchange_rates; end if;
  v_value_ves:=case when v_account.currency='USD' then round(p_amount*v_op,2) else round(p_amount,2) end;
  v_value_ref:=round(v_value_ves/v_bcv,4);
  v_applied:=case when v_invoice.currency='USD' then v_value_ref else v_value_ves end;
  v_remaining:=greatest(v_invoice.total_original-v_invoice.paid_original,0);
  if v_applied > (v_remaining + (case when v_invoice.currency='USD' then 0.05 else 1 end)) then raise exception 'El pago supera el saldo pendiente'; end if;
  v_applied:=least(v_applied,v_remaining);
  insert into public.account_movements(account_id,direction,movement_type,currency,amount_original,value_ves,category,payee,note,reference,occurred_at)
  select p_account_id,'OUT','SUPPLIER_PAYMENT',v_account.currency,p_amount,v_value_ves,'Pago a proveedor',s.name,nullif(trim(p_note),''),nullif(trim(p_reference),''),((p_paid_on::timestamp+time '12:00') at time zone 'America/Caracas') from public.suppliers s where s.id=v_invoice.supplier_id returning id into v_movement;
  insert into public.supplier_payments(supplier_invoice_id,account_id,account_movement_id,currency,amount_original,amount_applied_invoice,value_ves,value_ref,paid_on,reference,note)
  values(p_invoice_id,p_account_id,v_movement,v_account.currency,p_amount,v_applied,v_value_ves,v_value_ref,p_paid_on,nullif(trim(p_reference),''),nullif(trim(p_note),'')) returning id into v_id;
  v_status:=case when v_invoice.paid_original+v_applied >= (v_invoice.total_original - (case when v_invoice.currency='USD' then 0.05 else 1 end)) then 'PAID' else 'PARTIAL' end;
  update public.supplier_invoices set paid_original=case when v_status='PAID' then total_original else round(paid_original+v_applied,2) end,status=v_status,updated_at=now() where id=p_invoice_id;
  insert into public.audit_events(event_type,entity_type,entity_id,data) values('supplier_payment.recorded','supplier_payment',v_id,jsonb_build_object('invoice_id',p_invoice_id,'movement_id',v_movement,'amount',p_amount,'currency',v_account.currency,'applied',v_applied));
  return v_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.void_supplier_invoice(p_invoice_id uuid, p_reason text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  perform public.require_auth();
  if not lubricenter_private.is_order_admin() then raise exception 'Solo la cuenta administradora puede anular facturas de proveedor'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Indica el motivo'; end if;
  if exists(select 1 from public.supplier_receipts where supplier_invoice_id=p_invoice_id and status='POSTED') or exists(select 1 from public.supplier_payments where supplier_invoice_id=p_invoice_id) then raise exception 'Esta factura ya tiene recepciones o pagos y no se puede anular directamente'; end if;
  update public.supplier_invoices set status='VOID',voided_at=now(),voided_by=auth.uid(),void_reason=trim(p_reason),updated_at=now() where id=p_invoice_id and status<>'VOID';
  if not found then raise exception 'Factura no encontrada o ya anulada'; end if;
  insert into public.audit_events(event_type,entity_type,entity_id,data) values('supplier_invoice.voided','supplier_invoice',p_invoice_id,jsonb_build_object('reason',trim(p_reason)));
end;
$function$
;
CREATE OR REPLACE FUNCTION public.add_service_item(p_order_id uuid, p_business_area text, p_description text, p_base_ref numeric, p_customer_ref numeric, p_worker_share_override_ref numeric DEFAULT NULL::numeric, p_alexis_bonus_enabled boolean DEFAULT false)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_bcv numeric; v_op numeric; v_step numeric; v_mode text;
  v_worker uuid; v_bonus_employee uuid; v_worker_pct numeric := 0; v_bonus_pct numeric := 0;
  v_worker_ref numeric := 0; v_bonus_ref numeric := 0; v_lc_ref numeric := 0; v_item_id uuid;
  v_requested_area text := upper(coalesce(p_business_area,''));
  v_area text;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  if v_requested_area not in ('WORKSHOP','ELECTROAUTO','OIL_CHANGE','STORE') then raise exception 'Área de servicio inválida'; end if;
  -- The dedicated oil-change module uses add_oil_change_package/add_oil_change_item.
  -- Legacy generic UI value OIL_CHANGE therefore means a generic Lubricenter service.
  v_area := case when v_requested_area='OIL_CHANGE' then 'STORE' else v_requested_area end;
  if coalesce(trim(p_description),'') = '' then raise exception 'Descripción requerida'; end if;
  if p_base_ref <= 0 or p_customer_ref < 0 then raise exception 'Montos inválidos'; end if;
  select bcv_rate, operative_rate into v_bcv, v_op from public.current_exchange_rates;
  if v_bcv is null or v_op is null then raise exception 'Debes registrar tasa BCV y operativa antes de vender'; end if;
  select coalesce((value #>> '{}')::numeric,10) into v_step from public.app_settings where key='price_rounding_step';
  select coalesce(value #>> '{}','nearest') into v_mode from public.app_settings where key='price_rounding_mode';

  if v_area = 'WORKSHOP' then
    select id into v_worker from public.employees where code='CHEO' and active=true;
    select id into v_bonus_employee from public.employees where code='ALEXIS' and active=true;
    v_worker_pct := coalesce(public.compensation_value('CHEO','WORKSHOP_PERCENT',current_date),40);
    v_worker_ref := coalesce(p_worker_share_override_ref, round(p_base_ref * v_worker_pct / 100,4));
    if p_alexis_bonus_enabled then
      v_bonus_pct := coalesce(public.compensation_value('ALEXIS','ASSISTANT_BONUS_PERCENT',current_date),5);
      v_bonus_ref := round(p_base_ref * v_bonus_pct / 100,4);
    end if;
  elsif v_area = 'ELECTROAUTO' then
    select id into v_worker from public.employees where code='ALEXIS' and active=true;
    v_worker_pct := coalesce(public.compensation_value('ALEXIS','ELECTROAUTO_PERCENT',current_date),40);
    v_worker_ref := coalesce(p_worker_share_override_ref, round(p_base_ref * v_worker_pct / 100,4));
  end if;

  if v_worker_ref < 0 or v_bonus_ref < 0 then raise exception 'Las participaciones no pueden ser negativas'; end if;
  v_lc_ref := p_customer_ref - v_worker_ref - v_bonus_ref;
  if v_lc_ref < 0 then raise exception 'El monto al cliente no cubre la parte protegida del trabajador/bono. Ajusta el reparto explícitamente.'; end if;

  insert into public.order_items(
    order_id,item_type,business_area,description,quantity,pricing_mode,
    base_ref_amount,customer_ref_amount,charged_ves_amount,charged_ref_amount,
    bcv_rate_snapshot,operative_rate_snapshot,
    worker_employee_id,worker_share_percent_snapshot,worker_share_ref_snapshot,
    assistant_bonus_employee_id,assistant_bonus_percent_snapshot,assistant_bonus_ref_snapshot
  ) values (
    p_order_id,'SERVICE',v_area,trim(p_description),1,'STANDARD',
    p_base_ref,p_customer_ref,
    round(public.round_to_step(p_customer_ref * v_bcv,coalesce(v_step,10),coalesce(v_mode,'nearest')),2),
    round(p_customer_ref,4),v_bcv,v_op,
    v_worker,case when v_worker is not null then v_worker_pct end,case when v_worker is not null then v_worker_ref end,
    case when v_bonus_ref > 0 then v_bonus_employee end,case when v_bonus_ref > 0 then v_bonus_pct end,case when v_bonus_ref > 0 then v_bonus_ref end
  ) returning id into v_item_id;
  return v_item_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.supplier_invoice_detail(p_invoice_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_result jsonb;
begin
  perform public.require_auth();
  select jsonb_build_object(
    'invoice',to_jsonb(i)||jsonb_build_object('supplier_name',s.name,'supplier_rif',s.rif,'outstanding_original',greatest(i.total_original-i.paid_original,0)),
    'items',coalesce((select jsonb_agg(to_jsonb(x) order by x.created_at) from public.supplier_invoice_items x where x.supplier_invoice_id=i.id),'[]'::jsonb),
    'receipts',coalesce((select jsonb_agg(to_jsonb(r) order by r.received_on desc,r.created_at desc) from public.supplier_receipts r where r.supplier_invoice_id=i.id),'[]'::jsonb),
    'payments',coalesce((select jsonb_agg(to_jsonb(sp)||jsonb_build_object('account_name',fa.name) order by sp.paid_on desc,sp.created_at desc) from public.supplier_payments sp join public.financial_accounts fa on fa.id=sp.account_id where sp.supplier_invoice_id=i.id),'[]'::jsonb),
    'accounts',coalesce((select jsonb_agg(to_jsonb(a) order by a.account_type,a.name) from public.account_balances_current a where a.active and a.account_type not in ('RELATED','CLEARING')),'[]'::jsonb),
    'locations',coalesce((select jsonb_agg(to_jsonb(l) order by l.name) from public.locations l where l.active),'[]'::jsonb)
  ) into v_result from public.supplier_invoices i join public.suppliers s on s.id=i.supplier_id where i.id=p_invoice_id;
  if v_result is null then raise exception 'Factura no encontrada'; end if;
  return v_result;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.close_order(p_order_id uuid)
 RETURNS TABLE(order_number text, total_ves numeric, total_ref numeric, total_cash_usd_equivalent numeric)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_order public.orders;
  v_total_ves numeric; v_total_ref numeric; v_paid_ves numeric; v_op numeric; v_cash numeric;
  i public.order_items;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  select * into v_order from public.orders where id=p_order_id for update;
  select coalesce(sum(charged_ves_amount),0),coalesce(sum(charged_ref_amount),0) into v_total_ves,v_total_ref from public.order_items where order_id=p_order_id;
  if v_total_ves <= 0 then raise exception 'La orden no tiene items'; end if;
  select coalesce(sum(value_ves),0) into v_paid_ves from public.payments where order_id=p_order_id;
  if v_paid_ves + 1 < v_total_ves then raise exception 'Falta por cobrar Bs %', round(v_total_ves-v_paid_ves,2); end if;
  if v_paid_ves > v_total_ves + 1 then raise exception 'El pago excede el total de la orden en Bs %', round(v_paid_ves-v_total_ves,2); end if;
  select coalesce(sum(charged_ves_amount / nullif(operative_rate_snapshot,0)),0) into v_cash
  from public.order_items where order_id=p_order_id;

  update public.orders set status='CLOSED',closed_at=now(),total_ves=round(v_total_ves,2),total_ref=round(v_total_ref,4),total_cash_usd_equivalent=round(v_cash,4) where id=p_order_id;

  for i in select * from public.order_items where order_id=p_order_id loop
    if i.business_area='WORKSHOP' and coalesce(i.worker_share_ref_snapshot,0)>0 then
      insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description,occurred_at)
      values(i.worker_employee_id,i.id,'WORKSHOP_COMMISSION',i.worker_share_ref_snapshot,'40% taller · '||i.description,now())
      on conflict do nothing;
    end if;
    if i.business_area='WORKSHOP' and coalesce(i.assistant_bonus_ref_snapshot,0)>0 then
      insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description,occurred_at)
      values(i.assistant_bonus_employee_id,i.id,'ASSISTANT_BONUS',i.assistant_bonus_ref_snapshot,'Bono ayudante · '||i.description,now())
      on conflict do nothing;
    end if;
    if i.business_area='ELECTROAUTO' and coalesce(i.worker_share_ref_snapshot,0)>0 then
      insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description,occurred_at)
      values(i.worker_employee_id,i.id,'ELECTROAUTO_COMMISSION',i.worker_share_ref_snapshot,'Electroauto · '||i.description,now())
      on conflict do nothing;
    end if;
  end loop;

  insert into public.integration_events(event_type,aggregate_type,aggregate_id,payload)
  values('order.closed','order',p_order_id,jsonb_build_object('order_number',v_order.order_number,'total_ves',v_total_ves,'total_ref',v_total_ref));
  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('order.closed','order',p_order_id,jsonb_build_object('total_ves',v_total_ves,'total_ref',v_total_ref,'paid_ves',v_paid_ves));

  return query select v_order.order_number,round(v_total_ves,2),round(v_total_ref,4),round(v_cash,4);
end;
$function$
;
CREATE OR REPLACE FUNCTION public.purchasing_dashboard(p_from date DEFAULT NULL::date, p_to date DEFAULT NULL::date)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_from date:=coalesce(p_from,date_trunc('month',timezone('America/Caracas',now()))::date); v_to date:=coalesce(p_to,timezone('America/Caracas',now())::date); v_result jsonb;
begin
  perform public.require_auth();
  if v_from>v_to or v_to-v_from>366 then raise exception 'Rango de fechas inválido'; end if;
  select jsonb_build_object(
    'period',jsonb_build_object('from',v_from,'to',v_to),
    'summary',jsonb_build_object(
      'invoiced_ref',coalesce((select sum(case when currency='USD' then total_original else total_original/bcv_rate_snapshot end) from public.supplier_invoices where status<>'VOID' and invoice_date between v_from and v_to),0),
      'paid_ves',coalesce((select sum(value_ves) from public.supplier_payments where paid_on between v_from and v_to),0),
      'payable_ref',coalesce((select sum(case when currency='USD' then total_original-paid_original else (total_original-paid_original)/bcv_rate_snapshot end) from public.supplier_invoices where status in ('OPEN','PARTIAL')),0),
      'overdue',coalesce((select count(*) from public.supplier_invoices where status in ('OPEN','PARTIAL') and due_date<timezone('America/Caracas',now())::date),0),
      'suppliers',coalesce((select count(*) from public.suppliers where active),0)
    ),
    'suppliers',coalesce((select jsonb_agg(to_jsonb(x) order by x.name) from (select s.*,count(i.id) invoice_count,coalesce(sum(case when i.status in ('OPEN','PARTIAL') then case when i.currency='USD' then i.total_original-i.paid_original else (i.total_original-i.paid_original)/i.bcv_rate_snapshot end else 0 end),0) payable_ref from public.suppliers s left join public.supplier_invoices i on i.supplier_id=s.id group by s.id) x),'[]'::jsonb),
    'invoices',coalesce((select jsonb_agg(to_jsonb(x) order by x.invoice_date desc,x.created_at desc) from (select i.*,s.name supplier_name,greatest(i.total_original-i.paid_original,0) outstanding_original,coalesce((select sum(si.received_quantity) from public.supplier_invoice_items si where si.supplier_invoice_id=i.id and si.line_type='INVENTORY'),0) received_units,coalesce((select sum(si.quantity) from public.supplier_invoice_items si where si.supplier_invoice_id=i.id and si.line_type='INVENTORY'),0) invoiced_units from public.supplier_invoices i join public.suppliers s on s.id=i.supplier_id where i.invoice_date between v_from and v_to order by i.invoice_date desc limit 200) x),'[]'::jsonb),
    'accounts',coalesce((select jsonb_agg(to_jsonb(a) order by a.account_type,a.name) from public.account_balances_current a where a.active and a.account_type not in ('RELATED','CLEARING')),'[]'::jsonb)
  ) into v_result;
  return v_result;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.cash_close_dashboard(p_business_date date DEFAULT NULL::date)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_day date:=coalesce(p_business_date,timezone('America/Caracas',now())::date); v_location uuid; v_closing public.cash_closings; v_accounts jsonb;
begin
  perform public.require_auth();
  select id into v_location from public.locations where active order by created_at limit 1;
  select * into v_closing from public.cash_closings where business_date=v_day and location_id=v_location;
  with amounts as (
    select a.id,a.code,a.name,a.currency,a.account_type,
      coalesce(sum(case when m.occurred_at<((v_day::timestamp) at time zone 'America/Caracas') then case when m.direction='IN' then m.amount_original else -m.amount_original end else 0 end),0) opening_native,
      coalesce(sum(case when m.direction='IN' and timezone('America/Caracas',m.occurred_at)::date=v_day then m.amount_original else 0 end),0) system_in_native,
      coalesce(sum(case when m.direction='OUT' and timezone('America/Caracas',m.occurred_at)::date=v_day then m.amount_original else 0 end),0) system_out_native
    from public.financial_accounts a left join public.account_movements m on m.account_id=a.id
    where a.active and a.account_type not in ('RELATED','CLEARING') group by a.id
  )
  select coalesce(jsonb_agg(to_jsonb(x) order by x.account_type,x.name),'[]'::jsonb) into v_accounts
  from (select a.*,a.opening_native+a.system_in_native-a.system_out_native expected_native,
    d.actual_native,d.difference_native,d.explanation,d.denomination_counts,d.updated_at counted_at
    from amounts a left join public.cash_closing_accounts d on d.cash_closing_id=v_closing.id and d.account_id=a.id) x;
  return jsonb_build_object('business_date',v_day,'location_id',v_location,'status',coalesce(v_closing.status,'OPEN'),'closing',case when v_closing.id is null then null else to_jsonb(v_closing) end,'accounts',v_accounts);
end;
$function$
;
CREATE OR REPLACE FUNCTION public.dashboard_today()
 RETURNS TABLE(orders_today bigint, sales_ves numeric, sales_ref numeric, open_orders bigint, payroll_pending_ref numeric, bcv_rate numeric, operative_rate numeric)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  with d as (select (now() at time zone 'America/Caracas')::date as today),
  r as (select * from public.current_exchange_rates)
  select
    (select count(*) from public.orders,d where status='CLOSED' and (closed_at at time zone 'America/Caracas')::date=d.today),
    (select coalesce(sum(total_ves),0) from public.orders,d where status='CLOSED' and (closed_at at time zone 'America/Caracas')::date=d.today),
    (select coalesce(sum(total_ref),0) from public.orders,d where status='CLOSED' and (closed_at at time zone 'America/Caracas')::date=d.today),
    (select count(*) from public.orders where status='OPEN'),
    (select coalesce(sum(amount_ref),0) from public.payroll_accruals where payroll_run_id is null),
    r.bcv_rate,
    r.operative_rate
  from r;
$function$
;
CREATE OR REPLACE FUNCTION public.compensation_value(p_employee_code text, p_rule_type text, p_on date DEFAULT CURRENT_DATE)
 RETURNS numeric
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select cr.value
  from public.compensation_rules cr
  join public.employees e on e.id = cr.employee_id
  where e.code = p_employee_code
    and cr.rule_type = p_rule_type
    and cr.valid_from <= p_on
    and (cr.valid_to is null or cr.valid_to >= p_on)
  order by cr.valid_from desc, cr.created_at desc
  limit 1;
$function$
;
CREATE OR REPLACE FUNCTION public.set_customer_followup_status(p_followup_id uuid, p_status text, p_snoozed_until date DEFAULT NULL::date)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  perform public.require_auth();
  if upper(coalesce(p_status,'')) not in ('PENDING','SENT','SNOOZED') then raise exception 'Estado inválido'; end if;
  update public.customer_followups
     set status=upper(p_status),
         sent_at=case when upper(p_status)='SENT' then now() else sent_at end,
         snoozed_until=case when upper(p_status)='SNOOZED' then p_snoozed_until else null end,
         updated_at=now()
   where id=p_followup_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.save_cash_count(p_business_date date, p_account_id uuid, p_actual_native numeric, p_explanation text DEFAULT NULL::text, p_denominations jsonb DEFAULT '{}'::jsonb)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_location uuid; v_closing public.cash_closings; v_open numeric; v_in numeric; v_out numeric; v_expected numeric;
begin
  perform public.require_auth();
  if p_business_date is null or p_business_date>timezone('America/Caracas',now())::date then raise exception 'Fecha de cuadre inválida'; end if;
  if p_actual_native is null or p_actual_native<0 then raise exception 'El saldo contado no puede ser negativo'; end if;
  if not exists(select 1 from public.financial_accounts where id=p_account_id and active and account_type not in ('RELATED','CLEARING')) then raise exception 'Cuenta no disponible para cuadre'; end if;
  select id into v_location from public.locations where active order by created_at limit 1;
  insert into public.cash_closings(business_date,location_id) values(p_business_date,v_location) on conflict(business_date,location_id) do nothing;
  select * into v_closing from public.cash_closings where business_date=p_business_date and location_id=v_location for update;
  if v_closing.status='CLOSED' then raise exception 'El día está cerrado. La cuenta administradora debe reabrirlo para modificarlo'; end if;
  select coalesce(sum(case when direction='IN' then amount_original else -amount_original end) filter(where occurred_at<((p_business_date::timestamp) at time zone 'America/Caracas')),0),coalesce(sum(amount_original) filter(where direction='IN' and timezone('America/Caracas',occurred_at)::date=p_business_date),0),coalesce(sum(amount_original) filter(where direction='OUT' and timezone('America/Caracas',occurred_at)::date=p_business_date),0) into v_open,v_in,v_out from public.account_movements where account_id=p_account_id;
  v_expected:=v_open+v_in-v_out;
  insert into public.cash_closing_accounts(cash_closing_id,account_id,opening_native,system_in_native,system_out_native,expected_native,actual_native,difference_native,explanation,denomination_counts,updated_by,updated_at)
  values(v_closing.id,p_account_id,v_open,v_in,v_out,v_expected,p_actual_native,p_actual_native-v_expected,nullif(trim(p_explanation),''),coalesce(p_denominations,'{}'::jsonb),auth.uid(),now())
  on conflict(cash_closing_id,account_id) do update set opening_native=excluded.opening_native,system_in_native=excluded.system_in_native,system_out_native=excluded.system_out_native,expected_native=excluded.expected_native,actual_native=excluded.actual_native,difference_native=excluded.difference_native,explanation=excluded.explanation,denomination_counts=excluded.denomination_counts,updated_by=auth.uid(),updated_at=now();
  return v_closing.id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.close_cash_day(p_business_date date, p_notes text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_location uuid; v_closing public.cash_closings; v_missing integer; v_unexplained integer;
begin
  perform public.require_auth();
  select id into v_location from public.locations where active order by created_at limit 1;
  select * into v_closing from public.cash_closings where business_date=p_business_date and location_id=v_location for update;
  if not found then raise exception 'Primero cuenta los saldos de cada cuenta'; end if;
  if v_closing.status='CLOSED' then return v_closing.id; end if;
  if v_closing.status='REVIEW' and not lubricenter_private.is_order_admin() then raise exception 'Este cierre cambió después de cerrarse. Solo la cuenta administradora puede revisarlo y cerrarlo otra vez'; end if;
  perform public.save_cash_count(p_business_date,a.account_id,a.actual_native,a.explanation,a.denomination_counts) from public.cash_closing_accounts a where a.cash_closing_id=v_closing.id and a.actual_native is not null;
  select count(*) into v_missing from public.financial_accounts a where a.active and a.account_type not in ('RELATED','CLEARING') and not exists(select 1 from public.cash_closing_accounts d where d.cash_closing_id=v_closing.id and d.account_id=a.id and d.actual_native is not null);
  if v_missing>0 then raise exception 'Falta contar % cuenta(s)',v_missing; end if;
  select count(*) into v_unexplained from public.cash_closing_accounts d join public.financial_accounts a on a.id=d.account_id where d.cash_closing_id=v_closing.id and abs(d.difference_native)>case when a.currency='USD' then 0.01 else 1 end and coalesce(trim(d.explanation),'')='';
  if v_unexplained>0 then raise exception 'Explica las diferencias antes de cerrar'; end if;
  update public.cash_closings set status='CLOSED',notes=nullif(trim(p_notes),''),closed_by=auth.uid(),closed_at=now(),review_reason=null,updated_at=now() where id=v_closing.id;
  insert into public.audit_events(event_type,entity_type,entity_id,data) values('cash_close.closed','cash_closing',v_closing.id,jsonb_build_object('business_date',p_business_date));
  return v_closing.id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.reopen_cash_day(p_business_date date, p_reason text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_location uuid; v_id uuid;
begin
  perform public.require_auth();
  if not lubricenter_private.is_order_admin() then raise exception 'Solo la cuenta administradora puede reabrir un cuadre'; end if;
  if coalesce(trim(p_reason),'')='' then raise exception 'Indica el motivo de reapertura'; end if;
  select id into v_location from public.locations where active order by created_at limit 1;
  update public.cash_closings set status='REOPENED',reopened_by=auth.uid(),reopened_at=now(),reopen_reason=trim(p_reason),updated_at=now() where business_date=p_business_date and location_id=v_location and status in ('CLOSED','REVIEW') returning id into v_id;
  if v_id is null then raise exception 'No hay un cuadre cerrado para reabrir'; end if;
  insert into public.audit_events(event_type,entity_type,entity_id,data) values('cash_close.reopened','cash_closing',v_id,jsonb_build_object('business_date',p_business_date,'reason',trim(p_reason)));
  return v_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.upsert_vehicle(p_customer_id uuid DEFAULT NULL::uuid, p_plate text DEFAULT NULL::text, p_make text DEFAULT NULL::text, p_model text DEFAULT NULL::text, p_year integer DEFAULT NULL::integer, p_engine text DEFAULT NULL::text, p_current_odometer integer DEFAULT NULL::integer)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_id uuid;
  v_plate text := nullif(upper(trim(p_plate)),'');
  v_make text := nullif(trim(p_make),'');
  v_model text := nullif(trim(p_model),'');
  v_engine text := nullif(trim(p_engine),'');
begin
  perform public.require_auth();
  if p_customer_id is not null and not exists(select 1 from public.customers where id=p_customer_id) then
    raise exception 'Cliente no encontrado';
  end if;
  if v_plate is null and v_make is null and v_model is null then
    raise exception 'Debes indicar placa, marca o modelo';
  end if;
  if p_year is not null and (p_year < 1900 or p_year > extract(year from current_date)::int + 1) then
    raise exception 'Año de vehículo inválido';
  end if;
  if p_current_odometer is not null and p_current_odometer < 0 then
    raise exception 'Kilometraje inválido';
  end if;

  if v_plate is not null then
    select id into v_id from public.vehicles where upper(plate)=v_plate limit 1;
  end if;

  if v_id is null then
    insert into public.vehicles(customer_id,plate,make,model,year,engine,current_odometer)
    values(p_customer_id,v_plate,v_make,v_model,p_year,v_engine,p_current_odometer)
    returning id into v_id;
  else
    update public.vehicles
    set customer_id = coalesce(p_customer_id,customer_id),
        plate = coalesce(v_plate,plate),
        make = coalesce(v_make,make),
        model = coalesce(v_model,model),
        year = coalesce(p_year,year),
        engine = coalesce(v_engine,engine),
        current_odometer = case
          when p_current_odometer is null then current_odometer
          when current_odometer is null then p_current_odometer
          else greatest(current_odometer,p_current_odometer)
        end
    where id=v_id;
  end if;

  return v_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.assert_notion_pricing_fresh()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_catalog_sync timestamptz;
  v_rate_sync timestamptz;
begin
  select coalesce(
    (select s.last_verified_at from public.integration_sync_state s where s.source_key='notion_catalog'),
    (select max(p.catalog_synced_at) from public.products p where p.catalog_source='Notion · Nuestros Productos')
  ) into v_catalog_sync;

  select coalesce(
    (select s.last_verified_at from public.integration_sync_state s where s.source_key='notion_rates'),
    least(
      (select r.effective_at from public.exchange_rates r where r.rate_type='BCV' order by r.effective_at desc limit 1),
      (select r.effective_at from public.exchange_rates r where r.rate_type='OPERATIVE' order by r.effective_at desc limit 1)
    )
  ) into v_rate_sync;

  if v_catalog_sync is null or v_catalog_sync < now() - interval '24 hours' then
    raise exception 'Catálogo de Notion desactualizado. Sincroniza precios antes de vender productos.';
  end if;
  if v_rate_sync is null or v_rate_sync < now() - interval '3 hours' then
    raise exception 'Tasas de Notion desactualizadas. Sincroniza BCV y P2P antes de vender productos.';
  end if;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.set_order_crm_extras(p_order_id uuid, p_additional_services text[] DEFAULT '{}'::text[], p_bonuses text[] DEFAULT '{}'::text[], p_observations text DEFAULT NULL::text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  update public.orders
     set crm_additional_services = coalesce(p_additional_services,'{}'),
         crm_bonuses = coalesce(p_bonuses,'{}'),
         crm_observations = nullif(trim(coalesce(p_observations,'')),'')
   where id=p_order_id;
  if not found then raise exception 'Orden no encontrada'; end if;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.build_post_service_message(p_order_id uuid)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_name text; v_plate text; v_vehicle text; v_order_number text;
  v_health text; v_health_notes text; v_observations text;
  v_additional text[]; v_bonuses text[];
  v_services text; v_products text; v_additional_lines text; v_bonus_lines text; v_physical_bonus_lines text;
  v_sr public.service_records;
  v_template text; v_msg text;
  v_vehicle_block text := ''; v_services_block text := ''; v_products_block text := '';
  v_oil_block text := ''; v_additional_block text := ''; v_bonus_block text := '';
  v_observations_block text := ''; v_health_block text := ''; v_next_block text := '';
  v_km text := ''; nl text := chr(10);
begin
  select coalesce(nullif(trim(c.name),''),'Estimado cliente'), v.plate,
         nullif(trim(concat_ws(' ',v.make,v.model)),''), o.order_number,
         o.health_status, o.health_notes, o.crm_observations,
         o.crm_additional_services, o.crm_bonuses
    into v_name,v_plate,v_vehicle,v_order_number,v_health,v_health_notes,v_observations,v_additional,v_bonuses
  from public.orders o
  left join public.customers c on c.id=o.customer_id
  left join public.vehicles v on v.id=o.vehicle_id
  where o.id=p_order_id;
  if not found then raise exception 'Orden no encontrada'; end if;

  select string_agg('• '||description, nl order by created_at)
    into v_services
  from public.order_items
  where order_id=p_order_id and business_area in ('WORKSHOP','ELECTROAUTO','OIL_CHANGE') and item_type <> 'PRODUCT';

  select string_agg('• '||description||case when quantity<>1 then ' ×'||trim(to_char(quantity,'FM999999990.##')) else '' end, nl order by created_at)
    into v_products
  from public.order_items
  where order_id=p_order_id and item_type='PRODUCT' and pricing_mode <> 'BONUS';

  select string_agg('• '||regexp_replace(description,'^🎁 Cortesía · ','')||case when quantity<>1 then ' ×'||trim(to_char(quantity,'FM999999990.##')) else '' end, nl order by created_at)
    into v_physical_bonus_lines
  from public.order_items
  where order_id=p_order_id and item_type='PRODUCT' and pricing_mode='BONUS';

  select string_agg('• '||x, nl) into v_additional_lines
  from unnest(coalesce(v_additional,'{}'::text[])) x where nullif(trim(x),'') is not null;
  select string_agg('• '||x, nl) into v_bonus_lines
  from unnest(coalesce(v_bonuses,'{}'::text[])) x where nullif(trim(x),'') is not null;

  if v_physical_bonus_lines is not null then
    v_bonus_lines := case when v_bonus_lines is null then v_physical_bonus_lines else v_bonus_lines||nl||v_physical_bonus_lines end;
  end if;

  select * into v_sr from public.service_records where order_id=p_order_id order by performed_at desc limit 1;

  if v_vehicle is not null then v_vehicle_block := '🚗 *Vehículo:* '||v_vehicle||nl; end if;
  if v_plate is not null then v_vehicle_block := v_vehicle_block||'🔢 *Placa:* '||v_plate||nl; end if;
  if v_sr.id is not null and v_sr.odometer is not null then
    v_km := to_char(v_sr.odometer,'FM999G999G999')||' km';
    v_vehicle_block := v_vehicle_block||'📟 *Kilometraje:* '||v_km||nl;
  end if;
  v_vehicle_block := rtrim(v_vehicle_block);

  if v_services is not null then v_services_block := '🔧 *Servicios realizados:*'||nl||v_services; end if;
  if v_products is not null then v_products_block := '📦 *Productos / repuestos:*'||nl||v_products; end if;

  if v_sr.id is not null and (v_sr.oil_brand is not null or v_sr.oil_viscosity is not null or v_sr.oil_filter_code is not null) then
    v_oil_block := '🛢️ *Cambio de aceite:*'||nl;
    if v_sr.oil_brand is not null or v_sr.oil_viscosity is not null then
      v_oil_block := v_oil_block||'• Aceite: '||trim(concat_ws(' ',v_sr.oil_brand,v_sr.oil_viscosity))||nl;
    end if;
    if v_sr.oil_filter_code is not null then v_oil_block := v_oil_block||'• Filtro: '||v_sr.oil_filter_code||nl; end if;
    v_oil_block := rtrim(v_oil_block);
  end if;

  if v_additional_lines is not null then v_additional_block := '🛠️ *Servicios adicionales incluidos:*'||nl||v_additional_lines; end if;
  if v_bonus_lines is not null then v_bonus_block := '🎁 *Bonificaciones incluidas:*'||nl||v_bonus_lines; end if;
  if v_observations is not null then v_observations_block := '💬 *Observaciones:*'||nl||v_observations; end if;

  if v_health='RED' then
    v_health_block := '🚨 *Alerta de seguridad:* El servicio solicitado está listo, pero detectamos una condición que requiere atención.';
    if nullif(trim(coalesce(v_health_notes,'')),'') is not null then v_health_block := v_health_block||nl||'_'||v_health_notes||'_'; end if;
    v_health_block := v_health_block||nl||'Su seguridad es nuestra prioridad.';
  elsif v_health='YELLOW' then
    v_health_block := '⚠️ *Observación preventiva:* El trabajo principal está listo.';
    if nullif(trim(coalesce(v_health_notes,'')),'') is not null then v_health_block := v_health_block||nl||'_'||v_health_notes||'_'; end if;
  else
    v_health_block := '✅ *Estado general:* Servicio finalizado. ¡Listo para la vía!';
  end if;

  if v_sr.id is not null and (v_sr.next_service_odometer is not null or v_sr.next_service_date is not null) then
    v_next_block := '🗓️ *Próximo servicio:*'||nl;
    if v_sr.next_service_odometer is not null then v_next_block := v_next_block||'• Recomendado a los '||to_char(v_sr.next_service_odometer,'FM999G999G999')||' km'||nl; end if;
    if v_sr.next_service_date is not null then v_next_block := v_next_block||'• Fecha estimada: '||to_char(v_sr.next_service_date,'DD/MM/YYYY')||nl; end if;
    v_next_block := rtrim(v_next_block)||nl||'¡Nosotros te enviaremos un recordatorio!';
  end if;

  select value #>> '{}' into v_template from public.app_settings where key='crm_post_service_template';
  if nullif(v_template,'') is null then
    v_template := 'Hola *{{nombre}}*! 👋'||nl||nl||'Gracias por tu visita a *Lubricenter*.'||nl||nl||'{{vehiculo_bloque}}'||nl||nl||'{{servicios_bloque}}'||nl||nl||'{{productos_bloque}}'||nl||nl||'{{cambio_aceite_bloque}}'||nl||nl||'{{servicios_adicionales_bloque}}'||nl||nl||'{{bonificaciones_bloque}}'||nl||nl||'{{observaciones_bloque}}'||nl||nl||'{{estado_bloque}}'||nl||nl||'{{proximo_servicio_bloque}}'||nl||nl||'¡Gracias por preferir *Lubricenter*!';
  end if;

  v_msg := v_template;
  v_msg := replace(v_msg,'{{nombre}}',coalesce(v_name,''));
  v_msg := replace(v_msg,'{{orden}}',coalesce(v_order_number,''));
  v_msg := replace(v_msg,'{{vehiculo}}',coalesce(v_vehicle,''));
  v_msg := replace(v_msg,'{{placa}}',coalesce(v_plate,''));
  v_msg := replace(v_msg,'{{kilometraje}}',coalesce(v_km,''));
  v_msg := replace(v_msg,'{{servicios_lista}}',coalesce(v_services,''));
  v_msg := replace(v_msg,'{{productos_lista}}',coalesce(v_products,''));
  v_msg := replace(v_msg,'{{servicios_adicionales_lista}}',coalesce(v_additional_lines,''));
  v_msg := replace(v_msg,'{{bonificaciones_lista}}',coalesce(v_bonus_lines,''));
  v_msg := replace(v_msg,'{{observaciones}}',coalesce(v_observations,''));
  v_msg := replace(v_msg,'{{vehiculo_bloque}}',coalesce(v_vehicle_block,''));
  v_msg := replace(v_msg,'{{servicios_bloque}}',coalesce(v_services_block,''));
  v_msg := replace(v_msg,'{{productos_bloque}}',coalesce(v_products_block,''));
  v_msg := replace(v_msg,'{{cambio_aceite_bloque}}',coalesce(v_oil_block,''));
  v_msg := replace(v_msg,'{{servicios_adicionales_bloque}}',coalesce(v_additional_block,''));
  v_msg := replace(v_msg,'{{bonificaciones_bloque}}',coalesce(v_bonus_block,''));
  v_msg := replace(v_msg,'{{observaciones_bloque}}',coalesce(v_observations_block,''));
  v_msg := replace(v_msg,'{{estado_bloque}}',coalesce(v_health_block,''));
  v_msg := replace(v_msg,'{{proximo_servicio_bloque}}',coalesce(v_next_block,''));
  v_msg := regexp_replace(v_msg, E'\n[ \t]+\n', E'\n\n', 'g');
  v_msg := regexp_replace(v_msg, E'\n{3,}', E'\n\n', 'g');
  return trim(v_msg);
end;
$function$
;
CREATE OR REPLACE FUNCTION public.set_order_customer_vehicle(p_order_id uuid, p_customer_id uuid DEFAULT NULL::uuid, p_vehicle_id uuid DEFAULT NULL::uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);

  if p_customer_id is not null and not exists(select 1 from public.customers where id = p_customer_id) then
    raise exception 'Cliente no encontrado';
  end if;

  if p_vehicle_id is not null and not exists(select 1 from public.vehicles where id = p_vehicle_id) then
    raise exception 'Vehículo no encontrado';
  end if;

  if p_vehicle_id is not null and p_customer_id is not null then
    update public.vehicles
      set customer_id = coalesce(customer_id, p_customer_id), updated_at = now()
    where id = p_vehicle_id;
  end if;

  update public.orders
    set customer_id = p_customer_id,
        vehicle_id = p_vehicle_id
  where id = p_order_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.upsert_customer(p_name text DEFAULT NULL::text, p_phone text DEFAULT NULL::text, p_document_id text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_id uuid;
  v_name text := nullif(trim(p_name),'');
  v_phone text := nullif(trim(p_phone),'');
  v_doc text := nullif(trim(p_document_id),'');
begin
  perform public.require_auth();
  if v_name is null and v_phone is null and v_doc is null then
    raise exception 'Debes indicar nombre, teléfono o documento';
  end if;

  select id into v_id
  from public.customers
  where (v_phone is not null and phone = v_phone)
     or (v_doc is not null and document_id = v_doc)
  order by updated_at desc
  limit 1;

  if v_id is null then
    insert into public.customers(name,phone,document_id)
    values(v_name,v_phone,v_doc)
    returning id into v_id;
  else
    update public.customers
    set name = coalesce(v_name,name),
        phone = coalesce(v_phone,phone),
        document_id = coalesce(v_doc,document_id)
    where id=v_id;
  end if;

  return v_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.update_customer_followup_message(p_followup_id uuid, p_message text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  perform public.require_auth();
  if length(trim(coalesce(p_message,''))) < 2 then raise exception 'El mensaje no puede quedar vacío'; end if;
  update public.customer_followups set message=p_message,updated_at=now()
   where id=p_followup_id and followup_type='POST_SERVICE' and status <> 'SENT';
  if not found then raise exception 'Seguimiento no encontrado o ya enviado'; end if;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.close_order_with_credit(p_order_id uuid, p_due_date date DEFAULT NULL::date)
 RETURNS TABLE(order_number text, total_ves numeric, total_ref numeric, receivable_id uuid, outstanding_ves numeric, outstanding_ref numeric)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_order public.orders;
  v_total_ves numeric;
  v_total_ref numeric;
  v_paid_ves numeric;
  v_paid_ref numeric;
  v_outstanding_ves numeric;
  v_outstanding_ref numeric;
  v_cash numeric;
  v_receivable_id uuid;
  i public.order_items;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);

  select * into v_order
  from public.orders
  where id = p_order_id
  for update;

  select coalesce(sum(charged_ves_amount),0),
         coalesce(sum(charged_ref_amount),0)
    into v_total_ves, v_total_ref
  from public.order_items
  where order_id = p_order_id;

  if v_total_ves <= 0 then
    raise exception 'La orden no tiene items';
  end if;

  select coalesce(sum(value_ves),0),
         coalesce(sum(value_ref),0)
    into v_paid_ves, v_paid_ref
  from public.payments
  where order_id = p_order_id;

  if v_paid_ves > v_total_ves + 1 then
    raise exception 'El pago excede el total de la orden en Bs %', round(v_paid_ves-v_total_ves,2);
  end if;

  v_outstanding_ves := greatest(v_total_ves - v_paid_ves, 0);
  v_outstanding_ref := greatest(v_total_ref - v_paid_ref, 0);

  -- If the order is already effectively paid, use the normal close path.
  if v_outstanding_ves <= 1 then
    perform public.close_order(p_order_id);
    return query
      select v_order.order_number,
             round(v_total_ves,2),
             round(v_total_ref,4),
             null::uuid,
             0::numeric,
             0::numeric;
    return;
  end if;

  if v_order.customer_id is null then
    raise exception 'Credito LC requiere un cliente asociado a la orden';
  end if;

  if exists(select 1 from public.receivables r where r.order_id=p_order_id) then
    raise exception 'La orden ya tiene una cuenta por cobrar';
  end if;

  insert into public.receivables(
    order_id, debtor_type, customer_id,
    principal_ves, principal_ref, outstanding_ves,
    status, due_date
  )
  values(
    p_order_id, 'CUSTOMER', v_order.customer_id,
    round(v_outstanding_ves,2),
    greatest(round(v_outstanding_ref,4), 0.0001),
    round(v_outstanding_ves,2),
    'OPEN', p_due_date
  )
  returning id into v_receivable_id;

  select coalesce(sum(charged_ves_amount / nullif(operative_rate_snapshot,0)),0)
    into v_cash
  from public.order_items
  where order_id=p_order_id;

  update public.orders
  set status='CLOSED',
      closed_at=now(),
      total_ves=round(v_total_ves,2),
      total_ref=round(v_total_ref,4),
      total_cash_usd_equivalent=round(v_cash,4)
  where id=p_order_id;

  for i in select * from public.order_items where order_id=p_order_id loop
    if i.business_area='WORKSHOP' and coalesce(i.worker_share_ref_snapshot,0)>0 then
      insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description,occurred_at)
      values(i.worker_employee_id,i.id,'WORKSHOP_COMMISSION',i.worker_share_ref_snapshot,'40% taller · '||i.description,now())
      on conflict do nothing;
    end if;
    if i.business_area='WORKSHOP' and coalesce(i.assistant_bonus_ref_snapshot,0)>0 then
      insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description,occurred_at)
      values(i.assistant_bonus_employee_id,i.id,'ASSISTANT_BONUS',i.assistant_bonus_ref_snapshot,'Bono ayudante · '||i.description,now())
      on conflict do nothing;
    end if;
    if i.business_area='ELECTROAUTO' and coalesce(i.worker_share_ref_snapshot,0)>0 then
      insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description,occurred_at)
      values(i.worker_employee_id,i.id,'ELECTROAUTO_COMMISSION',i.worker_share_ref_snapshot,'Electroauto · '||i.description,now())
      on conflict do nothing;
    end if;
  end loop;

  insert into public.integration_events(event_type,aggregate_type,aggregate_id,payload)
  values(
    'order.closed','order',p_order_id,
    jsonb_build_object(
      'order_number',v_order.order_number,
      'total_ves',v_total_ves,
      'total_ref',v_total_ref,
      'payment_status','CREDIT_LC',
      'receivable_id',v_receivable_id,
      'outstanding_ves',v_outstanding_ves,
      'outstanding_ref',v_outstanding_ref
    )
  );

  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values(
    'order.closed_credit_lc','order',p_order_id,
    jsonb_build_object(
      'total_ves',v_total_ves,
      'total_ref',v_total_ref,
      'paid_ves',v_paid_ves,
      'outstanding_ves',v_outstanding_ves,
      'outstanding_ref',v_outstanding_ref,
      'receivable_id',v_receivable_id
    )
  );

  return query
    select v_order.order_number,
           round(v_total_ves,2),
           round(v_total_ref,4),
           v_receivable_id,
           round(v_outstanding_ves,2),
           round(v_outstanding_ref,4);
end;
$function$
;
CREATE OR REPLACE FUNCTION public.record_credit_payment(p_receivable_id uuid, p_method text, p_amount_original numeric, p_reference text DEFAULT NULL::text)
 RETURNS TABLE(payment_id uuid, outstanding_ves numeric, status text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_receivable public.receivables;
  v_method text := upper(p_method);
  v_currency text;
  v_bcv numeric;
  v_op numeric;
  v_value_ves numeric;
  v_value_ref numeric;
  v_new_outstanding numeric;
  v_payment_id uuid;
  v_new_status text;
begin
  perform public.require_auth();

  select * into v_receivable
  from public.receivables
  where id = p_receivable_id
  for update;

  if not found then
    raise exception 'Cuenta por cobrar no encontrada';
  end if;

  if v_receivable.status <> 'OPEN' then
    raise exception 'La cuenta por cobrar no está abierta';
  end if;

  if v_method not in ('CASH_USD','CASH_VES','MOBILE_PAYMENT','TRANSFER_BDV','TRANSFER_BNC') then
    raise exception 'Método de pago inválido';
  end if;

  if p_amount_original <= 0 then
    raise exception 'Monto de pago inválido';
  end if;

  select bcv_rate, operative_rate
    into v_bcv, v_op
  from public.current_exchange_rates;

  if v_bcv is null or v_op is null then
    raise exception 'Debes registrar tasas antes de cobrar';
  end if;

  v_currency := case when v_method='CASH_USD' then 'USD' else 'VES' end;
  v_value_ves := case when v_currency='USD' then p_amount_original * v_op else p_amount_original end;
  v_value_ref := v_value_ves / v_bcv;

  if v_value_ves > v_receivable.outstanding_ves + 1 then
    raise exception 'El abono excede el saldo pendiente en Bs %', round(v_value_ves - v_receivable.outstanding_ves,2);
  end if;

  insert into public.payments(
    order_id, receivable_id, method, currency, amount_original,
    bcv_rate_snapshot, operative_rate_snapshot,
    value_ves, value_ref, reference, paid_at
  )
  values(
    v_receivable.order_id, p_receivable_id, v_method, v_currency, p_amount_original,
    v_bcv, v_op,
    round(v_value_ves,2), round(v_value_ref,4), nullif(trim(p_reference),''), now()
  )
  returning id into v_payment_id;

  v_new_outstanding := greatest(v_receivable.outstanding_ves - v_value_ves, 0);
  v_new_status := case when v_new_outstanding <= 1 then 'PAID' else 'OPEN' end;

  update public.receivables
  set outstanding_ves = case when v_new_status='PAID' then 0 else round(v_new_outstanding,2) end,
      status = v_new_status,
      closed_at = case when v_new_status='PAID' then now() else null end
  where id = p_receivable_id;

  insert into public.integration_events(event_type,aggregate_type,aggregate_id,payload)
  values(
    case when v_new_status='PAID' then 'receivable.paid' else 'receivable.payment_recorded' end,
    'receivable',p_receivable_id,
    jsonb_build_object(
      'order_id',v_receivable.order_id,
      'payment_id',v_payment_id,
      'method',v_method,
      'currency',v_currency,
      'amount_original',p_amount_original,
      'value_ves',v_value_ves,
      'outstanding_ves',greatest(v_new_outstanding,0),
      'status',v_new_status
    )
  );

  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values(
    'receivable.payment_recorded','receivable',p_receivable_id,
    jsonb_build_object(
      'payment_id',v_payment_id,
      'method',v_method,
      'amount_original',p_amount_original,
      'value_ves',v_value_ves,
      'new_outstanding_ves',greatest(v_new_outstanding,0),
      'status',v_new_status
    )
  );

  return query
  select v_payment_id,
         case when v_new_status='PAID' then 0::numeric else round(v_new_outstanding,2) end,
         v_new_status;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.add_oil_change_item(p_order_id uuid, p_description text, p_base_ref numeric, p_customer_ref numeric, p_odometer integer, p_oil_brand text DEFAULT NULL::text, p_oil_viscosity text DEFAULT NULL::text, p_oil_quantity_liters numeric DEFAULT NULL::numeric, p_filter_code text DEFAULT NULL::text, p_next_km_interval integer DEFAULT NULL::integer, p_next_months integer DEFAULT NULL::integer)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_vehicle_id uuid;
  v_current_odometer integer;
  v_bcv numeric;
  v_op numeric;
  v_step numeric;
  v_mode text;
  v_default_km integer;
  v_default_months integer;
  v_interval_km integer;
  v_interval_months integer;
  v_item_id uuid;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);

  select o.vehicle_id, v.current_odometer
    into v_vehicle_id, v_current_odometer
  from public.orders o
  left join public.vehicles v on v.id=o.vehicle_id
  where o.id=p_order_id;

  if v_vehicle_id is null then
    raise exception 'Para registrar un cambio de aceite debes asociar un vehículo a la orden';
  end if;
  if coalesce(trim(p_description),'')='' then
    raise exception 'Descripción requerida';
  end if;
  if p_base_ref < 0 or p_customer_ref < 0 then
    raise exception 'Montos inválidos';
  end if;
  if p_odometer is null or p_odometer < 0 then
    raise exception 'Kilometraje requerido';
  end if;
  if v_current_odometer is not null and p_odometer < v_current_odometer then
    raise exception 'El kilometraje % es menor al registrado actualmente (%)', p_odometer, v_current_odometer;
  end if;
  if p_oil_quantity_liters is not null and p_oil_quantity_liters <= 0 then
    raise exception 'Cantidad de aceite inválida';
  end if;

  select bcv_rate,operative_rate into v_bcv,v_op from public.current_exchange_rates;
  if v_bcv is null or v_op is null then
    raise exception 'Debes registrar tasa BCV y operativa antes de vender';
  end if;
  select coalesce((value #>> '{}')::numeric,10) into v_step from public.app_settings where key='price_rounding_step';
  select coalesce(value #>> '{}','nearest') into v_mode from public.app_settings where key='price_rounding_mode';
  select coalesce((value #>> '{}')::integer,5000) into v_default_km from public.app_settings where key='oil_change_default_km';
  select coalesce((value #>> '{}')::integer,3) into v_default_months from public.app_settings where key='oil_change_default_months';

  v_interval_km := coalesce(p_next_km_interval,v_default_km,5000);
  v_interval_months := coalesce(p_next_months,v_default_months,3);
  if v_interval_km < 0 or v_interval_km > 50000 then raise exception 'Intervalo de kilometraje inválido'; end if;
  if v_interval_months < 0 or v_interval_months > 24 then raise exception 'Intervalo de meses inválido'; end if;

  insert into public.order_items(
    order_id,item_type,business_area,description,quantity,pricing_mode,
    base_ref_amount,customer_ref_amount,charged_ves_amount,charged_ref_amount,
    bcv_rate_snapshot,operative_rate_snapshot,
    service_odometer,oil_brand,oil_viscosity,oil_quantity_liters,oil_filter_code,
    next_service_odometer,next_service_date
  ) values (
    p_order_id,'SERVICE','OIL_CHANGE',trim(p_description),1,'STANDARD',
    p_base_ref,p_customer_ref,
    round(public.round_to_step(p_customer_ref*v_bcv,coalesce(v_step,10),coalesce(v_mode,'nearest')),2),
    round(p_customer_ref,4),v_bcv,v_op,
    p_odometer,nullif(trim(p_oil_brand),''),nullif(trim(p_oil_viscosity),''),p_oil_quantity_liters,nullif(trim(p_filter_code),''),
    case when v_interval_km > 0 then p_odometer+v_interval_km else null end,
    case when v_interval_months > 0 then current_date + make_interval(months=>v_interval_months) else null end
  ) returning id into v_item_id;

  return v_item_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.capture_service_records_on_close()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_max_odometer integer;
  v_next_odometer integer;
  v_next_date date;
begin
  if new.status='CLOSED' and old.status is distinct from 'CLOSED' and new.vehicle_id is not null then
    insert into public.service_records(
      order_id,order_item_id,customer_id,vehicle_id,service_type,description,odometer,
      oil_brand,oil_viscosity,oil_quantity_liters,oil_filter_code,
      next_service_odometer,next_service_date,charged_ref_amount,charged_ves_amount,performed_at,created_by
    )
    select
      new.id,oi.id,new.customer_id,new.vehicle_id,
      case when oi.business_area in ('OIL_CHANGE','WORKSHOP','ELECTROAUTO') then oi.business_area else 'OTHER' end,
      oi.description,
      coalesce(oi.service_odometer,v.current_odometer),
      oi.oil_brand,oi.oil_viscosity,oi.oil_quantity_liters,oi.oil_filter_code,
      oi.next_service_odometer,oi.next_service_date,
      oi.charged_ref_amount,oi.charged_ves_amount,coalesce(new.closed_at,now()),new.created_by
    from public.order_items oi
    join public.vehicles v on v.id=new.vehicle_id
    where oi.order_id=new.id and oi.item_type='SERVICE'
    on conflict (order_item_id) do nothing;

    select max(coalesce(oi.service_odometer,0)) into v_max_odometer
    from public.order_items oi
    where oi.order_id=new.id and oi.item_type='SERVICE' and oi.service_odometer is not null;

    if v_max_odometer is not null and v_max_odometer > 0 then
      update public.vehicles
      set current_odometer=case when current_odometer is null then v_max_odometer else greatest(current_odometer,v_max_odometer) end,
          updated_at=now()
      where id=new.vehicle_id;
    end if;

    select oi.next_service_odometer,oi.next_service_date
      into v_next_odometer,v_next_date
    from public.order_items oi
    where oi.order_id=new.id and oi.business_area='OIL_CHANGE'
    order by oi.created_at desc
    limit 1;

    insert into public.integration_events(event_type,aggregate_type,aggregate_id,payload)
    values(
      'vehicle.service_history_updated','vehicle',new.vehicle_id,
      jsonb_build_object(
        'order_id',new.id,
        'order_number',new.order_number,
        'customer_id',new.customer_id,
        'vehicle_id',new.vehicle_id,
        'next_service_odometer',v_next_odometer,
        'next_service_date',v_next_date,
        'has_oil_change',v_next_odometer is not null or v_next_date is not null
      )
    );
  end if;
  return new;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.sync_catalog_products(p_products jsonb)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_op numeric;
  v_count integer := 0;
  v_item jsonb;
  v_name text;
  v_seen text[] := array[]::text[];
begin
  perform public.require_auth();
  if jsonb_typeof(p_products) <> 'array' then raise exception 'El catálogo debe ser un arreglo de productos'; end if;

  select operative_rate into v_op from public.current_exchange_rates;
  if v_op is null or v_op <= 0 then raise exception 'Debes registrar la tasa operativa antes de sincronizar catálogo'; end if;

  for v_item in select value from jsonb_array_elements(p_products) loop
    v_name := nullif(btrim(v_item->>'nombre'),'');
    if v_name is null then continue; end if;
    if coalesce((v_item->>'precio_bs')::numeric,0) <= 0 then continue; end if;

    v_seen := array_append(v_seen,lower(v_name));
    insert into public.products(name,category,available,active,cash_usd_base_price,notes,image_url,catalog_source,catalog_synced_at)
    values(
      v_name,
      nullif(btrim(v_item->>'categoria'),''),
      true,true,
      round((v_item->>'precio_bs')::numeric / v_op,4),
      nullif(btrim(v_item->>'descripcion'),''),
      nullif(btrim(v_item->>'imagen'),''),
      'catalogo-github',now()
    )
    on conflict ((lower(btrim(name)))) do update
      set category=excluded.category,
          available=true,
          active=true,
          cash_usd_base_price=excluded.cash_usd_base_price,
          notes=excluded.notes,
          image_url=excluded.image_url,
          catalog_source='catalogo-github',
          catalog_synced_at=now(),
          updated_at=now();
    v_count := v_count + 1;
  end loop;

  update public.products
  set active=false,available=false,updated_at=now()
  where catalog_source='catalogo-github'
    and not (lower(btrim(name)) = any(v_seen));

  -- Retire the two initial development-only filter examples.
  update public.products
  set active=false,available=false,updated_at=now()
  where filter_code in ('AL-3387','AL-3600') and catalog_source is null;

  insert into public.audit_events(event_type,entity_type,data)
  values('catalog.synced','catalog',jsonb_build_object('product_count',v_count,'operative_rate',v_op));

  return v_count;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.assign_payment_account()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_code text;
begin
  if new.financial_account_id is not null then return new; end if;
  v_code := case new.method
    when 'CASH_VES' then 'CASH_VES'
    when 'CASH_USD' then 'CASH_USD'
    when 'TRANSFER_BDV' then 'BDV'
    when 'TRANSFER_BNC' then 'BNC'
    when 'MOBILE_PAYMENT' then 'MOBILE'
    else null end;
  if v_code is null then raise exception 'No existe cuenta configurada para el método %',new.method; end if;
  select id into new.financial_account_id from public.financial_accounts where code=v_code and active=true;
  if new.financial_account_id is null then raise exception 'Cuenta financiera % no disponible',v_code; end if;
  return new;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.capture_payment_movement()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  insert into public.account_movements(account_id,direction,movement_type,source_payment_id,currency,amount_original,value_ves,reference,occurred_at,created_by)
  values(new.financial_account_id,'IN','PAYMENT',new.id,new.currency,new.amount_original,new.value_ves,new.reference,new.paid_at,new.created_by)
  on conflict (source_payment_id) where source_payment_id is not null do nothing;
  return new;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.get_inventory_snapshot(p_location_code text DEFAULT 'CABUDARE'::text)
 RETURNS TABLE(id uuid, sku text, brand text, description text, category text, unit text, source_cost_ref numeric, source_alert text, needs_review boolean, cost_missing boolean, location_code text, quantity_on_hand numeric, sellable_quantity numeric, product_id uuid, catalog_product_name text, current_price_ves numeric, current_ref_bcv numeric)
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select i.id,i.sku,i.brand,i.description,i.category,i.unit,i.source_cost_ref,i.source_alert,
         i.needs_review,i.cost_missing,i.location_code,i.quantity_on_hand,i.sellable_quantity,
         i.product_id,i.catalog_product_name,i.current_price_ves,i.current_ref_bcv
  from public.inventory_current i
  where i.location_code = p_location_code
  order by i.category nulls last, i.brand nulls last, i.sku;
$function$
;
CREATE OR REPLACE FUNCTION public.get_oil_change_inventory(p_location_code text DEFAULT 'CABUDARE'::text)
 RETURNS TABLE(id uuid, sku text, brand text, description text, category text, quantity_on_hand numeric, product_id uuid, catalog_product_name text, current_price_ves numeric, current_ref_bcv numeric, needs_review boolean)
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select i.id,i.sku,i.brand,i.description,i.category,i.quantity_on_hand,i.product_id,
         i.catalog_product_name,i.current_price_ves,i.current_ref_bcv,i.needs_review
  from public.inventory_current i
  where i.location_code = p_location_code
    and i.quantity_on_hand > 0
    and i.category in ('Aceite Motor','Aceite Motos','Filtro Aceite')
  order by i.category, i.brand nulls last, i.sku;
$function$
;
CREATE OR REPLACE FUNCTION public.close_order_with_partial_credit(p_order_id uuid, p_method text, p_amount_original numeric, p_reference text DEFAULT NULL::text, p_due_date date DEFAULT NULL::date)
 RETURNS TABLE(order_number text, total_ves numeric, total_ref numeric, payment_id uuid, receivable_id uuid, outstanding_ves numeric, outstanding_ref numeric)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_order public.orders;
  v_total_ves numeric;
  v_paid_ves numeric;
  v_bcv numeric;
  v_operative numeric;
  v_method text := upper(coalesce(p_method, ''));
  v_new_payment_ves numeric;
  v_payment_id uuid;
  v_credit record;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);

  if v_method not in ('CASH_USD','CASH_VES','MOBILE_PAYMENT','TRANSFER_BDV','TRANSFER_BNC') then
    raise exception 'Selecciona una forma de pago válida para el abono';
  end if;
  if p_amount_original is null or p_amount_original <= 0 then
    raise exception 'Indica un abono mayor que cero';
  end if;

  select * into v_order from public.orders where id = p_order_id for update;
  if v_order.customer_id is null then
    raise exception 'Crédito LC requiere un cliente asociado a la orden';
  end if;
  if exists(select 1 from public.receivables where order_id = p_order_id) then
    raise exception 'La orden ya tiene una cuenta por cobrar';
  end if;

  select coalesce(sum(charged_ves_amount), 0) into v_total_ves
  from public.order_items where order_id = p_order_id;
  select coalesce(sum(value_ves), 0) into v_paid_ves
  from public.payments where order_id = p_order_id;
  select bcv_rate, operative_rate into v_bcv, v_operative from public.current_exchange_rates;

  if v_total_ves <= 0 then raise exception 'Agrega productos o trabajos antes de cobrar'; end if;
  if v_bcv is null or v_operative is null then raise exception 'Debes registrar tasas antes de cobrar'; end if;
  v_new_payment_ves := case when v_method = 'CASH_USD' then p_amount_original * v_operative else p_amount_original end;
  if v_paid_ves + v_new_payment_ves >= v_total_ves - 1 then
    raise exception 'El abono cubre toda la orden. Usa “Cobro directo” para cerrarla como pagada';
  end if;

  v_payment_id := public.add_payment(p_order_id, v_method, p_amount_original, p_reference);
  select * into v_credit from public.close_order_with_credit(p_order_id, p_due_date);

  return query select
    v_credit.order_number,
    v_credit.total_ves,
    v_credit.total_ref,
    v_payment_id,
    v_credit.receivable_id,
    v_credit.outstanding_ves,
    v_credit.outstanding_ref;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.get_catalog_snapshot()
 RETURNS TABLE(id uuid, name text, category text, available boolean, active boolean, cash_usd_base_price numeric, current_price_ves numeric, current_ref_bcv numeric, image_url text, catalog_source text, catalog_synced_at timestamp with time zone)
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select p.id,p.name,p.category,p.available,p.active,p.cash_usd_base_price,
         c.current_price_ves,c.current_ref_bcv,p.image_url,p.catalog_source,p.catalog_synced_at
  from public.products p
  left join public.product_catalog_current c on c.id=p.id
  where p.active=true and p.available=true
  order by p.category nulls last,p.name;
$function$
;
CREATE OR REPLACE FUNCTION public.set_order_workflow_status(p_order_id uuid, p_status text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_status text := upper(coalesce(p_status,''));
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  if v_status not in ('RECEIVED','DIAGNOSIS','IN_PROGRESS','WAITING_PART','READY') then
    raise exception 'Estado operativo inválido';
  end if;
  update public.orders
     set workflow_status=v_status,
         workflow_updated_at=now()
   where id=p_order_id;
  if not found then raise exception 'Orden no encontrada'; end if;

  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('order.workflow_changed','order',p_order_id,jsonb_build_object('workflow_status',v_status));
end;
$function$
;
CREATE OR REPLACE FUNCTION public.quick_sale_partial_credit(p_items jsonb, p_customer_id uuid, p_method text, p_amount_original numeric, p_reference text DEFAULT NULL::text, p_due_date date DEFAULT NULL::date, p_business_at timestamp with time zone DEFAULT NULL::timestamp with time zone)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_sale record;
  v_credit record;
begin
  perform public.require_auth();
  if p_customer_id is null or not exists(select 1 from public.customers where id = p_customer_id) then
    raise exception 'Selecciona un cliente para dejar el saldo en Crédito LC';
  end if;

  perform set_config('lubricenter.business_at', coalesce(p_business_at::text, ''), true);
  select * into v_sale from public.build_quick_sale_order(p_items);
  perform public.set_order_party(v_sale.order_id, p_customer_id, null);
  select * into v_credit from public.close_order_with_partial_credit(
    v_sale.order_id, p_method, p_amount_original, p_reference, p_due_date
  );

  return jsonb_build_object(
    'order_id', v_sale.order_id,
    'order_number', v_credit.order_number,
    'total_ves', v_credit.total_ves,
    'total_ref', v_credit.total_ref,
    'payment_id', v_credit.payment_id,
    'receivable_id', v_credit.receivable_id,
    'outstanding_ves', v_credit.outstanding_ves,
    'outstanding_ref', v_credit.outstanding_ref
  );
end;
$function$
;
CREATE OR REPLACE FUNCTION public.record_account_expense(p_account_id uuid, p_amount numeric, p_category text, p_note text DEFAULT NULL::text, p_reference text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_account public.financial_accounts;
  v_op numeric;
  v_value_ves numeric;
  v_id uuid;
begin
  perform public.require_auth();
  select * into v_account from public.financial_accounts where id=p_account_id and active=true;
  if not found then raise exception 'Cuenta no encontrada'; end if;
  if p_amount <= 0 then raise exception 'Monto inválido'; end if;
  if coalesce(trim(p_category),'')='' then raise exception 'Categoría requerida'; end if;
  select operative_rate into v_op from public.current_exchange_rates;
  v_value_ves := case when v_account.currency='USD' then p_amount*v_op else p_amount end;
  insert into public.account_movements(account_id,direction,movement_type,currency,amount_original,value_ves,category,note,reference,occurred_at)
  values(p_account_id,'OUT','EXPENSE',v_account.currency,p_amount,round(v_value_ves,2),trim(p_category),nullif(trim(p_note),''),nullif(trim(p_reference),''),now())
  returning id into v_id;
  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('cash.expense_recorded','account_movement',v_id,jsonb_build_object('account_id',p_account_id,'amount',p_amount,'currency',v_account.currency,'category',p_category));
  return v_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.add_inventory_product_item(p_order_id uuid, p_inventory_item_id uuid, p_quantity numeric, p_manual_unit_ref numeric DEFAULT NULL::numeric, p_business_area text DEFAULT 'OIL_CHANGE'::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_item public.inventory_items;
  v_order public.orders;
  v_product public.products;
  v_location uuid;
  v_stock numeric;
  v_bcv numeric;
  v_op numeric;
  v_step numeric;
  v_mode text;
  v_unit_ves numeric;
  v_unit_ref numeric;
  v_cash_usd numeric;
  v_order_item uuid;
  v_area text := upper(coalesce(p_business_area,'OIL_CHANGE'));
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  if p_quantity is null or p_quantity <= 0 then raise exception 'Cantidad de inventario inválida'; end if;
  if v_area not in ('OIL_CHANGE','STORE') then raise exception 'Área de inventario inválida'; end if;

  select * into v_order from public.orders where id=p_order_id for update;
  select * into v_item from public.inventory_items where id=p_inventory_item_id and active=true;
  if v_item.id is null then raise exception 'Producto de inventario no encontrado'; end if;
  if v_item.needs_review then raise exception 'Este SKU requiere revisión de inventario antes de venderse: %', v_item.sku; end if;

  v_location := v_order.location_id;
  if v_location is null then
    select id into v_location from public.locations where code='CABUDARE' and active=true limit 1;
    if v_location is null then select id into v_location from public.locations where active=true order by created_at limit 1; end if;
    update public.orders set location_id=v_location where id=p_order_id;
  end if;
  if v_location is null then raise exception 'No hay sede activa para descontar inventario'; end if;

  perform 1 from public.inventory_items where id=v_item.id for update;
  v_stock := public.inventory_quantity(v_item.id,v_location);
  if v_stock < p_quantity then raise exception 'Stock insuficiente para %: disponible %, solicitado %', v_item.sku, v_stock, p_quantity; end if;

  select bcv_rate,operative_rate into v_bcv,v_op from public.current_exchange_rates;
  if v_bcv is null or v_op is null then raise exception 'Debes registrar tasa BCV y operativa antes de vender'; end if;
  select coalesce((value #>> '{}')::numeric,10) into v_step from public.app_settings where key='price_rounding_step';
  select coalesce(value #>> '{}','nearest') into v_mode from public.app_settings where key='price_rounding_mode';

  if p_manual_unit_ref is not null then
    if p_manual_unit_ref <= 0 then raise exception 'El precio manual debe ser mayor que cero'; end if;
    v_unit_ref := p_manual_unit_ref;
    v_unit_ves := public.round_to_step(v_unit_ref*v_bcv,coalesce(v_step,10),coalesce(v_mode,'nearest'));
    v_cash_usd := null;
  else
    if v_item.product_id is null then raise exception 'Este SKU no tiene precio de catálogo. Ingresa precio REF manual.'; end if;
    select * into v_product from public.products where id=v_item.product_id and active=true and available=true;
    if v_product.id is null then raise exception 'El producto de catálogo vinculado no está disponible'; end if;
    if v_product.catalog_source='Notion · Nuestros Productos' then perform public.assert_notion_pricing_fresh(); end if;
    v_cash_usd := v_product.cash_usd_base_price;
    v_unit_ves := public.round_to_step(v_product.cash_usd_base_price*v_op,coalesce(v_step,10),coalesce(v_mode,'nearest'));
    v_unit_ref := v_unit_ves/v_bcv;
  end if;

  insert into public.order_items(
    order_id,item_type,business_area,description,product_id,inventory_item_id,inventory_location_id,
    quantity,pricing_mode,base_ref_amount,customer_ref_amount,
    charged_ves_amount,charged_ref_amount,cash_usd_unit_snapshot,cash_usd_special_total,
    bcv_rate_snapshot,operative_rate_snapshot,cash_price_revealed
  ) values (
    p_order_id,'PRODUCT',v_area,v_item.sku||' · '||v_item.description,v_item.product_id,v_item.id,v_location,
    p_quantity,'STANDARD',round(v_unit_ref*p_quantity,4),round(v_unit_ref*p_quantity,4),
    round(v_unit_ves*p_quantity,2),round(v_unit_ref*p_quantity,4),v_cash_usd,
    case when v_cash_usd is not null then round(v_cash_usd*p_quantity,4) else null end,
    v_bcv,v_op,false
  ) returning id into v_order_item;
  return v_order_item;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.record_internal_transfer(p_from_account_id uuid, p_to_account_id uuid, p_amount numeric, p_note text DEFAULT NULL::text, p_reference text DEFAULT NULL::text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_from public.financial_accounts;
  v_to public.financial_accounts;
  v_op numeric;
  v_value_ves numeric;
  v_group uuid := gen_random_uuid();
begin
  perform public.require_auth();
  if p_from_account_id=p_to_account_id then raise exception 'Las cuentas deben ser distintas'; end if;
  if p_amount <= 0 then raise exception 'Monto inválido'; end if;
  select * into v_from from public.financial_accounts where id=p_from_account_id and active=true;
  select * into v_to from public.financial_accounts where id=p_to_account_id and active=true;
  if v_from.id is null or v_to.id is null then raise exception 'Cuenta no encontrada'; end if;
  if v_from.currency<>v_to.currency then raise exception 'En esta versión las transferencias internas deben usar la misma moneda'; end if;
  select operative_rate into v_op from public.current_exchange_rates;
  v_value_ves := case when v_from.currency='USD' then p_amount*v_op else p_amount end;
  insert into public.account_movements(account_id,direction,movement_type,transfer_group,currency,amount_original,value_ves,note,reference,occurred_at)
  values
    (p_from_account_id,'OUT','TRANSFER',v_group,v_from.currency,p_amount,round(v_value_ves,2),nullif(trim(p_note),''),nullif(trim(p_reference),''),now()),
    (p_to_account_id,'IN','TRANSFER',v_group,v_to.currency,p_amount,round(v_value_ves,2),nullif(trim(p_note),''),nullif(trim(p_reference),''),now());
  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('cash.internal_transfer','transfer',v_group,jsonb_build_object('from_account_id',p_from_account_id,'to_account_id',p_to_account_id,'amount',p_amount,'currency',v_from.currency));
  return v_group;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.inventory_quantity(p_inventory_item_id uuid, p_location_id uuid)
 RETURNS numeric
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select coalesce(sum(quantity_delta),0)
  from public.inventory_movements
  where inventory_item_id=p_inventory_item_id and location_id=p_location_id;
$function$
;
CREATE OR REPLACE FUNCTION public.delete_open_order(p_order_id uuid, p_reason text DEFAULT 'Orden duplicada'::text)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_order public.orders;
  v_number text;
begin
  perform public.require_auth();

  select * into v_order
  from public.orders
  where id = p_order_id
  for update;

  if v_order.id is null then
    raise exception 'Orden no encontrada';
  end if;

  if v_order.status <> 'OPEN' then
    raise exception 'Solo se pueden eliminar órdenes abiertas. Las órdenes cerradas se conservan por integridad contable.';
  end if;

  if exists (select 1 from public.receivables where order_id = p_order_id) then
    raise exception 'Esta orden tiene una cuenta por cobrar y no puede eliminarse.';
  end if;

  if exists (select 1 from public.service_records where order_id = p_order_id) then
    raise exception 'Esta orden ya generó historial de servicio y no puede eliminarse.';
  end if;

  if exists (
    select 1
    from public.inventory_movements m
    join public.order_items oi on oi.id = m.order_item_id
    where oi.order_id = p_order_id
  ) then
    raise exception 'Esta orden ya generó movimientos de inventario y no puede eliminarse.';
  end if;

  v_number := v_order.order_number;

  insert into public.audit_events(event_type, entity_type, entity_id, data, actor_id)
  values (
    'ORDER_DELETED',
    'ORDER',
    p_order_id,
    jsonb_build_object(
      'order_number', v_number,
      'reason', coalesce(nullif(trim(p_reason), ''), 'Orden duplicada'),
      'deleted_at', now()
    ),
    auth.uid()
  );

  delete from public.orders where id = p_order_id;
  return v_number;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.add_oil_change_package(p_order_id uuid, p_odometer integer, p_description text DEFAULT 'Cambio de aceite'::text, p_service_base_ref numeric DEFAULT 0, p_service_customer_ref numeric DEFAULT 0, p_oil_inventory_item_id uuid DEFAULT NULL::uuid, p_oil_units numeric DEFAULT NULL::numeric, p_oil_manual_unit_ref numeric DEFAULT NULL::numeric, p_oil_viscosity text DEFAULT NULL::text, p_oil_quantity_liters numeric DEFAULT NULL::numeric, p_filter_inventory_item_id uuid DEFAULT NULL::uuid, p_filter_units numeric DEFAULT 1, p_filter_manual_unit_ref numeric DEFAULT NULL::numeric, p_next_km_interval integer DEFAULT 5000, p_next_months integer DEFAULT 3)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_oil public.inventory_items;
  v_filter public.inventory_items;
  v_service_item uuid;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  if p_oil_inventory_item_id is null then raise exception 'Selecciona el aceite usado'; end if;
  if p_oil_units is null or p_oil_units <= 0 then raise exception 'Indica las unidades de aceite usadas'; end if;

  select * into v_oil from public.inventory_items where id=p_oil_inventory_item_id and active=true;
  if v_oil.id is null then raise exception 'Aceite no encontrado'; end if;
  if v_oil.category not in ('Aceite Motor','Aceite Motos','Aceite Hidraulico') then raise exception 'El SKU seleccionado no corresponde a un aceite'; end if;

  perform public.add_inventory_product_item(p_order_id,p_oil_inventory_item_id,p_oil_units,p_oil_manual_unit_ref,'OIL_CHANGE');

  if p_filter_inventory_item_id is not null then
    select * into v_filter from public.inventory_items where id=p_filter_inventory_item_id and active=true;
    if v_filter.id is null then raise exception 'Filtro no encontrado'; end if;
    if v_filter.category <> 'Filtro Aceite' then raise exception 'El SKU seleccionado no corresponde a un filtro de aceite'; end if;
    if p_filter_units is null or p_filter_units <= 0 then raise exception 'Cantidad de filtro inválida'; end if;
    perform public.add_inventory_product_item(p_order_id,p_filter_inventory_item_id,p_filter_units,p_filter_manual_unit_ref,'OIL_CHANGE');
  end if;

  v_service_item := public.add_oil_change_item(
    p_order_id,
    coalesce(nullif(trim(p_description),''),'Cambio de aceite'),
    coalesce(p_service_base_ref,0),
    coalesce(p_service_customer_ref,0),
    p_odometer,
    v_oil.brand,
    p_oil_viscosity,
    p_oil_quantity_liters,
    case when v_filter.id is not null then v_filter.sku else null end,
    p_next_km_interval,
    p_next_months
  );
  return v_service_item;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.set_inventory_count(p_inventory_item_id uuid, p_new_count numeric, p_note text DEFAULT NULL::text)
 RETURNS numeric
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_location uuid;
  v_current numeric;
  v_delta numeric;
begin
  perform public.require_auth();
  if p_new_count is null or p_new_count < 0 then raise exception 'El conteo debe ser cero o mayor'; end if;
  select id into v_location from public.locations where code='CABUDARE' and active=true limit 1;
  if v_location is null then select id into v_location from public.locations where active=true order by created_at limit 1; end if;
  if v_location is null then raise exception 'No hay sede activa'; end if;
  perform 1 from public.inventory_items where id=p_inventory_item_id and active=true for update;
  if not found then raise exception 'SKU no encontrado'; end if;
  v_current := public.inventory_quantity(p_inventory_item_id,v_location);
  v_delta := p_new_count-v_current;
  if v_delta <> 0 then
    insert into public.inventory_movements(inventory_item_id,location_id,quantity_delta,movement_type,note)
    values(p_inventory_item_id,v_location,v_delta,'ADJUSTMENT',coalesce(nullif(trim(p_note),''),'Conteo físico'));
  end if;
  update public.inventory_items set needs_review=false,updated_at=now() where id=p_inventory_item_id;
  return p_new_count;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.add_product_item(p_order_id uuid, p_product_id uuid, p_quantity numeric, p_reveal_cash_price boolean DEFAULT false)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_product public.products;
  v_bcv numeric; v_op numeric; v_step numeric; v_mode text;
  v_unit_ves numeric; v_unit_ref numeric; v_item_id uuid;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  if p_quantity is null or p_quantity <= 0 then raise exception 'Cantidad inválida'; end if;
  select * into v_product from public.products where id=p_product_id and active=true and available=true;
  if v_product.id is null then raise exception 'Producto no encontrado o no disponible'; end if;
  if v_product.catalog_source='Notion · Nuestros Productos' then perform public.assert_notion_pricing_fresh(); end if;
  select bcv_rate, operative_rate into v_bcv, v_op from public.current_exchange_rates;
  if v_bcv is null or v_op is null then raise exception 'Debes registrar tasa BCV y operativa antes de vender'; end if;
  select coalesce((value #>> '{}')::numeric,10) into v_step from public.app_settings where key='price_rounding_step';
  select coalesce(value #>> '{}','nearest') into v_mode from public.app_settings where key='price_rounding_mode';
  v_unit_ves := public.round_to_step(v_product.cash_usd_base_price * v_op, coalesce(v_step,10), coalesce(v_mode,'nearest'));
  v_unit_ref := v_unit_ves / v_bcv;

  insert into public.order_items(
    order_id,item_type,business_area,description,product_id,quantity,pricing_mode,
    charged_ves_amount,charged_ref_amount,cash_usd_unit_snapshot,cash_usd_special_total,
    bcv_rate_snapshot,operative_rate_snapshot,cash_price_revealed
  ) values (
    p_order_id,'PRODUCT','STORE',coalesce(v_product.filter_code || ' · ','') || v_product.name,v_product.id,p_quantity,
    case when p_reveal_cash_price then 'CASH_USD_SPECIAL' else 'STANDARD' end,
    round(v_unit_ves * p_quantity,2), round(v_unit_ref * p_quantity,4),v_product.cash_usd_base_price,
    round(v_product.cash_usd_base_price * p_quantity,4),v_bcv,v_op,p_reveal_cash_price
  ) returning id into v_item_id;
  return v_item_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.set_maintenance_reminder_status(p_service_record_id uuid, p_status text, p_snoozed_until date DEFAULT NULL::date)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  perform public.require_auth();
  if p_status not in ('PENDING','SENT','SNOOZED') then raise exception 'Estado de recordatorio inválido'; end if;
  if not exists(select 1 from public.service_records where id=p_service_record_id and service_type='OIL_CHANGE') then
    raise exception 'Servicio de aceite no encontrado';
  end if;
  if p_status='SNOOZED' and p_snoozed_until is null then raise exception 'Indica hasta qué fecha posponer'; end if;

  insert into public.maintenance_reminder_actions(service_record_id,status,snoozed_until,sent_at,last_action_by,updated_at)
  values(
    p_service_record_id,
    p_status,
    case when p_status='SNOOZED' then p_snoozed_until else null end,
    case when p_status='SENT' then now() else null end,
    auth.uid(),
    now()
  )
  on conflict(service_record_id) do update set
    status=excluded.status,
    snoozed_until=excluded.snoozed_until,
    sent_at=case when excluded.status='SENT' then now() else maintenance_reminder_actions.sent_at end,
    last_action_by=auth.uid(),
    updated_at=now();
end;
$function$
;
CREATE OR REPLACE FUNCTION public.get_pricing_sync_status()
 RETURNS TABLE(catalog_synced_at timestamp with time zone, catalog_products bigint, bcv_rate numeric, bcv_effective_at timestamp with time zone, operative_rate numeric, operative_effective_at timestamp with time zone)
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select
    coalesce(
      (select s.last_verified_at from public.integration_sync_state s where s.source_key='notion_catalog'),
      (select max(p.catalog_synced_at) from public.products p where p.catalog_source='Notion · Nuestros Productos')
    ),
    (select count(*) from public.products p where p.catalog_source='Notion · Nuestros Productos' and p.active=true and p.available=true),
    (select r.value from public.exchange_rates r where r.rate_type='BCV' order by r.effective_at desc limit 1),
    coalesce(
      (select s.last_verified_at from public.integration_sync_state s where s.source_key='notion_rates'),
      (select r.effective_at from public.exchange_rates r where r.rate_type='BCV' order by r.effective_at desc limit 1)
    ),
    (select r.value from public.exchange_rates r where r.rate_type='OPERATIVE' order by r.effective_at desc limit 1),
    coalesce(
      (select s.last_verified_at from public.integration_sync_state s where s.source_key='notion_rates'),
      (select r.effective_at from public.exchange_rates r where r.rate_type='OPERATIVE' order by r.effective_at desc limit 1)
    );
$function$
;
CREATE OR REPLACE FUNCTION public.set_crm_post_service_template(p_template text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  perform public.require_auth();
  if length(trim(coalesce(p_template,''))) < 10 then raise exception 'La plantilla es demasiado corta'; end if;
  if length(p_template) > 12000 then raise exception 'La plantilla supera el límite permitido'; end if;
  insert into public.app_settings(key,value,updated_at)
  values('crm_post_service_template',to_jsonb(p_template),now())
  on conflict(key) do update set value=excluded.value,updated_at=now();
end;
$function$
;
CREATE OR REPLACE FUNCTION public.add_catalog_product_item_override(p_order_id uuid, p_product_id uuid, p_quantity numeric, p_manual_unit_ref numeric DEFAULT NULL::numeric)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_product public.products;
  v_bcv numeric;
  v_op numeric;
  v_step numeric;
  v_mode text;
  v_unit_ves numeric;
  v_unit_ref numeric;
  v_item_id uuid;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  if p_quantity is null or p_quantity <= 0 then raise exception 'Cantidad inválida'; end if;

  select * into v_product from public.products where id=p_product_id and active=true and available=true;
  if v_product.id is null then raise exception 'Producto no encontrado o no disponible'; end if;

  select bcv_rate, operative_rate into v_bcv, v_op from public.current_exchange_rates;
  if v_bcv is null or v_op is null then raise exception 'Debes registrar tasa BCV y operativa antes de vender'; end if;
  select coalesce((value #>> '{}')::numeric,10) into v_step from public.app_settings where key='price_rounding_step';
  select coalesce(value #>> '{}','nearest') into v_mode from public.app_settings where key='price_rounding_mode';

  if p_manual_unit_ref is not null then
    if p_manual_unit_ref <= 0 then raise exception 'El precio manual debe ser mayor que cero'; end if;
    v_unit_ref := p_manual_unit_ref;
    v_unit_ves := public.round_to_step(v_unit_ref*v_bcv,coalesce(v_step,10),coalesce(v_mode,'nearest'));
  else
    if v_product.catalog_source='Notion · Nuestros Productos' then perform public.assert_notion_pricing_fresh(); end if;
    v_unit_ves := public.round_to_step(v_product.cash_usd_base_price*v_op,coalesce(v_step,10),coalesce(v_mode,'nearest'));
    v_unit_ref := v_unit_ves/v_bcv;
  end if;

  insert into public.order_items(
    order_id,item_type,business_area,description,product_id,quantity,pricing_mode,
    base_ref_amount,customer_ref_amount,charged_ves_amount,charged_ref_amount,
    cash_usd_unit_snapshot,cash_usd_special_total,bcv_rate_snapshot,operative_rate_snapshot,cash_price_revealed
  ) values (
    p_order_id,'PRODUCT','STORE',v_product.name,v_product.id,p_quantity,
    case when p_manual_unit_ref is null then 'STANDARD' else 'MANUAL_OVERRIDE' end,
    round(v_unit_ref*p_quantity,4),round(v_unit_ref*p_quantity,4),
    round(v_unit_ves*p_quantity,2),round(v_unit_ref*p_quantity,4),
    v_product.cash_usd_base_price,round(v_product.cash_usd_base_price*p_quantity,4),
    v_bcv,v_op,false
  ) returning id into v_item_id;
  return v_item_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.add_manual_product_item(p_order_id uuid, p_description text, p_quantity numeric, p_unit_ref numeric)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_bcv numeric;
  v_op numeric;
  v_step numeric;
  v_mode text;
  v_unit_ves numeric;
  v_item_id uuid;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  if nullif(trim(p_description),'') is null then raise exception 'Escribe el producto'; end if;
  if p_quantity is null or p_quantity <= 0 then raise exception 'Cantidad inválida'; end if;
  if p_unit_ref is null or p_unit_ref <= 0 then raise exception 'El precio REF debe ser mayor que cero'; end if;

  select bcv_rate, operative_rate into v_bcv, v_op from public.current_exchange_rates;
  if v_bcv is null or v_op is null then raise exception 'Debes registrar tasa BCV y operativa antes de vender'; end if;
  select coalesce((value #>> '{}')::numeric,10) into v_step from public.app_settings where key='price_rounding_step';
  select coalesce(value #>> '{}','nearest') into v_mode from public.app_settings where key='price_rounding_mode';
  v_unit_ves := public.round_to_step(p_unit_ref*v_bcv,coalesce(v_step,10),coalesce(v_mode,'nearest'));

  insert into public.order_items(
    order_id,item_type,business_area,description,quantity,pricing_mode,
    base_ref_amount,customer_ref_amount,charged_ves_amount,charged_ref_amount,
    bcv_rate_snapshot,operative_rate_snapshot,cash_price_revealed
  ) values (
    p_order_id,'PRODUCT','STORE',trim(p_description),p_quantity,'MANUAL_NO_STOCK',
    round(p_unit_ref*p_quantity,4),round(p_unit_ref*p_quantity,4),
    round(v_unit_ves*p_quantity,2),round(p_unit_ref*p_quantity,4),
    v_bcv,v_op,false
  ) returning id into v_item_id;
  return v_item_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.set_order_health(p_order_id uuid, p_health_status text, p_health_notes text DEFAULT NULL::text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  if upper(coalesce(p_health_status,'')) not in ('GREEN','YELLOW','RED') then
    raise exception 'Estado de salud inválido';
  end if;
  if upper(p_health_status) in ('YELLOW','RED') and nullif(trim(coalesce(p_health_notes,'')),'') is null then
    raise exception 'Describe la observación preventiva o de seguridad antes de guardar';
  end if;
  update public.orders
     set health_status=upper(p_health_status),
         health_notes=nullif(trim(coalesce(p_health_notes,'')),''),
         health_reviewed_at=now()
   where id=p_order_id;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.validate_order_ready_to_close(p_order_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_order public.orders;
  v_has_vehicle_service boolean;
  v_has_oil boolean;
  v_bad_oil boolean;
begin
  perform public.require_auth();
  select * into v_order from public.orders where id=p_order_id;
  if v_order.id is null then raise exception 'Orden no encontrada'; end if;

  select exists(
    select 1 from public.order_items
    where order_id=p_order_id
      and business_area in ('WORKSHOP','ELECTROAUTO','OIL_CHANGE')
      and item_type='SERVICE'
  ) into v_has_vehicle_service;

  select exists(
    select 1 from public.order_items
    where order_id=p_order_id and business_area='OIL_CHANGE' and item_type='SERVICE'
  ) into v_has_oil;

  if v_order.is_walk_in and v_has_oil then
    raise exception 'El cambio de aceite necesita cliente y vehículo. Desactiva “servicio rápido sin cliente” y asócialos antes de cerrar';
  end if;

  if v_has_vehicle_service and not v_order.is_walk_in then
    if v_order.customer_id is null then
      raise exception 'Antes de cerrar un servicio debes asociar el cliente o marcarlo como servicio rápido sin cliente';
    end if;
    if v_order.vehicle_id is null then
      raise exception 'Antes de cerrar un servicio debes asociar el vehículo o marcarlo como servicio rápido sin cliente';
    end if;
    if v_order.health_status in ('YELLOW','RED') and nullif(trim(coalesce(v_order.health_notes,'')),'') is null then
      raise exception 'La observación preventiva/seguridad necesita una descripción';
    end if;
  end if;

  if v_has_oil then
    select exists(
      select 1 from public.order_items
      where order_id=p_order_id
        and business_area='OIL_CHANGE'
        and item_type='SERVICE'
        and (
          service_odometer is null
          or nullif(trim(coalesce(oil_brand,'')),'') is null
          or (next_service_odometer is null and next_service_date is null)
        )
    ) into v_bad_oil;
    if v_bad_oil then
      raise exception 'El cambio de aceite está incompleto. Regístralo desde “+ Cambio de aceite” con kilometraje, aceite y próximo servicio';
    end if;
  end if;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.dashboard_overview()
 RETURNS TABLE(local_date date, closed_orders_today bigint, sales_ves_today numeric, sales_ref_today numeric, collected_ves_today numeric, collected_ref_today numeric, open_orders bigint, active_vehicles bigint, vehicles_received bigint, vehicles_diagnosis bigint, vehicles_in_progress bigint, vehicles_waiting_parts bigint, vehicles_ready bigint, post_service_action bigint, maintenance_due bigint, maintenance_soon bigint, receivables_open bigint, receivables_outstanding_ves numeric, payroll_pending_ref numeric, inventory_review bigint, inventory_negative bigint, bcv_rate numeric, operative_rate numeric)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_today date := (now() at time zone 'America/Caracas')::date;
begin
  perform public.require_auth();
  return query
  with rates as (select * from public.current_exchange_rates),
  workshop as (
    select
      count(*)::bigint active,
      count(*) filter(where workflow_status='RECEIVED')::bigint received,
      count(*) filter(where workflow_status='DIAGNOSIS')::bigint diagnosis,
      count(*) filter(where workflow_status='IN_PROGRESS')::bigint in_progress,
      count(*) filter(where workflow_status='WAITING_PARTS')::bigint waiting_parts,
      count(*) filter(where workflow_status='READY')::bigint ready
    from public.workshop_board_current
  )
  select
    v_today,
    (select count(*) from public.orders where status='CLOSED' and (closed_at at time zone 'America/Caracas')::date=v_today),
    (select coalesce(sum(total_ves),0) from public.orders where status='CLOSED' and (closed_at at time zone 'America/Caracas')::date=v_today),
    (select coalesce(sum(total_ref),0) from public.orders where status='CLOSED' and (closed_at at time zone 'America/Caracas')::date=v_today),
    (select coalesce(sum(value_ves),0) from public.payments where exists(select 1 from public.orders o where o.id=payments.order_id and o.status<>'CANCELLED') and (paid_at at time zone 'America/Caracas')::date=v_today),
    (select coalesce(sum(value_ref),0) from public.payments where exists(select 1 from public.orders o where o.id=payments.order_id and o.status<>'CANCELLED') and (paid_at at time zone 'America/Caracas')::date=v_today),
    (select count(*) from public.orders where status='OPEN'),
    workshop.active,workshop.received,workshop.diagnosis,workshop.in_progress,workshop.waiting_parts,workshop.ready,
    (select count(*) from public.customer_followups where followup_type='POST_SERVICE' and (status='PENDING' or (status='SNOOZED' and (snoozed_until is null or snoozed_until<=v_today)))),
    (select count(*) from public.maintenance_reminders_current where urgency='DUE'),
    (select count(*) from public.maintenance_reminders_current where urgency='SOON'),
    (select count(*) from public.receivables where status='OPEN'),
    (select coalesce(sum(outstanding_ves),0) from public.receivables where status='OPEN'),
    (select coalesce(sum(amount_ref),0) from public.payroll_accruals where payroll_run_id is null),
    (select count(*) from public.inventory_current where needs_review=true),
    (select count(*) from public.inventory_current where quantity_on_hand<0),
    rates.bcv_rate,rates.operative_rate
  from workshop cross join rates;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.apply_legacy_service_import(p_source_system text, p_source_name text DEFAULT NULL::text)
 RETURNS TABLE(imported integer, errors integer)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  r record;
  v_customer uuid;
  v_vehicle uuid;
  v_service uuid;
  v_run uuid;
  v_imported integer := 0;
  v_errors integer := 0;
  v_when timestamptz;
begin
  insert into public.data_import_runs(source_system,source_name,staged_rows)
  values(p_source_system,p_source_name,(select count(*) from public.legacy_service_import_stage where source_system=p_source_system))
  returning id into v_run;

  for r in
    select * from public.legacy_service_import_stage
    where source_system=p_source_system and import_status in ('STAGED','ERROR')
    order by service_date nulls last, submitted_at nulls last, source_key
  loop
    begin
      v_customer := null; v_vehicle := null; v_service := null;

      select customer_id into v_customer
      from public.customer_external_identities
      where source_system=p_source_system and external_key=r.identity_key
      limit 1;

      if v_customer is null and r.document_id is not null then
        select id into v_customer from public.customers
        where public.normalize_ve_document(document_id)=r.document_id
        order by created_at limit 1;
      end if;
      if v_customer is null and r.phone is not null then
        select id into v_customer from public.customers
        where public.normalize_ve_phone(phone)=r.phone
        order by created_at limit 1;
      end if;

      if v_customer is null then
        insert into public.customers(name,phone,document_id)
        values(coalesce(nullif(trim(r.customer_name),''),'Cliente histórico'),r.phone,r.document_id)
        returning id into v_customer;
      else
        update public.customers
           set name=case when nullif(trim(name),'') is null then r.customer_name else name end,
               phone=case when public.normalize_ve_phone(phone) is null and r.phone is not null then r.phone else phone end,
               document_id=case when public.normalize_ve_document(document_id) is null and r.document_id is not null then r.document_id else document_id end,
               updated_at=now()
         where id=v_customer;
      end if;

      insert into public.customer_external_identities(source_system,external_key,customer_id,normalized_document,normalized_phone,first_seen_at,last_seen_at)
      values(p_source_system,r.identity_key,v_customer,r.document_id,r.phone,
             coalesce((r.service_date::timestamp + time '12:00') at time zone 'America/Caracas',r.submitted_at),
             coalesce((r.service_date::timestamp + time '12:00') at time zone 'America/Caracas',r.submitted_at))
      on conflict(source_system,external_key) do update set
        customer_id=excluded.customer_id,
        normalized_document=coalesce(customer_external_identities.normalized_document,excluded.normalized_document),
        normalized_phone=coalesce(customer_external_identities.normalized_phone,excluded.normalized_phone),
        first_seen_at=least(coalesce(customer_external_identities.first_seen_at,excluded.first_seen_at),coalesce(excluded.first_seen_at,customer_external_identities.first_seen_at)),
        last_seen_at=greatest(coalesce(customer_external_identities.last_seen_at,excluded.last_seen_at),coalesce(excluded.last_seen_at,customer_external_identities.last_seen_at)),
        updated_at=now();

      if r.canonical_plate is not null then
        select id into v_vehicle from public.vehicles
        where public.normalize_vehicle_plate(plate)=r.canonical_plate
        order by created_at limit 1;
      else
        select id into v_vehicle from public.vehicles
        where customer_id=v_customer and plate is null
          and lower(regexp_replace(coalesce(model,''),'[^a-zA-Z0-9]','','g'))=lower(regexp_replace(coalesce(r.vehicle_model,''),'[^a-zA-Z0-9]','','g'))
        order by created_at limit 1;
      end if;

      if v_vehicle is null then
        insert into public.vehicles(customer_id,plate,make,model,year,current_odometer)
        values(v_customer,r.canonical_plate,r.vehicle_make,r.vehicle_model,r.vehicle_year,r.odometer)
        returning id into v_vehicle;
      else
        update public.vehicles set
          make=coalesce(make,r.vehicle_make), model=coalesce(model,r.vehicle_model), year=coalesce(year,r.vehicle_year), updated_at=now()
        where id=v_vehicle;
      end if;

      if public.normalize_vehicle_plate(r.raw_plate) is not null then
        insert into public.vehicle_plate_aliases(vehicle_id,source_system,alias_plate,normalized_alias,confidence,first_seen_at,last_seen_at)
        values(v_vehicle,p_source_system,r.raw_plate,public.normalize_vehicle_plate(r.raw_plate),
               case when r.canonical_plate is null then 'CONFLICT' when public.normalize_vehicle_plate(r.raw_plate)=r.canonical_plate then 'SOURCE' else 'HIGH_CONFIDENCE_ALIAS' end,
               coalesce((r.service_date::timestamp + time '12:00') at time zone 'America/Caracas',r.submitted_at),
               coalesce((r.service_date::timestamp + time '12:00') at time zone 'America/Caracas',r.submitted_at))
        on conflict(vehicle_id,source_system,normalized_alias) do update set
          last_seen_at=greatest(coalesce(vehicle_plate_aliases.last_seen_at,excluded.last_seen_at),coalesce(excluded.last_seen_at,vehicle_plate_aliases.last_seen_at));
      end if;

      v_when := coalesce((r.service_date::timestamp + time '12:00') at time zone 'America/Caracas',r.submitted_at,now());
      insert into public.vehicle_customer_history(vehicle_id,customer_id,source_system,first_seen_at,last_seen_at)
      values(v_vehicle,v_customer,p_source_system,v_when,v_when)
      on conflict(vehicle_id,customer_id,source_system) do update set
        first_seen_at=least(coalesce(vehicle_customer_history.first_seen_at,excluded.first_seen_at),coalesce(excluded.first_seen_at,vehicle_customer_history.first_seen_at)),
        last_seen_at=greatest(coalesce(vehicle_customer_history.last_seen_at,excluded.last_seen_at),coalesce(excluded.last_seen_at,vehicle_customer_history.last_seen_at));

      select id into v_service from public.service_records where source_system=p_source_system and source_key=r.source_key limit 1;
      if v_service is null then
        insert into public.service_records(
          order_id,order_item_id,customer_id,vehicle_id,service_type,description,odometer,
          oil_brand,oil_viscosity,oil_quantity_liters,oil_filter_code,next_service_odometer,next_service_date,
          charged_ref_amount,charged_ves_amount,performed_at,source_system,source_key,source_invoice,
          service_notes,included_services,bonuses,source_payload,imported_at
        ) values(
          null,null,v_customer,v_vehicle,r.service_type,
          case when r.service_type='OIL_CHANGE' then trim(concat_ws(' · ','Cambio de aceite',r.oil_raw,case when r.oil_filter_code is not null then 'Filtro '||r.oil_filter_code end)) else coalesce(r.service_notes,'Servicio histórico') end,
          r.odometer,r.oil_raw,r.oil_viscosity,null,r.oil_filter_code,r.next_service_odometer,r.next_service_date,
          0,0,v_when,p_source_system,r.source_key,r.invoice,r.service_notes,r.included_services,r.bonuses,r.source_payload,now()
        ) returning id into v_service;
      end if;

      update public.legacy_service_import_stage
         set import_status='IMPORTED',imported_customer_id=v_customer,imported_vehicle_id=v_vehicle,
             imported_service_record_id=v_service,imported_at=now()
       where source_system=p_source_system and source_key=r.source_key;

      if cardinality(r.quality_flags)>0 then
        insert into public.data_import_issues(source_system,source_key,issue_type,details)
        select p_source_system,r.source_key,q,jsonb_build_object('source_rows',r.source_rows,'payload',r.source_payload)
        from unnest(r.quality_flags) q
        where not exists(select 1 from public.data_import_issues i where i.source_system=p_source_system and i.source_key=r.source_key and i.issue_type=q);
      end if;
      v_imported := v_imported+1;
    exception when others then
      v_errors := v_errors+1;
      update public.legacy_service_import_stage set import_status='ERROR' where source_system=p_source_system and source_key=r.source_key;
      insert into public.data_import_issues(source_system,source_key,issue_type,raw_value,details)
      values(p_source_system,r.source_key,'IMPORT_ERROR',sqlerrm,jsonb_build_object('source_rows',r.source_rows))
      on conflict do nothing;
    end;
  end loop;

  update public.customers set phone=public.normalize_ve_phone(phone),updated_at=now()
  where public.normalize_ve_phone(phone) is not null and phone is distinct from public.normalize_ve_phone(phone);

  with latest_odo as (
    select distinct on (vehicle_id) vehicle_id,odometer from public.service_records
    where odometer is not null order by vehicle_id,performed_at desc,created_at desc
  )
  update public.vehicles v set current_odometer=l.odometer,updated_at=now() from latest_odo l where l.vehicle_id=v.id;

  with latest_owner as (
    select distinct on (vehicle_id) vehicle_id,customer_id from public.service_records
    where customer_id is not null order by vehicle_id,performed_at desc,created_at desc
  )
  update public.vehicles v set customer_id=l.customer_id,updated_at=now() from latest_owner l where l.vehicle_id=v.id;

  update public.data_import_runs set finished_at=now(),imported_rows=v_imported,error_rows=v_errors where id=v_run;
  return query select v_imported,v_errors;
end $function$
;
CREATE OR REPLACE FUNCTION public.consume_inventory_on_order_close()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  r record;
  v_location uuid;
  v_stock numeric;
begin
  if new.status='CLOSED' and old.status is distinct from 'CLOSED' then
    for r in
      select oi.id,oi.inventory_item_id,oi.inventory_location_id,oi.quantity,ii.sku
      from public.order_items oi
      join public.inventory_items ii on ii.id=oi.inventory_item_id
      where oi.order_id=new.id and oi.inventory_item_id is not null
      order by oi.created_at,oi.id
    loop
      v_location := coalesce(r.inventory_location_id,new.location_id);
      if v_location is null then select id into v_location from public.locations where code='CABUDARE' and active=true limit 1; end if;
      perform 1 from public.inventory_items where id=r.inventory_item_id for update;
      v_stock := public.inventory_quantity(r.inventory_item_id,v_location);
      if v_stock < r.quantity then
        raise exception 'No se puede cerrar: stock insuficiente para % (disponible %, requerido %)',r.sku,v_stock,r.quantity;
      end if;
      insert into public.inventory_movements(inventory_item_id,location_id,quantity_delta,movement_type,order_item_id,note,occurred_at)
      values(r.inventory_item_id,v_location,-r.quantity,'SALE',r.id,'Salida por orden '||coalesce(new.order_number,new.id::text),coalesce(new.closed_at,now()))
      on conflict (order_item_id) where movement_type='SALE' and order_item_id is not null do nothing;
    end loop;
  end if;
  return new;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.normalize_ve_phone(p_value text)
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public', 'pg_temp'
AS $function$
declare d text;
begin
  d := regexp_replace(coalesce(p_value,''),'\D','','g');
  if d ~ '^58[4][0-9]{9}$' and length(d)=12 then return d; end if;
  if d ~ '^0[4][0-9]{9}$' and length(d)=11 then return '58'||substr(d,2); end if;
  if d ~ '^[4][0-9]{9}$' and length(d)=10 then return '58'||d; end if;
  return null;
end $function$
;
CREATE OR REPLACE FUNCTION public.normalize_ve_document(p_value text)
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public', 'pg_temp'
AS $function$
declare d text;
begin
  d := regexp_replace(upper(coalesce(p_value,'')),'[^0-9]','','g');
  if d is null or d='' or d ~ '^0+$' or length(d)<5 or length(d)>9 then return null; end if;
  return d;
end $function$
;
CREATE OR REPLACE FUNCTION public.normalize_vehicle_plate(p_value text)
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public', 'pg_temp'
AS $function$
declare p text;
begin
  p := regexp_replace(upper(coalesce(p_value,'')),'[^A-Z0-9]','','g');
  if p in ('','NA','NM','NF','ND','00000','000000') then return null; end if;
  if length(p)<5 or length(p)>8 or p !~ '[A-Z]' or p !~ '[0-9]' then return null; end if;
  return p;
end $function$
;
CREATE OR REPLACE FUNCTION public.build_quick_sale_order(p_items jsonb)
 RETURNS TABLE(order_id uuid, order_number text, total_ves numeric, total_ref numeric)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_order_id uuid;
  v_order_number text;
  v_line jsonb;
  v_kind text;
  v_qty numeric;
  v_unit_ref numeric;
  v_description text;
  v_inventory_item_id uuid;
  v_product_id uuid;
begin
  perform public.require_auth();

  if p_items is null or jsonb_typeof(p_items) <> 'array' then
    raise exception 'La venta rápida requiere una lista de productos';
  end if;
  if jsonb_array_length(p_items) < 1 then
    raise exception 'Agrega al menos un producto';
  end if;
  if jsonb_array_length(p_items) > 50 then
    raise exception 'La venta rápida admite hasta 50 líneas';
  end if;

  select c.id, c.order_number into v_order_id, v_order_number
  from public.create_order() c;

  for v_line in select value from jsonb_array_elements(p_items)
  loop
    v_kind := upper(coalesce(v_line->>'kind',''));
    v_qty := nullif(v_line->>'quantity','')::numeric;
    v_unit_ref := nullif(v_line->>'unit_ref','')::numeric;

    if v_qty is null or v_qty <= 0 then raise exception 'Cantidad inválida en venta rápida'; end if;
    if v_unit_ref is null or v_unit_ref <= 0 then raise exception 'Cada producto necesita precio REF mayor que cero'; end if;

    if v_kind = 'STOCK' then
      v_inventory_item_id := nullif(v_line->>'inventory_item_id','')::uuid;
      if v_inventory_item_id is null then raise exception 'Falta inventory_item_id'; end if;
      perform public.add_inventory_product_item(v_order_id, v_inventory_item_id, v_qty, v_unit_ref, 'STORE');
    elsif v_kind = 'CATALOG' then
      v_product_id := nullif(v_line->>'product_id','')::uuid;
      if v_product_id is null then raise exception 'Falta product_id'; end if;
      perform public.add_catalog_product_item_override(v_order_id, v_product_id, v_qty, v_unit_ref);
    elsif v_kind = 'MANUAL' then
      v_description := nullif(trim(coalesce(v_line->>'description','')),'');
      if v_description is null then raise exception 'Escribe el producto manual'; end if;
      perform public.add_manual_product_item(v_order_id, v_description, v_qty, v_unit_ref);
    else
      raise exception 'Tipo de producto inválido en venta rápida: %', v_kind;
    end if;
  end loop;

  select coalesce(sum(oi.charged_ves_amount),0), coalesce(sum(oi.charged_ref_amount),0)
  into total_ves, total_ref
  from public.order_items oi where oi.order_id=v_order_id;

  order_id := v_order_id;
  order_number := v_order_number;

  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('quick_sale.order_built','order',v_order_id,jsonb_build_object('order_number',v_order_number,'lines',jsonb_array_length(p_items),'total_ves',total_ves,'total_ref',total_ref));

  return next;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.complete_quick_sale(p_items jsonb, p_payment_method text, p_payment_reference text DEFAULT NULL::text)
 RETURNS TABLE(order_id uuid, order_number text, total_ves numeric, total_ref numeric)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_built record;
  v_method text := upper(coalesce(p_payment_method,''));
  v_amount numeric;
  v_op numeric;
begin
  perform public.require_auth();

  if v_method not in ('CASH_USD','CASH_VES','MOBILE_PAYMENT','TRANSFER_BDV','TRANSFER_BNC') then
    raise exception 'Método de pago inválido';
  end if;

  select * into v_built from public.build_quick_sale_order(p_items);

  if v_method='CASH_USD' then
    select operative_rate into v_op from public.current_exchange_rates;
    if v_op is null or v_op <= 0 then raise exception 'No hay tasa operativa disponible'; end if;
    v_amount := v_built.total_ves / v_op;
  else
    v_amount := v_built.total_ves;
  end if;

  perform public.add_payment(v_built.order_id, v_method, v_amount, p_payment_reference);
  perform public.close_order(v_built.order_id);

  order_id := v_built.order_id;
  order_number := v_built.order_number;
  total_ves := v_built.total_ves;
  total_ref := v_built.total_ref;

  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('quick_sale.completed','order',v_built.order_id,jsonb_build_object('order_number',v_built.order_number,'payment_method',v_method,'total_ves',v_built.total_ves,'total_ref',v_built.total_ref));

  return next;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.complete_quick_sale_cashea(p_items jsonb, p_initial_percent numeric, p_initial_payment_method text, p_payment_reference text DEFAULT NULL::text, p_cashea_reference text DEFAULT NULL::text)
 RETURNS TABLE(order_id uuid, order_number text, total_ves numeric, total_ref numeric, initial_ves numeric, initial_ref numeric, financed_ref numeric, commission_ref numeric, cashea_sale_id uuid)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_built record;
  v_bcv numeric; v_op numeric;
  v_method text := upper(coalesce(p_initial_payment_method,''));
  v_commission_pct numeric;
  v_min_ref numeric;
  v_initial_ref numeric; v_initial_ves numeric; v_financed_ref numeric;
  v_commission_ref numeric; v_commission_ves numeric;
  v_sale_id uuid;
  v_currency text; v_amount_original numeric;
  v_i1 numeric; v_i2 numeric; v_i3 numeric;
begin
  perform public.require_auth();
  if p_initial_percent is null or p_initial_percent <= 0 or p_initial_percent > 100 then raise exception 'Porcentaje inicial Cashea inválido'; end if;
  if v_method not in ('CASH_USD','CASH_VES','MOBILE_PAYMENT','TRANSFER_BDV','TRANSFER_BNC') then raise exception 'Método de pago de la inicial inválido'; end if;

  select bcv_rate, operative_rate into v_bcv,v_op from public.current_exchange_rates;
  if v_bcv is null or v_bcv<=0 or v_op is null or v_op<=0 then raise exception 'Debes registrar tasas antes de cobrar'; end if;
  select coalesce((value #>> '{}')::numeric,4) into v_commission_pct from public.app_settings where key='cashea_commission_percent';
  select coalesce((value #>> '{}')::numeric,25) into v_min_ref from public.app_settings where key='cashea_minimum_ref';

  select * into v_built from public.build_quick_sale_order(p_items);
  if v_built.total_ref < v_min_ref then raise exception 'Cashea requiere un mínimo configurado de REF % para esta venta', v_min_ref; end if;

  v_initial_ref := round(v_built.total_ref * p_initial_percent / 100,4);
  v_initial_ves := round(v_initial_ref * v_bcv,2);
  v_financed_ref := greatest(round(v_built.total_ref - v_initial_ref,4),0);
  v_commission_ref := round(v_built.total_ref * v_commission_pct / 100,4);
  v_commission_ves := round(v_commission_ref * v_bcv,2);

  v_currency := case when v_method='CASH_USD' then 'USD' else 'VES' end;
  v_amount_original := case when v_currency='USD' then v_initial_ref else v_initial_ves end;
  insert into public.payments(order_id,method,currency,amount_original,bcv_rate_snapshot,operative_rate_snapshot,value_ves,value_ref,reference,paid_at)
  values(v_built.order_id,v_method,v_currency,v_amount_original,v_bcv,v_op,v_initial_ves,v_initial_ref,nullif(trim(p_payment_reference),''),now());

  insert into public.cashea_sales(order_id,receivable_id,status,initial_percent,commission_percent,gross_ref,gross_ves_snapshot,initial_ref,initial_ves_snapshot,financed_ref,commission_ref,commission_ves_snapshot,bcv_rate_snapshot,initial_payment_method,cashea_reference)
  values(v_built.order_id,null,case when v_financed_ref<=0.01 then 'SETTLED' else 'ACTIVE' end,p_initial_percent,v_commission_pct,v_built.total_ref,v_built.total_ves,v_initial_ref,v_initial_ves,v_financed_ref,v_commission_ref,v_commission_ves,v_bcv,v_method,nullif(trim(p_cashea_reference),''))
  returning id into v_sale_id;

  if v_financed_ref > 0.01 then
    v_i1 := round(v_financed_ref/3,4);
    v_i2 := round(v_financed_ref/3,4);
    v_i3 := round(v_financed_ref-v_i1-v_i2,4);
    insert into public.cashea_installments(cashea_sale_id,installment_no,due_date,amount_ref,amount_ves_snapshot)
    values
      (v_sale_id,1,current_date+14,v_i1,round(v_i1*v_bcv,2)),
      (v_sale_id,2,current_date+28,v_i2,round(v_i2*v_bcv,2)),
      (v_sale_id,3,current_date+42,v_i3,round(v_i3*v_bcv,2));
  end if;

  update public.orders
  set status='CLOSED',closed_at=now(),total_ves=round(v_built.total_ves,2),total_ref=round(v_built.total_ref,4),
      total_cash_usd_equivalent=round((select coalesce(sum(oi.charged_ves_amount/nullif(oi.operative_rate_snapshot,0)),0) from public.order_items oi where oi.order_id=v_built.order_id),4)
  where id=v_built.order_id;

  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('quick_sale.cashea_completed','order',v_built.order_id,
    jsonb_build_object('cashea_sale_id',v_sale_id,'initial_percent',p_initial_percent,'commission_percent',v_commission_pct,'initial_ref',v_initial_ref,'financed_ref',v_financed_ref,'commission_ref',v_commission_ref,'reference',nullif(trim(p_cashea_reference),'')));

  order_id := v_built.order_id;
  order_number := v_built.order_number;
  total_ves := round(v_built.total_ves,2);
  total_ref := round(v_built.total_ref,4);
  initial_ves := v_initial_ves;
  initial_ref := v_initial_ref;
  financed_ref := v_financed_ref;
  commission_ref := v_commission_ref;
  cashea_sale_id := v_sale_id;
  return next;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.add_oil_change_package_flexible(p_order_id uuid, p_odometer integer, p_description text DEFAULT 'Cambio de aceite'::text, p_service_base_ref numeric DEFAULT 0, p_service_customer_ref numeric DEFAULT 0, p_oil_source text DEFAULT 'INVENTORY'::text, p_oil_inventory_item_id uuid DEFAULT NULL::uuid, p_oil_product_id uuid DEFAULT NULL::uuid, p_oil_description text DEFAULT NULL::text, p_oil_units numeric DEFAULT 1, p_oil_unit_ref numeric DEFAULT NULL::numeric, p_oil_brand text DEFAULT NULL::text, p_oil_viscosity text DEFAULT NULL::text, p_oil_quantity_liters numeric DEFAULT NULL::numeric, p_filter_source text DEFAULT 'NONE'::text, p_filter_inventory_item_id uuid DEFAULT NULL::uuid, p_filter_product_id uuid DEFAULT NULL::uuid, p_filter_description text DEFAULT NULL::text, p_filter_units numeric DEFAULT 1, p_filter_unit_ref numeric DEFAULT NULL::numeric, p_filter_code text DEFAULT NULL::text, p_next_km_interval integer DEFAULT 5000, p_next_months integer DEFAULT 3)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_oil_source text := upper(coalesce(p_oil_source,''));
  v_filter_source text := upper(coalesce(p_filter_source,'NONE'));
  v_oil_item public.inventory_items;
  v_filter_item public.inventory_items;
  v_oil_product public.products;
  v_filter_product public.products;
  v_oil_brand text := nullif(trim(coalesce(p_oil_brand,'')),'');
  v_filter_code text := nullif(trim(coalesce(p_filter_code,'')),'');
  v_service_item uuid;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);

  if p_odometer is null or p_odometer < 0 then raise exception 'Ingresa el kilometraje actual'; end if;
  if p_oil_units is null or p_oil_units <= 0 then raise exception 'Indica la cantidad de aceite usada'; end if;
  if p_oil_unit_ref is null or p_oil_unit_ref <= 0 then raise exception 'Indica el precio REF del aceite'; end if;
  if v_oil_source not in ('INVENTORY','CATALOG','MANUAL') then raise exception 'Origen de aceite inválido'; end if;
  if v_filter_source not in ('NONE','INVENTORY','CATALOG','MANUAL') then raise exception 'Origen de filtro inválido'; end if;

  if v_oil_source='INVENTORY' then
    if p_oil_inventory_item_id is null then raise exception 'Selecciona el aceite del inventario'; end if;
    select * into v_oil_item from public.inventory_items where id=p_oil_inventory_item_id and active=true;
    if v_oil_item.id is null then raise exception 'Aceite de inventario no encontrado'; end if;
    perform public.add_inventory_product_item(p_order_id,p_oil_inventory_item_id,p_oil_units,p_oil_unit_ref,'OIL_CHANGE');
    v_oil_brand := coalesce(v_oil_brand,v_oil_item.brand,v_oil_item.description);
  elsif v_oil_source='CATALOG' then
    if p_oil_product_id is null then raise exception 'Selecciona el aceite del catálogo'; end if;
    select * into v_oil_product from public.products where id=p_oil_product_id and active=true and available=true;
    if v_oil_product.id is null then raise exception 'Aceite de catálogo no encontrado'; end if;
    perform public.add_catalog_product_item_override(p_order_id,p_oil_product_id,p_oil_units,p_oil_unit_ref);
    v_oil_brand := coalesce(v_oil_brand,v_oil_product.name);
  else
    if nullif(trim(coalesce(p_oil_description,'')),'') is null then raise exception 'Escribe el aceite utilizado'; end if;
    perform public.add_manual_product_item(p_order_id,trim(p_oil_description),p_oil_units,p_oil_unit_ref);
    v_oil_brand := coalesce(v_oil_brand,trim(p_oil_description));
  end if;

  if v_filter_source <> 'NONE' then
    if p_filter_units is null or p_filter_units <= 0 then raise exception 'Indica la cantidad de filtros'; end if;
    if p_filter_unit_ref is null or p_filter_unit_ref <= 0 then raise exception 'Indica el precio REF del filtro'; end if;

    if v_filter_source='INVENTORY' then
      if p_filter_inventory_item_id is null then raise exception 'Selecciona el filtro del inventario'; end if;
      select * into v_filter_item from public.inventory_items where id=p_filter_inventory_item_id and active=true;
      if v_filter_item.id is null then raise exception 'Filtro de inventario no encontrado'; end if;
      perform public.add_inventory_product_item(p_order_id,p_filter_inventory_item_id,p_filter_units,p_filter_unit_ref,'OIL_CHANGE');
      v_filter_code := coalesce(v_filter_code,v_filter_item.sku);
    elsif v_filter_source='CATALOG' then
      if p_filter_product_id is null then raise exception 'Selecciona el filtro del catálogo'; end if;
      select * into v_filter_product from public.products where id=p_filter_product_id and active=true and available=true;
      if v_filter_product.id is null then raise exception 'Filtro de catálogo no encontrado'; end if;
      perform public.add_catalog_product_item_override(p_order_id,p_filter_product_id,p_filter_units,p_filter_unit_ref);
      v_filter_code := coalesce(v_filter_code,v_filter_product.name);
    else
      if nullif(trim(coalesce(p_filter_description,'')),'') is null then raise exception 'Escribe el filtro utilizado'; end if;
      perform public.add_manual_product_item(p_order_id,trim(p_filter_description),p_filter_units,p_filter_unit_ref);
      v_filter_code := coalesce(v_filter_code,trim(p_filter_description));
    end if;
  end if;

  v_service_item := public.add_oil_change_item(
    p_order_id,
    coalesce(nullif(trim(p_description),''),'Cambio de aceite'),
    coalesce(p_service_base_ref,0),
    coalesce(p_service_customer_ref,0),
    p_odometer,
    v_oil_brand,
    nullif(trim(coalesce(p_oil_viscosity,'')),''),
    p_oil_quantity_liters,
    v_filter_code,
    p_next_km_interval,
    p_next_months
  );

  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('oil_change.flexible_package_added','order_item',v_service_item,jsonb_build_object(
    'order_id',p_order_id,'oil_source',v_oil_source,'filter_source',v_filter_source,
    'oil_units',p_oil_units,'filter_units',case when v_filter_source='NONE' then null else p_filter_units end
  ));

  return v_service_item;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.close_order_with_full_payment(p_order_id uuid, p_method text, p_reference text DEFAULT NULL::text)
 RETURNS TABLE(order_number text, total_ves numeric, total_ref numeric, payment_id uuid)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_total_ves numeric;
  v_total_ref numeric;
  v_paid_ves numeric;
  v_remaining numeric;
  v_method text := upper(coalesce(p_method,''));
  v_op numeric;
  v_amount numeric;
  v_payment_id uuid;
  v_closed record;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);
  if v_method not in ('CASH_USD','CASH_VES','MOBILE_PAYMENT','TRANSFER_BDV','TRANSFER_BNC') then raise exception 'Método de pago inválido'; end if;

  select coalesce(sum(oi.charged_ves_amount),0),coalesce(sum(oi.charged_ref_amount),0)
  into v_total_ves,v_total_ref from public.order_items oi where oi.order_id=p_order_id;
  if v_total_ves<=0 then raise exception 'La orden no tiene items'; end if;
  select coalesce(sum(p.value_ves),0) into v_paid_ves from public.payments p where p.order_id=p_order_id;
  v_remaining := greatest(v_total_ves-v_paid_ves,0);
  if v_remaining>1 then
    if v_method='CASH_USD' then
      select operative_rate into v_op from public.current_exchange_rates;
      if v_op is null or v_op<=0 then raise exception 'No hay tasa operativa disponible'; end if;
      v_amount := v_remaining/v_op;
    else
      v_amount := v_remaining;
    end if;
    v_payment_id := public.add_payment(p_order_id,v_method,v_amount,p_reference);
  end if;
  select * into v_closed from public.close_order(p_order_id);
  order_number:=v_closed.order_number;
  total_ves:=v_closed.total_ves;
  total_ref:=v_closed.total_ref;
  payment_id:=v_payment_id;
  return next;
end;
$function$
;
CREATE OR REPLACE FUNCTION public.close_order_with_cashea(p_order_id uuid, p_initial_percent numeric, p_initial_payment_method text, p_payment_reference text DEFAULT NULL::text, p_cashea_reference text DEFAULT NULL::text)
 RETURNS TABLE(order_id uuid, order_number text, total_ves numeric, total_ref numeric, initial_ves numeric, initial_ref numeric, financed_ref numeric, commission_ref numeric, cashea_sale_id uuid)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_order public.orders;
  v_bcv numeric;
  v_op numeric;
  v_total_ves numeric;
  v_total_ref numeric;
  v_method text := upper(coalesce(p_initial_payment_method,''));
  v_commission_pct numeric;
  v_min_ref numeric;
  v_initial_ref numeric;
  v_initial_ves numeric;
  v_financed_ref numeric;
  v_commission_ref numeric;
  v_commission_ves numeric;
  v_sale_id uuid;
  v_currency text;
  v_amount_original numeric;
  v_i1 numeric;
  v_i2 numeric;
  v_i3 numeric;
  v_cash numeric;
  i public.order_items;
begin
  perform public.require_auth();
  perform public.assert_order_open(p_order_id);

  select * into v_order from public.orders o where o.id=p_order_id for update;
  if v_order.id is null then raise exception 'Orden no encontrada'; end if;

  if p_initial_percent is null or p_initial_percent <= 0 or p_initial_percent >= 100 then
    raise exception 'La inicial Cashea debe ser mayor que 0%% y menor que 100%%';
  end if;
  if v_method not in ('CASH_USD','CASH_VES','MOBILE_PAYMENT','TRANSFER_BDV','TRANSFER_BNC') then
    raise exception 'Método de pago de la inicial inválido';
  end if;
  if exists(select 1 from public.cashea_sales cs where cs.order_id=p_order_id) then
    raise exception 'Esta orden ya tiene una venta Cashea registrada';
  end if;
  if exists(select 1 from public.receivables r where r.order_id=p_order_id and r.status='OPEN') then
    raise exception 'La orden ya tiene una cuenta por cobrar abierta';
  end if;
  if exists(select 1 from public.payments p where p.order_id=p_order_id) then
    raise exception 'Para cerrar con Cashea elimina primero los pagos cargados en esta orden; la inicial Cashea se registra al confirmar';
  end if;

  select coalesce(sum(oi.charged_ves_amount),0), coalesce(sum(oi.charged_ref_amount),0)
  into v_total_ves,v_total_ref
  from public.order_items oi where oi.order_id=p_order_id;
  if v_total_ves <= 0 or v_total_ref <= 0 then raise exception 'La orden no tiene items cobrables'; end if;

  select cer.bcv_rate,cer.operative_rate into v_bcv,v_op from public.current_exchange_rates cer;
  if v_bcv is null or v_bcv<=0 or v_op is null or v_op<=0 then raise exception 'Debes registrar tasas antes de cobrar'; end if;

  select coalesce((s.value #>> '{}')::numeric,4) into v_commission_pct from public.app_settings s where s.key='cashea_commission_percent';
  select coalesce((s.value #>> '{}')::numeric,25) into v_min_ref from public.app_settings s where s.key='cashea_minimum_ref';
  if v_total_ref < v_min_ref then raise exception 'Cashea requiere un mínimo configurado de REF % para esta venta', v_min_ref; end if;

  v_initial_ref := round(v_total_ref*p_initial_percent/100,4);
  v_initial_ves := round(v_initial_ref*v_bcv,2);
  v_financed_ref := greatest(round(v_total_ref-v_initial_ref,4),0);
  v_commission_ref := round(v_total_ref*v_commission_pct/100,4);
  v_commission_ves := round(v_commission_ref*v_bcv,2);

  v_currency := case when v_method='CASH_USD' then 'USD' else 'VES' end;
  v_amount_original := case when v_currency='USD' then v_initial_ref else v_initial_ves end;

  insert into public.payments(order_id,method,currency,amount_original,bcv_rate_snapshot,operative_rate_snapshot,value_ves,value_ref,reference,paid_at)
  values(p_order_id,v_method,v_currency,v_amount_original,v_bcv,v_op,v_initial_ves,v_initial_ref,nullif(trim(p_payment_reference),''),now());

  insert into public.cashea_sales(
    order_id,receivable_id,status,initial_percent,commission_percent,gross_ref,gross_ves_snapshot,
    initial_ref,initial_ves_snapshot,financed_ref,commission_ref,commission_ves_snapshot,bcv_rate_snapshot,
    initial_payment_method,cashea_reference
  ) values(
    p_order_id,null,'ACTIVE',p_initial_percent,v_commission_pct,v_total_ref,v_total_ves,
    v_initial_ref,v_initial_ves,v_financed_ref,v_commission_ref,v_commission_ves,v_bcv,
    v_method,nullif(trim(p_cashea_reference),'')
  ) returning id into v_sale_id;

  v_i1 := round(v_financed_ref/3,4);
  v_i2 := round(v_financed_ref/3,4);
  v_i3 := round(v_financed_ref-v_i1-v_i2,4);
  insert into public.cashea_installments(cashea_sale_id,installment_no,due_date,amount_ref,amount_ves_snapshot)
  values
    (v_sale_id,1,current_date+14,v_i1,round(v_i1*v_bcv,2)),
    (v_sale_id,2,current_date+28,v_i2,round(v_i2*v_bcv,2)),
    (v_sale_id,3,current_date+42,v_i3,round(v_i3*v_bcv,2));

  select coalesce(sum(oi.charged_ves_amount/nullif(oi.operative_rate_snapshot,0)),0)
  into v_cash from public.order_items oi where oi.order_id=p_order_id;

  update public.orders o
  set status='CLOSED',closed_at=now(),total_ves=round(v_total_ves,2),total_ref=round(v_total_ref,4),total_cash_usd_equivalent=round(v_cash,4)
  where o.id=p_order_id;

  for i in select oi.* from public.order_items oi where oi.order_id=p_order_id loop
    if i.business_area='WORKSHOP' and coalesce(i.worker_share_ref_snapshot,0)>0 then
      insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description,occurred_at)
      values(i.worker_employee_id,i.id,'WORKSHOP_COMMISSION',i.worker_share_ref_snapshot,'40% taller · '||i.description,now())
      on conflict do nothing;
    end if;
    if i.business_area='WORKSHOP' and coalesce(i.assistant_bonus_ref_snapshot,0)>0 then
      insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description,occurred_at)
      values(i.assistant_bonus_employee_id,i.id,'ASSISTANT_BONUS',i.assistant_bonus_ref_snapshot,'Bono ayudante · '||i.description,now())
      on conflict do nothing;
    end if;
    if i.business_area='ELECTROAUTO' and coalesce(i.worker_share_ref_snapshot,0)>0 then
      insert into public.payroll_accruals(employee_id,source_order_item_id,source_type,amount_ref,description,occurred_at)
      values(i.worker_employee_id,i.id,'ELECTROAUTO_COMMISSION',i.worker_share_ref_snapshot,'Electroauto · '||i.description,now())
      on conflict do nothing;
    end if;
  end loop;

  insert into public.integration_events(event_type,aggregate_type,aggregate_id,payload)
  values('order.closed','order',p_order_id,jsonb_build_object(
    'order_number',v_order.order_number,'total_ves',v_total_ves,'total_ref',v_total_ref,
    'payment_status','CASHEA','cashea_sale_id',v_sale_id,'initial_percent',p_initial_percent,
    'initial_ref',v_initial_ref,'financed_ref',v_financed_ref,'commission_ref',v_commission_ref
  ));

  insert into public.audit_events(event_type,entity_type,entity_id,data)
  values('order.closed_cashea','order',p_order_id,jsonb_build_object(
    'cashea_sale_id',v_sale_id,'initial_percent',p_initial_percent,'commission_percent',v_commission_pct,
    'initial_ref',v_initial_ref,'financed_ref',v_financed_ref,'commission_ref',v_commission_ref,
    'cashea_reference',nullif(trim(p_cashea_reference),'')
  ));

  order_id := p_order_id;
  order_number := v_order.order_number;
  total_ves := round(v_total_ves,2);
  total_ref := round(v_total_ref,4);
  initial_ves := v_initial_ves;
  initial_ref := v_initial_ref;
  financed_ref := v_financed_ref;
  commission_ref := v_commission_ref;
  cashea_sale_id := v_sale_id;
  return next;
end;
$function$
;
create view public."current_exchange_rates" as  SELECT ( SELECT er.value
           FROM exchange_rates er
          WHERE (er.rate_type = 'BCV'::text)
          ORDER BY er.effective_at DESC, er.created_at DESC
         LIMIT 1) AS bcv_rate,
    ( SELECT er.value
           FROM exchange_rates er
          WHERE (er.rate_type = 'OPERATIVE'::text)
          ORDER BY er.effective_at DESC, er.created_at DESC
         LIMIT 1) AS operative_rate;;
create view public."product_catalog_current" as  SELECT p.id,
    p.name,
    p.category,
    p.filter_code,
    p.available,
    p.active,
    p.cash_usd_base_price,
    r.bcv_rate,
    r.operative_rate,
    round_to_step((p.cash_usd_base_price * r.operative_rate), COALESCE(( SELECT ((app_settings.value #>> '{}'::text[]))::numeric AS "numeric"
           FROM app_settings
          WHERE (app_settings.key = 'price_rounding_step'::text)), (10)::numeric), COALESCE(( SELECT (app_settings.value #>> '{}'::text[])
           FROM app_settings
          WHERE (app_settings.key = 'price_rounding_mode'::text)), 'nearest'::text)) AS current_price_ves,
        CASE
            WHEN (r.bcv_rate > (0)::numeric) THEN (round_to_step((p.cash_usd_base_price * r.operative_rate), COALESCE(( SELECT ((app_settings.value #>> '{}'::text[]))::numeric AS "numeric"
               FROM app_settings
              WHERE (app_settings.key = 'price_rounding_step'::text)), (10)::numeric), COALESCE(( SELECT (app_settings.value #>> '{}'::text[])
               FROM app_settings
              WHERE (app_settings.key = 'price_rounding_mode'::text)), 'nearest'::text)) / r.bcv_rate)
            ELSE NULL::numeric
        END AS current_ref_bcv
   FROM (products p
     CROSS JOIN current_exchange_rates r)
  WHERE (p.active = true);;
create view public."account_balances_current" as  SELECT a.id,
    a.code,
    a.name,
    a.currency,
    a.account_type,
    a.active,
    COALESCE(sum(
        CASE
            WHEN (m.direction = 'IN'::text) THEN m.amount_original
            ELSE (- m.amount_original)
        END), (0)::numeric) AS balance_native,
    COALESCE(sum(
        CASE
            WHEN (m.direction = 'IN'::text) THEN m.value_ves
            ELSE (- m.value_ves)
        END), (0)::numeric) AS balance_ves
   FROM (financial_accounts a
     LEFT JOIN account_movements m ON ((m.account_id = a.id)))
  GROUP BY a.id, a.code, a.name, a.currency, a.account_type, a.active;;
create view public."inventory_current" as  WITH stock AS (
         SELECT inventory_movements.inventory_item_id,
            inventory_movements.location_id,
            sum(inventory_movements.quantity_delta) AS quantity_on_hand
           FROM inventory_movements
          GROUP BY inventory_movements.inventory_item_id, inventory_movements.location_id
        )
 SELECT i.id,
    i.sku,
    i.brand,
    i.description,
    i.category,
    i.unit,
    i.source_cost_ref,
    i.source_stock_imported,
    i.source_alert,
    i.source_price_status,
    i.needs_review,
    i.cost_missing,
    i.product_id,
    l.id AS location_id,
    l.code AS location_code,
    l.name AS location_name,
    COALESCE(s.quantity_on_hand, (0)::numeric) AS quantity_on_hand,
    GREATEST(COALESCE(s.quantity_on_hand, (0)::numeric), (0)::numeric) AS sellable_quantity,
    pc.name AS catalog_product_name,
    pc.cash_usd_base_price,
    pc.current_price_ves,
    pc.current_ref_bcv,
    i.imported_at,
    i.updated_at
   FROM (((inventory_items i
     CROSS JOIN locations l)
     LEFT JOIN stock s ON (((s.inventory_item_id = i.id) AND (s.location_id = l.id))))
     LEFT JOIN product_catalog_current pc ON ((pc.id = i.product_id)))
  WHERE ((i.active = true) AND (l.active = true));;
create view public."order_status_current" as  WITH item_totals AS (
         SELECT order_items.order_id,
            (count(*))::integer AS item_count,
            COALESCE(sum(order_items.charged_ves_amount), (0)::numeric) AS current_total_ves,
            COALESCE(sum(order_items.charged_ref_amount), (0)::numeric) AS current_total_ref,
            string_agg(DISTINCT order_items.business_area, ', '::text ORDER BY order_items.business_area) AS service_areas
           FROM order_items
          GROUP BY order_items.order_id
        ), payment_totals AS (
         SELECT payments.order_id,
            COALESCE(sum(payments.value_ves), (0)::numeric) AS paid_ves,
            COALESCE(sum(payments.value_ref), (0)::numeric) AS paid_ref
           FROM payments
          GROUP BY payments.order_id
        ), open_credit AS (
         SELECT DISTINCT ON (receivables.order_id) receivables.order_id,
            receivables.id AS receivable_id,
            receivables.status AS receivable_status,
            receivables.outstanding_ves,
            receivables.due_date
           FROM receivables
          ORDER BY receivables.order_id, receivables.created_at DESC
        ), crm AS (
         SELECT DISTINCT ON (customer_followups.order_id) customer_followups.order_id,
            customer_followups.status AS crm_status,
            customer_followups.sent_at,
            customer_followups.snoozed_until
           FROM customer_followups
          WHERE (customer_followups.followup_type = 'POST_SERVICE'::text)
          ORDER BY customer_followups.order_id, customer_followups.created_at DESC
        ), cashea AS (
         SELECT DISTINCT ON (cashea_sales.order_id) cashea_sales.order_id,
            cashea_sales.id AS cashea_sale_id,
            cashea_sales.status AS cashea_status
           FROM cashea_sales
          ORDER BY cashea_sales.order_id, cashea_sales.created_at DESC
        )
 SELECT o.id,
    o.order_number,
    o.status,
    o.customer_id,
    o.vehicle_id,
    o.opened_at,
    o.closed_at,
    o.workflow_status,
    o.workflow_updated_at,
    o.health_status,
    o.health_reviewed_at,
    COALESCE(i.item_count, 0) AS item_count,
    COALESCE(i.current_total_ves,
        CASE
            WHEN (o.status = 'CLOSED'::text) THEN o.total_ves
            ELSE (0)::numeric
        END) AS current_total_ves,
    COALESCE(i.current_total_ref,
        CASE
            WHEN (o.status = 'CLOSED'::text) THEN o.total_ref
            ELSE (0)::numeric
        END) AS current_total_ref,
    COALESCE(p.paid_ves, (0)::numeric) AS paid_ves,
    COALESCE(p.paid_ref, (0)::numeric) AS paid_ref,
    i.service_areas,
    c.receivable_id,
    c.receivable_status,
    c.outstanding_ves,
    c.due_date,
    crm.crm_status,
    crm.sent_at AS crm_sent_at,
    crm.snoozed_until AS crm_snoozed_until,
        CASE
            WHEN ((cs.cashea_sale_id IS NOT NULL) AND (cs.cashea_status = ANY (ARRAY['ACTIVE'::text, 'SETTLED'::text]))) THEN 'CASHEA'::text
            WHEN (c.receivable_status = 'OPEN'::text) THEN 'CREDIT_LC'::text
            WHEN (o.status = 'CLOSED'::text) THEN 'PAID'::text
            WHEN (COALESCE(i.current_total_ves, (0)::numeric) <= (0)::numeric) THEN 'NOT_STARTED'::text
            WHEN (COALESCE(p.paid_ves, (0)::numeric) <= (1)::numeric) THEN 'UNPAID'::text
            WHEN ((COALESCE(p.paid_ves, (0)::numeric) + (1)::numeric) < COALESCE(i.current_total_ves, (0)::numeric)) THEN 'PARTIAL'::text
            ELSE 'PAID_PENDING_CLOSE'::text
        END AS financial_status,
        CASE
            WHEN (o.status <> 'CLOSED'::text) THEN 'NOT_APPLICABLE'::text
            WHEN (crm.crm_status IS NULL) THEN 'NO_FOLLOWUP'::text
            ELSE crm.crm_status
        END AS crm_state
   FROM (((((orders o
     LEFT JOIN item_totals i ON ((i.order_id = o.id)))
     LEFT JOIN payment_totals p ON ((p.order_id = o.id)))
     LEFT JOIN open_credit c ON ((c.order_id = o.id)))
     LEFT JOIN crm ON ((crm.order_id = o.id)))
     LEFT JOIN cashea cs ON ((cs.order_id = o.id)));;
create view public."workshop_board_current" as  SELECT o.id,
    o.order_number,
    o.workflow_status,
    o.workflow_updated_at,
    o.opened_at,
    o.health_status,
    o.customer_id,
    o.vehicle_id,
    c.name AS customer_name,
    c.phone AS customer_phone,
    v.plate,
    v.make,
    v.model,
    v.year,
    v.current_odometer,
    (COALESCE(( SELECT count(*) AS count
           FROM order_items oi
          WHERE (oi.order_id = o.id)), (0)::bigint))::integer AS item_count,
    COALESCE(( SELECT sum(oi.charged_ref_amount) AS sum
           FROM order_items oi
          WHERE (oi.order_id = o.id)), (0)::numeric) AS current_total_ref,
    COALESCE(( SELECT string_agg(DISTINCT oi.business_area, ' · '::text) AS string_agg
           FROM order_items oi
          WHERE ((oi.order_id = o.id) AND (oi.item_type = 'SERVICE'::text))), ''::text) AS service_areas,
    o.is_walk_in
   FROM ((orders o
     LEFT JOIN customers c ON ((c.id = o.customer_id)))
     LEFT JOIN vehicles v ON ((v.id = o.vehicle_id)))
  WHERE ((o.status = 'OPEN'::text) AND ((o.vehicle_id IS NOT NULL) OR (EXISTS ( SELECT 1
           FROM order_items oi
          WHERE ((oi.order_id = o.id) AND (oi.business_area = ANY (ARRAY['WORKSHOP'::text, 'ELECTROAUTO'::text, 'OIL_CHANGE'::text])))))));;
create view public."maintenance_reminders_current" as  WITH latest AS (
         SELECT DISTINCT ON (sr.vehicle_id) sr.id AS service_record_id,
            sr.vehicle_id,
            sr.customer_id,
            sr.performed_at,
            sr.odometer,
            sr.oil_brand,
            sr.oil_viscosity,
            sr.oil_filter_code,
            sr.next_service_odometer,
            sr.next_service_date,
            sr.description
           FROM service_records sr
          WHERE ((sr.service_type = 'OIL_CHANGE'::text) AND (NOT (EXISTS ( SELECT 1
                   FROM orders o
                  WHERE ((o.id = sr.order_id) AND (o.status = 'CANCELLED'::text))))))
          ORDER BY sr.vehicle_id, sr.performed_at DESC, sr.created_at DESC
        ), cutoff AS (
         SELECT COALESCE(( SELECT (TRIM(BOTH '"'::text FROM (app_settings.value)::text))::date AS btrim
                   FROM app_settings
                  WHERE (app_settings.key = 'crm_operational_start_date'::text)), '2026-09-10'::date) AS start_date
        )
 SELECT l.service_record_id,
    l.vehicle_id,
    l.customer_id,
    c.name AS customer_name,
    c.phone AS customer_phone,
    v.plate,
    v.make,
    v.model,
    v.year,
    v.current_odometer,
    l.performed_at,
    l.odometer AS service_odometer,
    l.oil_brand,
    l.oil_viscosity,
    l.oil_filter_code,
    l.next_service_odometer,
    l.next_service_date,
        CASE
            WHEN (a.status IS NOT NULL) THEN a.status
            WHEN ((l.next_service_date IS NOT NULL) AND (l.next_service_date < cutoff.start_date)) THEN 'SENT'::text
            ELSE 'PENDING'::text
        END AS reminder_status,
    a.snoozed_until,
        CASE
            WHEN (a.sent_at IS NOT NULL) THEN a.sent_at
            WHEN ((a.status IS NULL) AND (l.next_service_date IS NOT NULL) AND (l.next_service_date < cutoff.start_date)) THEN (l.next_service_date)::timestamp with time zone
            ELSE NULL::timestamp with time zone
        END AS sent_at,
        CASE
            WHEN (a.status = 'SENT'::text) THEN 'SENT'::text
            WHEN ((a.status IS NULL) AND (l.next_service_date IS NOT NULL) AND (l.next_service_date < cutoff.start_date)) THEN 'SENT'::text
            WHEN ((a.status = 'SNOOZED'::text) AND (a.snoozed_until > CURRENT_DATE)) THEN 'SNOOZED'::text
            WHEN ((l.next_service_date IS NOT NULL) AND (l.next_service_date <= CURRENT_DATE)) THEN 'DUE'::text
            WHEN ((l.next_service_odometer IS NOT NULL) AND (v.current_odometer IS NOT NULL) AND (v.current_odometer >= l.next_service_odometer)) THEN 'DUE'::text
            WHEN ((l.next_service_date IS NOT NULL) AND (l.next_service_date <= (CURRENT_DATE + 14))) THEN 'SOON'::text
            ELSE 'UPCOMING'::text
        END AS urgency
   FROM ((((latest l
     JOIN vehicles v ON ((v.id = l.vehicle_id)))
     LEFT JOIN customers c ON ((c.id = COALESCE(l.customer_id, v.customer_id))))
     LEFT JOIN maintenance_reminder_actions a ON ((a.service_record_id = l.service_record_id)))
     CROSS JOIN cutoff);;
create view public."customer_followups_current" as  SELECT f.id,
    f.order_id,
    f.followup_type,
    f.channel,
    f.status,
    f.message,
    f.sent_at,
    f.snoozed_until,
    f.created_at,
    o.order_number,
    o.closed_at,
    o.health_status,
    o.health_notes,
    c.id AS customer_id,
    c.name AS customer_name,
    c.phone AS customer_phone,
    v.id AS vehicle_id,
    v.plate,
    v.make,
    v.model,
    v.year
   FROM (((customer_followups f
     JOIN orders o ON ((o.id = f.order_id)))
     LEFT JOIN customers c ON ((c.id = f.customer_id)))
     LEFT JOIN vehicles v ON ((v.id = f.vehicle_id)));;
CREATE UNIQUE INDEX IF NOT EXISTS cashea_sales_pkey ON public.cashea_sales USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS cashea_sales_order_id_key ON public.cashea_sales USING btree (order_id);
CREATE UNIQUE INDEX IF NOT EXISTS cashea_sales_receivable_id_key ON public.cashea_sales USING btree (receivable_id);
CREATE INDEX IF NOT EXISTS idx_cashea_sales_status ON public.cashea_sales USING btree (status, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS cashea_installments_pkey ON public.cashea_installments USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS cashea_installments_cashea_sale_id_installment_no_key ON public.cashea_installments USING btree (cashea_sale_id, installment_no);
CREATE INDEX IF NOT EXISTS idx_cashea_installments_due ON public.cashea_installments USING btree (status, due_date);
CREATE UNIQUE INDEX IF NOT EXISTS inventory_movements_pkey ON public.inventory_movements USING btree (id);
CREATE INDEX IF NOT EXISTS inventory_movements_item_location_idx ON public.inventory_movements USING btree (inventory_item_id, location_id, occurred_at);
CREATE UNIQUE INDEX IF NOT EXISTS inventory_sale_order_item_uidx ON public.inventory_movements USING btree (order_item_id) WHERE ((movement_type = 'SALE'::text) AND (order_item_id IS NOT NULL));
CREATE INDEX IF NOT EXISTS inventory_movements_location_id_idx ON public.inventory_movements USING btree (location_id);
CREATE UNIQUE INDEX IF NOT EXISTS inventory_movement_receipt_unique ON public.inventory_movements USING btree (supplier_receipt_item_id) WHERE (supplier_receipt_item_id IS NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS suppliers_pkey ON public.suppliers USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS suppliers_rif_unique ON public.suppliers USING btree (upper(TRIM(BOTH FROM rif))) WHERE ((rif IS NOT NULL) AND (TRIM(BOTH FROM rif) <> ''::text));
CREATE INDEX IF NOT EXISTS suppliers_name_idx ON public.suppliers USING btree (lower(name));
CREATE UNIQUE INDEX IF NOT EXISTS supplier_invoices_pkey ON public.supplier_invoices USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS supplier_invoice_number_unique ON public.supplier_invoices USING btree (supplier_id, upper(TRIM(BOTH FROM invoice_number))) WHERE (status <> 'VOID'::text);
CREATE INDEX IF NOT EXISTS supplier_invoices_due_idx ON public.supplier_invoices USING btree (status, due_date);
CREATE UNIQUE INDEX IF NOT EXISTS supplier_invoice_items_pkey ON public.supplier_invoice_items USING btree (id);
CREATE INDEX IF NOT EXISTS supplier_invoice_items_invoice_idx ON public.supplier_invoice_items USING btree (supplier_invoice_id);
CREATE INDEX IF NOT EXISTS supplier_invoice_items_inventory_idx ON public.supplier_invoice_items USING btree (inventory_item_id) WHERE (inventory_item_id IS NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS supplier_receipts_pkey ON public.supplier_receipts USING btree (id);
CREATE INDEX IF NOT EXISTS supplier_receipts_invoice_idx ON public.supplier_receipts USING btree (supplier_invoice_id);
CREATE INDEX IF NOT EXISTS supplier_receipts_location_idx ON public.supplier_receipts USING btree (location_id);
CREATE UNIQUE INDEX IF NOT EXISTS supplier_receipt_items_pkey ON public.supplier_receipt_items USING btree (id);
CREATE INDEX IF NOT EXISTS supplier_receipt_items_receipt_idx ON public.supplier_receipt_items USING btree (supplier_receipt_id);
CREATE INDEX IF NOT EXISTS supplier_receipt_items_invoice_item_idx ON public.supplier_receipt_items USING btree (supplier_invoice_item_id);
CREATE INDEX IF NOT EXISTS supplier_receipt_items_inventory_idx ON public.supplier_receipt_items USING btree (inventory_item_id);
CREATE UNIQUE INDEX IF NOT EXISTS supplier_payments_pkey ON public.supplier_payments USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS supplier_payments_account_movement_id_key ON public.supplier_payments USING btree (account_movement_id);
CREATE INDEX IF NOT EXISTS supplier_payments_invoice_idx ON public.supplier_payments USING btree (supplier_invoice_id);
CREATE INDEX IF NOT EXISTS supplier_payments_account_idx ON public.supplier_payments USING btree (account_id);
CREATE UNIQUE INDEX IF NOT EXISTS cash_closings_pkey ON public.cash_closings USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS cash_closings_business_date_location_id_key ON public.cash_closings USING btree (business_date, location_id);
CREATE INDEX IF NOT EXISTS cash_closings_location_idx ON public.cash_closings USING btree (location_id);
CREATE UNIQUE INDEX IF NOT EXISTS cash_closing_accounts_pkey ON public.cash_closing_accounts USING btree (cash_closing_id, account_id);
CREATE INDEX IF NOT EXISTS cash_closing_accounts_account_idx ON public.cash_closing_accounts USING btree (account_id);
CREATE UNIQUE INDEX IF NOT EXISTS products_pkey ON public.products USING btree (id);
CREATE INDEX IF NOT EXISTS products_name_idx ON public.products USING btree (name);
CREATE INDEX IF NOT EXISTS products_filter_code_idx ON public.products USING btree (filter_code);
CREATE UNIQUE INDEX IF NOT EXISTS products_normalized_name_uidx ON public.products USING btree (lower(btrim(name)));
CREATE UNIQUE INDEX IF NOT EXISTS app_settings_pkey ON public.app_settings USING btree (key);
CREATE UNIQUE INDEX IF NOT EXISTS locations_pkey ON public.locations USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS locations_code_key ON public.locations USING btree (code);
CREATE UNIQUE INDEX IF NOT EXISTS employees_pkey ON public.employees USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS employees_code_key ON public.employees USING btree (code);
CREATE UNIQUE INDEX IF NOT EXISTS customers_pkey ON public.customers USING btree (id);
CREATE INDEX IF NOT EXISTS customers_phone_idx ON public.customers USING btree (phone);
CREATE UNIQUE INDEX IF NOT EXISTS vehicles_pkey ON public.vehicles USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS vehicles_plate_unique ON public.vehicles USING btree (upper(plate)) WHERE ((plate IS NOT NULL) AND (plate <> ''::text));
CREATE INDEX IF NOT EXISTS vehicles_customer_id_idx ON public.vehicles USING btree (customer_id);
CREATE UNIQUE INDEX IF NOT EXISTS exchange_rates_pkey ON public.exchange_rates USING btree (id);
CREATE INDEX IF NOT EXISTS exchange_rates_lookup_idx ON public.exchange_rates USING btree (rate_type, effective_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS compensation_rules_pkey ON public.compensation_rules USING btree (id);
CREATE INDEX IF NOT EXISTS compensation_rules_lookup_idx ON public.compensation_rules USING btree (employee_id, rule_type, valid_from DESC);
CREATE UNIQUE INDEX IF NOT EXISTS receivables_pkey ON public.receivables USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS receivables_one_per_order ON public.receivables USING btree (order_id);
CREATE INDEX IF NOT EXISTS receivables_customer_id_idx ON public.receivables USING btree (customer_id);
CREATE UNIQUE INDEX IF NOT EXISTS integration_events_pkey ON public.integration_events USING btree (id);
CREATE INDEX IF NOT EXISTS integration_events_outbox_idx ON public.integration_events USING btree (status, available_at) WHERE (status = ANY (ARRAY['PENDING'::text, 'FAILED'::text]));
CREATE UNIQUE INDEX IF NOT EXISTS audit_events_pkey ON public.audit_events USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS payroll_accruals_pkey ON public.payroll_accruals USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS payroll_accruals_employee_id_source_order_item_id_source_ty_key ON public.payroll_accruals USING btree (employee_id, source_order_item_id, source_type);
CREATE INDEX IF NOT EXISTS payroll_accruals_pending_idx ON public.payroll_accruals USING btree (employee_id, occurred_at) WHERE (payroll_run_id IS NULL);
CREATE INDEX IF NOT EXISTS payroll_accruals_payroll_run_id_idx ON public.payroll_accruals USING btree (payroll_run_id);
CREATE INDEX IF NOT EXISTS payroll_accruals_source_order_item_id_idx ON public.payroll_accruals USING btree (source_order_item_id);
CREATE UNIQUE INDEX IF NOT EXISTS payroll_runs_pkey ON public.payroll_runs USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS payroll_runs_employee_id_period_start_period_end_key ON public.payroll_runs USING btree (employee_id, period_start, period_end);
CREATE UNIQUE INDEX IF NOT EXISTS payroll_adjustments_pkey ON public.payroll_adjustments USING btree (id);
CREATE INDEX IF NOT EXISTS payroll_adjustments_pending_idx ON public.payroll_adjustments USING btree (employee_id, occurred_on) WHERE (payroll_run_id IS NULL);
CREATE INDEX IF NOT EXISTS payroll_adjustments_payroll_run_id_idx ON public.payroll_adjustments USING btree (payroll_run_id);
CREATE UNIQUE INDEX IF NOT EXISTS payments_pkey ON public.payments USING btree (id);
CREATE INDEX IF NOT EXISTS payments_order_idx ON public.payments USING btree (order_id, paid_at);
CREATE INDEX IF NOT EXISTS payments_receivable_id_idx ON public.payments USING btree (receivable_id);
CREATE INDEX IF NOT EXISTS payments_financial_account_id_idx ON public.payments USING btree (financial_account_id);
CREATE INDEX IF NOT EXISTS order_items_inventory_item_idx ON public.order_items USING btree (inventory_item_id);
CREATE UNIQUE INDEX IF NOT EXISTS order_items_pkey ON public.order_items USING btree (id);
CREATE INDEX IF NOT EXISTS order_items_order_idx ON public.order_items USING btree (order_id, created_at);
CREATE INDEX IF NOT EXISTS order_items_product_id_idx ON public.order_items USING btree (product_id);
CREATE INDEX IF NOT EXISTS order_items_worker_employee_id_idx ON public.order_items USING btree (worker_employee_id);
CREATE INDEX IF NOT EXISTS order_items_assistant_bonus_employee_id_idx ON public.order_items USING btree (assistant_bonus_employee_id);
CREATE INDEX IF NOT EXISTS order_items_inventory_location_id_idx ON public.order_items USING btree (inventory_location_id);
CREATE INDEX IF NOT EXISTS idx_orders_workflow_open ON public.orders USING btree (status, workflow_status, workflow_updated_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS orders_pkey ON public.orders USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS orders_order_seq_key ON public.orders USING btree (order_seq);
CREATE INDEX IF NOT EXISTS orders_status_idx ON public.orders USING btree (status, opened_at DESC);
CREATE INDEX IF NOT EXISTS orders_customer_id_idx ON public.orders USING btree (customer_id);
CREATE INDEX IF NOT EXISTS orders_vehicle_id_idx ON public.orders USING btree (vehicle_id);
CREATE INDEX IF NOT EXISTS orders_location_id_idx ON public.orders USING btree (location_id);
CREATE UNIQUE INDEX IF NOT EXISTS orders_one_correction ON public.orders USING btree (corrects_order_id) WHERE (corrects_order_id IS NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS account_movements_pkey ON public.account_movements USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS account_movements_payment_uidx ON public.account_movements USING btree (source_payment_id) WHERE (source_payment_id IS NOT NULL);
CREATE INDEX IF NOT EXISTS account_movements_account_date_idx ON public.account_movements USING btree (account_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS account_movements_transfer_group_idx ON public.account_movements USING btree (transfer_group) WHERE (transfer_group IS NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS financial_accounts_pkey ON public.financial_accounts USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS financial_accounts_code_key ON public.financial_accounts USING btree (code);
CREATE UNIQUE INDEX IF NOT EXISTS service_records_pkey ON public.service_records USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS service_records_order_item_id_key ON public.service_records USING btree (order_item_id);
CREATE INDEX IF NOT EXISTS service_records_vehicle_performed_idx ON public.service_records USING btree (vehicle_id, performed_at DESC);
CREATE INDEX IF NOT EXISTS service_records_customer_idx ON public.service_records USING btree (customer_id);
CREATE INDEX IF NOT EXISTS service_records_next_date_idx ON public.service_records USING btree (next_service_date) WHERE (next_service_date IS NOT NULL);
CREATE INDEX IF NOT EXISTS service_records_next_odometer_idx ON public.service_records USING btree (vehicle_id, next_service_odometer) WHERE (next_service_odometer IS NOT NULL);
CREATE INDEX IF NOT EXISTS service_records_order_id_idx ON public.service_records USING btree (order_id);
CREATE UNIQUE INDEX IF NOT EXISTS service_records_source_unique ON public.service_records USING btree (source_system, source_key) WHERE ((source_system IS NOT NULL) AND (source_key IS NOT NULL));
CREATE UNIQUE INDEX IF NOT EXISTS integration_sync_state_pkey ON public.integration_sync_state USING btree (source_key);
CREATE UNIQUE INDEX IF NOT EXISTS maintenance_reminder_actions_pkey ON public.maintenance_reminder_actions USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS maintenance_reminder_actions_service_record_id_key ON public.maintenance_reminder_actions USING btree (service_record_id);
CREATE INDEX IF NOT EXISTS inventory_items_category_idx ON public.inventory_items USING btree (category);
CREATE INDEX IF NOT EXISTS inventory_items_product_idx ON public.inventory_items USING btree (product_id);
CREATE UNIQUE INDEX IF NOT EXISTS inventory_items_sku_brand_key ON public.inventory_items USING btree (sku, brand);
CREATE UNIQUE INDEX IF NOT EXISTS inventory_items_brand_sku_uidx ON public.inventory_items USING btree (COALESCE(brand, ''::text), sku);
CREATE UNIQUE INDEX IF NOT EXISTS inventory_items_pkey ON public.inventory_items USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS customer_followups_pkey ON public.customer_followups USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS customer_followups_order_id_followup_type_key ON public.customer_followups USING btree (order_id, followup_type);
CREATE INDEX IF NOT EXISTS customer_followups_customer_id_idx ON public.customer_followups USING btree (customer_id);
CREATE INDEX IF NOT EXISTS customer_followups_vehicle_id_idx ON public.customer_followups USING btree (vehicle_id);
CREATE UNIQUE INDEX IF NOT EXISTS order_history_pkey ON public.order_history USING btree (id);
CREATE INDEX IF NOT EXISTS order_history_order_time ON public.order_history USING btree (order_id, recorded_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS data_import_runs_pkey ON public.data_import_runs USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS data_import_issues_pkey ON public.data_import_issues USING btree (id);
CREATE INDEX IF NOT EXISTS data_import_issues_source_idx ON public.data_import_issues USING btree (source_system, resolved, issue_type);
CREATE UNIQUE INDEX IF NOT EXISTS customer_external_identities_pkey ON public.customer_external_identities USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS customer_external_identities_source_system_external_key_key ON public.customer_external_identities USING btree (source_system, external_key);
CREATE INDEX IF NOT EXISTS customer_external_identity_customer_idx ON public.customer_external_identities USING btree (customer_id);
CREATE UNIQUE INDEX IF NOT EXISTS vehicle_plate_aliases_pkey ON public.vehicle_plate_aliases USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS vehicle_plate_aliases_vehicle_id_source_system_normalized_a_key ON public.vehicle_plate_aliases USING btree (vehicle_id, source_system, normalized_alias);
CREATE INDEX IF NOT EXISTS vehicle_plate_alias_norm_idx ON public.vehicle_plate_aliases USING btree (normalized_alias);
CREATE UNIQUE INDEX IF NOT EXISTS vehicle_customer_history_pkey ON public.vehicle_customer_history USING btree (id);
CREATE UNIQUE INDEX IF NOT EXISTS vehicle_customer_history_vehicle_id_customer_id_source_syst_key ON public.vehicle_customer_history USING btree (vehicle_id, customer_id, source_system);
CREATE INDEX IF NOT EXISTS vehicle_customer_history_vehicle_idx ON public.vehicle_customer_history USING btree (vehicle_id, last_seen_at DESC);
CREATE INDEX IF NOT EXISTS vehicle_customer_history_customer_id_idx ON public.vehicle_customer_history USING btree (customer_id);
CREATE UNIQUE INDEX IF NOT EXISTS legacy_service_import_stage_pkey ON public.legacy_service_import_stage USING btree (source_system, source_key);
CREATE TRIGGER employees_touch BEFORE UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER customers_touch BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER vehicles_touch BEFORE UPDATE ON public.vehicles FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER products_touch BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_capture_service_records_on_close AFTER UPDATE OF status ON public.orders FOR EACH ROW EXECUTE FUNCTION capture_service_records_on_close();
CREATE TRIGGER trg_assign_payment_account BEFORE INSERT ON public.payments FOR EACH ROW EXECUTE FUNCTION assign_payment_account();
CREATE TRIGGER trg_capture_payment_movement AFTER INSERT ON public.payments FOR EACH ROW EXECUTE FUNCTION capture_payment_movement();
CREATE TRIGGER trg_consume_inventory_on_order_close BEFORE UPDATE OF status ON public.orders FOR EACH ROW EXECUTE FUNCTION consume_inventory_on_order_close();
CREATE TRIGGER trg_queue_post_service_followup AFTER UPDATE OF status ON public.orders FOR EACH ROW EXECUTE FUNCTION queue_post_service_followup();
CREATE TRIGGER trg_enforce_order_close_readiness BEFORE UPDATE OF status ON public.orders FOR EACH ROW WHEN (((new.status = 'CLOSED'::text) AND (old.status IS DISTINCT FROM 'CLOSED'::text))) EXECUTE FUNCTION enforce_order_close_readiness();
CREATE TRIGGER guard_closed_edits BEFORE DELETE OR UPDATE ON public.payments FOR EACH ROW EXECUTE FUNCTION lubricenter_private.guard_closed_edits();
CREATE TRIGGER audit_order_movement AFTER INSERT OR DELETE OR UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION lubricenter_private.capture_order_history();
CREATE TRIGGER audit_order_movement AFTER INSERT OR DELETE OR UPDATE ON public.order_items FOR EACH ROW EXECUTE FUNCTION lubricenter_private.capture_order_history();
CREATE TRIGGER audit_order_movement AFTER INSERT OR DELETE OR UPDATE ON public.payments FOR EACH ROW EXECUTE FUNCTION lubricenter_private.capture_order_history();
CREATE TRIGGER audit_order_movement AFTER INSERT OR DELETE OR UPDATE ON public.inventory_movements FOR EACH ROW EXECUTE FUNCTION lubricenter_private.capture_order_history();
CREATE TRIGGER audit_order_movement AFTER INSERT OR DELETE OR UPDATE ON public.account_movements FOR EACH ROW EXECUTE FUNCTION lubricenter_private.capture_order_history();
CREATE TRIGGER audit_order_movement AFTER INSERT OR DELETE OR UPDATE ON public.payroll_accruals FOR EACH ROW EXECUTE FUNCTION lubricenter_private.capture_order_history();
CREATE TRIGGER audit_order_movement AFTER INSERT OR DELETE OR UPDATE ON public.payroll_adjustments FOR EACH ROW EXECUTE FUNCTION lubricenter_private.capture_order_history();
CREATE TRIGGER audit_order_movement AFTER INSERT OR DELETE OR UPDATE ON public.receivables FOR EACH ROW EXECUTE FUNCTION lubricenter_private.capture_order_history();
CREATE TRIGGER audit_order_movement AFTER INSERT OR DELETE OR UPDATE ON public.cashea_sales FOR EACH ROW EXECUTE FUNCTION lubricenter_private.capture_order_history();
CREATE TRIGGER audit_order_movement AFTER INSERT OR DELETE OR UPDATE ON public.cashea_installments FOR EACH ROW EXECUTE FUNCTION lubricenter_private.capture_order_history();
CREATE TRIGGER audit_order_movement AFTER INSERT OR DELETE OR UPDATE ON public.customer_followups FOR EACH ROW EXECUTE FUNCTION lubricenter_private.capture_order_history();
CREATE TRIGGER immutable_history BEFORE DELETE OR UPDATE OR TRUNCATE ON public.order_history FOR EACH STATEMENT EXECUTE FUNCTION lubricenter_private.immutable_history();
CREATE TRIGGER guard_closed_edits BEFORE DELETE OR UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION lubricenter_private.guard_closed_edits();
CREATE TRIGGER guard_closed_edits BEFORE INSERT OR DELETE OR UPDATE ON public.order_items FOR EACH ROW EXECUTE FUNCTION lubricenter_private.guard_closed_edits();
CREATE TRIGGER aa_business_date BEFORE INSERT OR UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION lubricenter_private.apply_business_date();
CREATE TRIGGER aa_business_date BEFORE INSERT ON public.payments FOR EACH ROW EXECUTE FUNCTION lubricenter_private.apply_business_date();
CREATE TRIGGER aa_business_date BEFORE INSERT ON public.payroll_accruals FOR EACH ROW EXECUTE FUNCTION lubricenter_private.apply_business_date();
CREATE TRIGGER ab_normalize_order_walk_in BEFORE INSERT OR UPDATE OF customer_id, vehicle_id, corrects_order_id, is_walk_in ON public.orders FOR EACH ROW EXECUTE FUNCTION lubricenter_private.normalize_order_walk_in();
CREATE TRIGGER snapshot_order_item_cost_trigger BEFORE INSERT ON public.inventory_movements FOR EACH ROW EXECUTE FUNCTION snapshot_order_item_cost();
CREATE TRIGGER mark_cash_close_review_trigger AFTER INSERT OR DELETE OR UPDATE ON public.account_movements FOR EACH ROW EXECUTE FUNCTION mark_cash_close_review();
alter table "public"."cashea_sales" enable row level security;
alter table "public"."cashea_installments" enable row level security;
alter table "public"."inventory_movements" enable row level security;
alter table "public"."suppliers" enable row level security;
alter table "public"."supplier_invoices" enable row level security;
alter table "public"."supplier_invoice_items" enable row level security;
alter table "public"."supplier_receipts" enable row level security;
alter table "public"."supplier_receipt_items" enable row level security;
alter table "public"."supplier_payments" enable row level security;
alter table "public"."cash_closings" enable row level security;
alter table "public"."cash_closing_accounts" enable row level security;
alter table "public"."products" enable row level security;
alter table "public"."app_settings" enable row level security;
alter table "public"."locations" enable row level security;
alter table "public"."employees" enable row level security;
alter table "public"."customers" enable row level security;
alter table "public"."vehicles" enable row level security;
alter table "public"."exchange_rates" enable row level security;
alter table "public"."compensation_rules" enable row level security;
alter table "public"."receivables" enable row level security;
alter table "public"."integration_events" enable row level security;
alter table "public"."audit_events" enable row level security;
alter table "public"."payroll_accruals" enable row level security;
alter table "public"."payroll_runs" enable row level security;
alter table "public"."payroll_adjustments" enable row level security;
alter table "public"."payments" enable row level security;
alter table "public"."order_items" enable row level security;
alter table "public"."orders" enable row level security;
alter table "public"."account_movements" enable row level security;
alter table "public"."financial_accounts" enable row level security;
alter table "public"."service_records" enable row level security;
alter table "public"."integration_sync_state" enable row level security;
alter table "public"."maintenance_reminder_actions" enable row level security;
alter table "public"."inventory_items" enable row level security;
alter table "public"."customer_followups" enable row level security;
alter table "public"."order_history" enable row level security;
alter table "public"."data_import_runs" enable row level security;
alter table "public"."data_import_issues" enable row level security;
alter table "public"."customer_external_identities" enable row level security;
alter table "public"."vehicle_plate_aliases" enable row level security;
alter table "public"."vehicle_customer_history" enable row level security;
alter table "public"."legacy_service_import_stage" enable row level security;
create policy "cashea_sales_read_authenticated" on "public"."cashea_sales" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "cashea_installments_read_authenticated" on "public"."cashea_installments" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."inventory_movements" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."suppliers" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."supplier_invoices" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."supplier_invoice_items" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."supplier_receipts" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."supplier_receipt_items" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."supplier_payments" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."cash_closings" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."cash_closing_accounts" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."products" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."app_settings" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."locations" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."employees" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."customers" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."vehicles" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."exchange_rates" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."compensation_rules" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."receivables" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."integration_events" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."audit_events" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."payroll_accruals" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."payroll_runs" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."payroll_adjustments" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."payments" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."order_items" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."orders" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."account_movements" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."financial_accounts" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."service_records" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."maintenance_reminder_actions" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated_read" on "public"."inventory_items" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "customer_followups_authenticated_select" on "public"."customer_followups" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "customer_followups_authenticated_update" on "public"."customer_followups" as PERMISSIVE for UPDATE to "authenticated" using (true) with check (true);
create policy "order_history_read" on "public"."order_history" as PERMISSIVE for SELECT to "authenticated" using ((( SELECT auth.uid() AS uid) IS NOT NULL));
create policy "authenticated read import runs" on "public"."data_import_runs" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated read import issues" on "public"."data_import_issues" as PERMISSIVE for SELECT to "authenticated" using (true);
create policy "authenticated read vehicle customer history" on "public"."vehicle_customer_history" as PERMISSIVE for SELECT to "authenticated" using (true);
grant usage on schema public,auth,lubricenter_private to authenticated; grant select on all tables in schema public to authenticated;
